#ifndef STATS_ENGINE_H
#define STATS_ENGINE_H

/*
 * Component 3: Cricket Statistics Engine
 * Compatible with the team's match_model.h (Component 2).
 *
 * This module calculates cricket statistics and builds graph-ready series.
 * It does NOT render graphs; Component 4 owns rendering.
 *
 * Compile as C99 or later.
 */
#include <stddef.h>
#include "match_model.h"

#ifdef __cplusplus
extern "C" {
#endif

#define STATS_NAME_LEN NAME_LEN
#define STATS_TITLE_LEN 64

typedef enum {
    STATS_OK = 0,
    STATS_NO_DATA,
    STATS_INVALID_ARGUMENT,
    STATS_INVALID_DATA,
    STATS_BUFFER_TOO_SMALL,
    STATS_NO_MEMORY
} StatsStatus;

typedef struct {
    double strike_rate;       /* runs per 100 balls */
    int boundary_runs;        /* 4*fours + 6*sixes */
    int boundary_count;       /* fours + sixes */
} BattingStats;

typedef struct {
    char overs[24];           /* e.g. "3.4" (3 overs, 4 balls) */
    double economy;           /* runs conceded per 6 legal balls */
    double bowling_average;   /* runs conceded per wicket */
    double bowling_strike_rate; /* legal balls per wicket */
} BowlingStats;

typedef struct {
    int total_runs;
    int wickets;
    int legal_balls;
    char overs[24];
    double run_rate;
    int total_fours;
    int total_sixes;
    int boundary_runs;
    int boundary_count;
    int highest_over_runs;
    int highest_over_number;
    int top_scorer_index;     /* -1 if no batter data */
    int best_bowler_index;    /* -1 if no bowler data */
    int last_wicket_index;    /* -1 if no fall-of-wicket data */
} InningsStats;

/* A point is deliberately simple for Component 4 to render in Pure C. */
typedef struct {
    double x;
    double y;
    char label[NAME_LEN];
} StatsPoint;

typedef struct {
    char title[STATS_TITLE_LEN];
    StatsPoint *points;       /* owned by this series after successful build */
    size_t count;
} StatsSeries;

/* Validate all fields consumed by this module. Returns STATS_INVALID_DATA for
 * inconsistent records and STATS_INVALID_ARGUMENT for a null innings pointer. */
StatsStatus stats_validate_innings(const Innings *innings);

/* Individual player calculations. */
StatsStatus stats_batting(const Player *batter, BattingStats *out);
StatsStatus stats_bowling(const Player *bowler, BowlingStats *out);

/* Cricket overs display: legal balls 20 -> "3.2". */
StatsStatus stats_format_overs(int legal_balls, char *buffer, size_t size);

/* Required run rate to reach target_runs, using legal balls remaining.
 * If the target is already reached, returns STATS_OK with 0.0. If balls are
 * exhausted while runs are still needed, returns STATS_NO_DATA with 0.0. */
StatsStatus stats_required_run_rate(int target_runs, int current_runs,
                                    int legal_balls_remaining, double *out);

/* Calculate an innings summary. Index fields refer to the source arrays. */
StatsStatus stats_innings(const Innings *innings, InningsStats *out);

/* Build/free graph-ready series. Initialize with stats_series_init before first
 * use and call stats_series_free when finished. The series owns its points.
 * On STATS_NO_DATA or an error, an existing series is left unchanged, except
 * cumulative-run overflow, which clears the newly allocated result safely. */
void stats_series_init(StatsSeries *series);
void stats_series_free(StatsSeries *series);

/* One point per recorded over. x=over number; y=runs or wickets. */
StatsStatus stats_graph_runs_per_over(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_wickets_per_over(const Innings *innings, StatsSeries *out);

/* Cumulative runs across recorded overs (respects actual over_number gaps). */
StatsStatus stats_graph_cumulative_runs(const Innings *innings, StatsSeries *out);

/* One point per batter/bowler. x=1-based player index; y=selected statistic. */
StatsStatus stats_graph_batter_runs(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_batter_strike_rates(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_bowler_wickets(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_bowler_economy(const Innings *innings, StatsSeries *out);

/* Fall-of-wickets: x=team score at fall; y=wicket number. */
StatsStatus stats_graph_fall_of_wickets(const Innings *innings, StatsSeries *out);

/* Boundary totals: points are labelled "Fours" and "Sixes". */
StatsStatus stats_graph_boundaries(const Innings *innings, StatsSeries *out);

/* Two-innings comparison: points labelled with batting team names.
 * y=total runs or wickets respectively.
 */
StatsStatus stats_graph_innings_runs_comparison(const Match *match, StatsSeries *out);
StatsStatus stats_graph_innings_wickets_comparison(const Match *match, StatsSeries *out);

/* Print a readable text report (useful for testing/debugging). */
StatsStatus stats_print_innings_report(const Innings *innings);

#ifdef __cplusplus
}
#endif
#endif
