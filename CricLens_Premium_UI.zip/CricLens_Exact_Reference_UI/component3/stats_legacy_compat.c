#include <stdio.h>
#include <string.h>
#include "stats_legacy_compat.h"
#include "stats_engine.h"

/*
 * Compatibility layer for the original Component 5 interface.
 * The calculations for batting and over-by-over graph data now delegate to
 * the improved Component 3 API. Awards, result text and partnerships retain
 * their original public interface so existing Component 5 code keeps working.
 */
void stats_batter(const Player *p, int dismissals, BatterStats *out)
{
    BattingStats calculated;
    StatsStatus status;
    if (!p || !out) return;
    memset(out, 0, sizeof(*out));
    status = stats_batting(p, &calculated);
    if (status != STATS_OK && status != STATS_NO_DATA) return;
    out->strike_rate = (float)calculated.strike_rate;
    out->average = dismissals > 0 ? (float)p->runs / dismissals : (float)p->runs;
    out->boundary_pct = p->runs > 0
        ? (float)calculated.boundary_runs * 100.0f / (float)p->runs : 0.0f;
}

static int copy_series_y(const Innings *in, int *out, int max,
                         StatsStatus (*builder)(const Innings *, StatsSeries *))
{
    StatsSeries series;
    StatsStatus status;
    size_t i, count;
    if (!in || !out || max <= 0) return 0;
    stats_series_init(&series);
    status = builder(in, &series);
    if (status != STATS_OK) {
        stats_series_free(&series);
        return 0;
    }
    count = series.count < (size_t)max ? series.count : (size_t)max;
    for (i = 0; i < count; ++i) out[i] = (int)series.points[i].y;
    stats_series_free(&series);
    return (int)count;
}

int stats_over_runs(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_runs_per_over);
}

int stats_cumulative_runs(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_cumulative_runs);
}

int stats_over_wickets(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_wickets_per_over);
}

/* ---- Partnerships, worked out from the fall of wickets ---- */
static void batter_name(const Innings *in, size_t idx, char *dst)
{
    if (idx < in->batter_count) snprintf(dst, NAME_LEN, "%s", in->batters[idx].name);
    else snprintf(dst, NAME_LEN, "Batter %zu", idx + 1);
}

int stats_partnerships(const Innings *in, Partnership *out, int max)
{
    size_t k;
    int n = 0, prev = 0;
    if (!in || !out || max <= 0) return 0;
    for (k = 0; k < in->fow_count && n < max; ++k) {
        out[n].runs = in->fow[k].team_score - prev;
        out[n].unbeaten = 0;
        prev = in->fow[k].team_score;
        batter_name(in, k, out[n].bat1);
        batter_name(in, k + 1, out[n].bat2);
        ++n;
    }
    if (in->wickets < 10 && in->total_runs > prev && n < max) {
        out[n].runs = in->total_runs - prev;
        out[n].unbeaten = 1;
        batter_name(in, k, out[n].bat1);
        batter_name(in, k + 1, out[n].bat2);
        ++n;
    }
    return n;
}

/* ---- Awards and result ---- */
typedef struct { char name[NAME_LEN]; int pts, six, wk; } Tally;

static Tally *tally_for(Tally *t, int *n, int cap, const char *name)
{
    int i;
    for (i = 0; i < *n; ++i) if (strcmp(t[i].name, name) == 0) return &t[i];
    if (*n >= cap) return NULL;
    snprintf(t[*n].name, NAME_LEN, "%s", name);
    t[*n].pts = t[*n].six = t[*n].wk = 0;
    return &t[(*n)++];
}

int stats_awards(const Match *m, MatchAwards *out)
{
    Tally t[128], *x;
    int n = 0, i, best = 0;
    size_t k;
    double best_sr = -1.0;

    if (!m || !out) return 0;
    memset(out, 0, sizeof *out);
    snprintf(out->man_of_match, NAME_LEN, "-"); snprintf(out->most_sixes, NAME_LEN, "-");
    snprintf(out->most_wickets, NAME_LEN, "-"); snprintf(out->super_striker, NAME_LEN, "-");

    for (i = 0; i < 2; ++i) {
        const Innings *in = &m->innings[i];
        for (k = 0; k < in->batter_count; ++k) {
            const Player *p = &in->batters[k];
            x = tally_for(t, &n, 128, p->name);
            if (!x) continue;
            x->pts += p->runs; x->six += p->sixes;
            if (p->balls_faced >= STATS_MIN_BALLS_STRIKER && (double)p->runs * 100.0 / p->balls_faced > best_sr) {
                best_sr = (double)p->runs * 100.0 / p->balls_faced;
                snprintf(out->super_striker, NAME_LEN, "%s", p->name);
                out->strike_rate = (float)best_sr;
            }
        }
        for (k = 0; k < in->bowler_count; ++k) {
            const Player *p = &in->bowlers[k];
            x = tally_for(t, &n, 128, p->name);
            if (!x) continue;
            x->wk += p->wickets; x->pts += STATS_POINTS_PER_WICKET * p->wickets;
        }
    }
    for (i = 1; i < n; ++i) if (t[i].pts > t[best].pts) best = i;
    if (n > 0) { snprintf(out->man_of_match, NAME_LEN, "%.49s", t[best].name); out->mom_points = t[best].pts; best = 0; }
    for (i = 1; i < n; ++i) if (t[i].six > t[best].six) best = i;
    if (n > 0 && t[best].six > 0) { snprintf(out->most_sixes, NAME_LEN, "%.49s", t[best].name); out->sixes = t[best].six; }
    best = 0;
    for (i = 1; i < n; ++i) if (t[i].wk > t[best].wk) best = i;
    if (n > 0 && t[best].wk > 0) { snprintf(out->most_wickets, NAME_LEN, "%s", t[best].name); out->wickets = t[best].wk; }
    return 1;
}

int stats_result(const Match *m, char *buf, size_t size)
{
    const Innings *a, *b;
    if (!m || !buf || size == 0) return 0;
    a = &m->innings[0]; b = &m->innings[1];
    if (b->total_runs > a->total_runs) snprintf(buf, size, "%s won by %d wickets", b->batting_team, 10 - b->wickets);
    else if (a->total_runs > b->total_runs) snprintf(buf, size, "%s won by %d runs", a->batting_team, a->total_runs - b->total_runs);
    else snprintf(buf, size, "Match tied");
    return 1;
}
