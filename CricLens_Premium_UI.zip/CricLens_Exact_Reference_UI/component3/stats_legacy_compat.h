#ifndef STATS_LEGACY_COMPAT_H
#define STATS_LEGACY_COMPAT_H
#include "match_model.h"
#define STATS_MIN_BALLS_STRIKER 10
#define STATS_POINTS_PER_WICKET 25
typedef struct { float strike_rate, average, boundary_pct; } BatterStats;
typedef struct { char bat1[NAME_LEN], bat2[NAME_LEN]; int runs, unbeaten; } Partnership;
typedef struct { char man_of_match[NAME_LEN]; int mom_points; char most_sixes[NAME_LEN]; int sixes; char most_wickets[NAME_LEN]; int wickets; char super_striker[NAME_LEN]; float strike_rate; } MatchAwards;
void stats_batter(const Player *, int, BatterStats *);
int stats_over_runs(const Innings *, int *, int);
int stats_cumulative_runs(const Innings *, int *, int);
int stats_over_wickets(const Innings *, int *, int);
int stats_partnerships(const Innings *, Partnership *, int);
int stats_awards(const Match *, MatchAwards *);
int stats_result(const Match *, char *, size_t);
#endif
