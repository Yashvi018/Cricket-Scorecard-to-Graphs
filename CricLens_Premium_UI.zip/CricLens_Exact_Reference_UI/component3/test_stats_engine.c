#include "stats_engine.h"

#include <stdio.h>
#include <string.h>
#include <limits.h>

#define CHECK(condition) do { \
    if (!(condition)) { \
        fprintf(stderr, "FAIL at line %d: %s\n", __LINE__, #condition); \
        return 1; \
    } \
} while (0)

static void clear_innings(Innings *in, Player *batters, Player *bowlers,
                          Over *overs, FallOfWicket *fow)
{
    memset(in, 0, sizeof(*in));
    memset(batters, 0, 2 * sizeof(*batters));
    memset(bowlers, 0, 2 * sizeof(*bowlers));
    memset(overs, 0, 3 * sizeof(*overs));
    memset(fow, 0, 2 * sizeof(*fow));
}

int main(void)
{
    Innings innings, second;
    Player batters[2], bowlers[2];
    Over overs[3];
    FallOfWicket fow[2];
    InningsStats summary;
    BattingStats batting;
    BowlingStats bowling;
    StatsSeries series;
    Match match;
    double required_rate = -1.0;
    char over_text[24];

    clear_innings(&innings, batters, bowlers, overs, fow);
    (void)memset(&second, 0, sizeof(second));
    (void)memset(&match, 0, sizeof(match));

    (void)strcpy(innings.batting_team, "Falcons");
    innings.total_runs = 185;
    innings.wickets = 6;
    innings.legal_balls = 120;

    (void)strcpy(batters[0].name, "A. Player");
    batters[0].runs = 72;
    batters[0].balls_faced = 45;
    batters[0].fours = 6;
    batters[0].sixes = 4;
    (void)strcpy(batters[1].name, "B. Player");
    batters[1].runs = 58;
    batters[1].balls_faced = 40;
    batters[1].fours = 5;
    batters[1].sixes = 2;
    innings.batters = batters;
    innings.batter_count = 2;

    (void)strcpy(bowlers[0].name, "C. Bowler");
    bowlers[0].wickets = 3;
    bowlers[0].balls_bowled = 24;
    bowlers[0].runs_conceded = 25;
    (void)strcpy(bowlers[1].name, "D. Bowler");
    bowlers[1].wickets = 2;
    bowlers[1].balls_bowled = 18;
    bowlers[1].runs_conceded = 20;
    innings.bowlers = bowlers;
    innings.bowler_count = 2;

    overs[0] = (Over){1, 8, 0};
    overs[1] = (Over){2, 12, 1};
    overs[2] = (Over){3, 6, 0};
    innings.overs = overs;
    innings.over_count = 3;

    fow[0].wicket_number = 1;
    fow[0].team_score = 25;
    fow[0].over_number = 3;
    fow[0].ball_in_over = 2;
    (void)strcpy(fow[0].player_out, "Batter X");
    fow[1].wicket_number = 2;
    fow[1].team_score = 44;
    fow[1].over_number = 5;
    fow[1].ball_in_over = 1;
    (void)strcpy(fow[1].player_out, "Batter Y");
    innings.fow = fow;
    innings.fow_count = 2;

    CHECK(stats_validate_innings(&innings) == STATS_OK);
    CHECK(stats_validate_innings(NULL) == STATS_INVALID_ARGUMENT);
    CHECK(stats_innings(&innings, &summary) == STATS_OK);
    CHECK(summary.total_runs == 185 && summary.wickets == 6);
    CHECK(strcmp(summary.overs, "20.0") == 0);
    CHECK(summary.run_rate > 9.24 && summary.run_rate < 9.26);
    CHECK(summary.top_scorer_index == 0);
    CHECK(summary.best_bowler_index == 0);
    CHECK(summary.highest_over_number == 2 && summary.highest_over_runs == 12);
    CHECK(summary.total_fours == 11 && summary.total_sixes == 6);
    CHECK(summary.boundary_runs == 80 && summary.boundary_count == 17);
    CHECK(summary.last_wicket_index == 1);

    CHECK(stats_batting(&batters[0], &batting) == STATS_OK);
    CHECK(batting.boundary_runs == 48 && batting.boundary_count == 10);
    CHECK(batting.strike_rate > 159.99 && batting.strike_rate < 160.01);
    CHECK(stats_batting(NULL, &batting) == STATS_INVALID_ARGUMENT);

    CHECK(stats_bowling(&bowlers[0], &bowling) == STATS_OK);
    CHECK(strcmp(bowling.overs, "4.0") == 0);
    CHECK(bowling.economy > 6.24 && bowling.economy < 6.26);
    CHECK(bowling.bowling_average > 8.33 && bowling.bowling_average < 8.34);
    CHECK(bowling.bowling_strike_rate == 8.0);

    CHECK(stats_format_overs(23, over_text, sizeof(over_text)) == STATS_OK);
    CHECK(strcmp(over_text, "3.5") == 0);
    CHECK(stats_format_overs(0, over_text, sizeof(over_text)) == STATS_OK);
    CHECK(strcmp(over_text, "0.0") == 0);
    CHECK(stats_format_overs(-1, over_text, sizeof(over_text)) == STATS_INVALID_ARGUMENT);
    CHECK(stats_format_overs(12, over_text, 2) == STATS_BUFFER_TOO_SMALL);

    CHECK(stats_required_run_rate(181, 150, 30, &required_rate) == STATS_OK);
    CHECK(required_rate > 6.19 && required_rate < 6.21);
    CHECK(stats_required_run_rate(150, 150, 0, &required_rate) == STATS_OK);
    CHECK(required_rate == 0.0);
    CHECK(stats_required_run_rate(151, 150, 0, &required_rate) == STATS_NO_DATA);
    CHECK(required_rate == 0.0);
    CHECK(stats_required_run_rate(100, 120, 12, &required_rate) == STATS_OK);
    CHECK(required_rate == 0.0);
    CHECK(stats_required_run_rate(-1, 0, 10, &required_rate) == STATS_INVALID_ARGUMENT);
    CHECK(stats_required_run_rate(1, 0, 10, NULL) == STATS_INVALID_ARGUMENT);

    stats_series_init(&series);
    CHECK(stats_graph_runs_per_over(&innings, &series) == STATS_OK);
    CHECK(series.count == 3 && series.points[1].x == 2 && series.points[1].y == 12);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_wickets_per_over(&innings, &series) == STATS_OK);
    CHECK(series.count == 3 && series.points[1].y == 1);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_cumulative_runs(&innings, &series) == STATS_OK);
    CHECK(series.count == 3 && series.points[2].y == 26);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_batter_runs(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y == 72);
    CHECK(strcmp(series.points[0].label, "A. Player") == 0);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_batter_strike_rates(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y > 159.99);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_bowler_wickets(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y == 3);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_bowler_economy(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y > 6.24);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_fall_of_wickets(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[1].x == 44 && series.points[1].y == 2);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_boundaries(&innings, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y == 11 && series.points[1].y == 6);
    stats_series_free(&series);

    (void)strcpy(second.batting_team, "Tigers");
    second.total_runs = 172;
    second.wickets = 8;
    second.legal_balls = 120;
    match.innings[0] = innings;
    match.innings[1] = second;
    stats_series_init(&series);
    CHECK(stats_graph_innings_runs_comparison(&match, &series) == STATS_OK);
    CHECK(series.count == 2 && series.points[0].y == 185 && series.points[1].y == 172);
    CHECK(strcmp(series.points[1].label, "Tigers") == 0);
    stats_series_free(&series);

    stats_series_init(&series);
    CHECK(stats_graph_innings_wickets_comparison(&match, &series) == STATS_OK);
    CHECK(series.points[0].y == 6 && series.points[1].y == 8);
    stats_series_free(&series);

    /* Empty data is reported explicitly rather than producing invalid rates. */
    {
        Player no_balls;
        (void)memset(&no_balls, 0, sizeof(no_balls));
        (void)strcpy(no_balls.name, "No balls");
        CHECK(stats_batting(&no_balls, &batting) == STATS_NO_DATA);
        CHECK(batting.strike_rate == 0.0);
        CHECK(stats_bowling(&no_balls, &bowling) == STATS_NO_DATA);
        CHECK(bowling.economy == 0.0);
    }

    /* Invalid player and fall-of-wicket records must be rejected. */
    batters[0].fours = 100;
    CHECK(stats_validate_innings(&innings) == STATS_INVALID_DATA);
    batters[0].fours = 6;
    fow[1].player_out[0] = '\0';
    CHECK(stats_validate_innings(&innings) == STATS_INVALID_DATA);
    fow[1].player_out[0] = 'B';
    fow[1].player_out[1] = '\0';
    fow[1].wicket_number = 1;
    CHECK(stats_validate_innings(&innings) == STATS_INVALID_DATA);

    /* No graph data returns STATS_NO_DATA and leaves an empty series safe. */
    {
        Innings empty;
        (void)memset(&empty, 0, sizeof(empty));
        (void)strcpy(empty.batting_team, "Empty");
        stats_series_init(&series);
        CHECK(stats_graph_runs_per_over(&empty, &series) == STATS_NO_DATA);
        CHECK(series.points == NULL && series.count == 0);
        stats_series_free(&series);
    }

    puts("All Component 3 tests passed.");
    return 0;
}
