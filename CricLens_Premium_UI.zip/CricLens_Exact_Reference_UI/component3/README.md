# Component 3 — Cricket Statistics Engine

## Purpose

Component 3 calculates cricket statistics from the match structures defined by
Component 2 and prepares graph-ready data series for Component 4. It performs
calculations and validation; it does **not** draw or render graphs.

The module is written in standard C (C99) and is designed to compile separately
from the application's user-interface and graph-rendering code.

## Files in this submission

| File | Purpose |
|---|---|
| `stats_engine.h` | Public API, result structures, status codes and function declarations |
| `stats_engine.c` | Statistics calculations, validation and graph-series generation |
| `test_stats_engine.c` | Standalone automated tests for the statistics engine |
| `match_model.h` | Interface snapshot of the Component 2 data structures required to compile this component |
| `Makefile` | Reproducible build, test and cleanup commands |

### Dependency note

`match_model.h` is included so this Component 3 folder can be built and tested
independently. In the complete project, use the team's authoritative
`match_model.h` from Component 2. Do not maintain two conflicting definitions
of `Player`, `Over`, `FallOfWicket`, `Innings` or `Match`.

Component 1's input parser is separate from this module. Component 3 consumes
the structured `Match` / `Innings` model produced using Component 2; it does
not consume Component 1's simple `Dataset` directly.

## Features

### 1. Input-data validation

`stats_validate_innings()` checks the fields used by the statistics engine,
including player names and non-negative statistics, boundary consistency,
over ordering, and fall-of-wicket consistency. Invalid or inconsistent
records are reported through a `StatsStatus` return value rather than being
silently used in calculations.

### 2. Batting statistics

`stats_batting()` calculates:
- Strike rate: `(runs / balls faced) * 100`
- Boundary runs: `4 * fours + 6 * sixes`
- Boundary count: `fours + sixes`

### 3. Bowling statistics

`stats_bowling()` calculates:
- Overs in cricket notation (for example, 3 overs and 4 balls is `3.4`)
- Economy rate: runs conceded per 6 legal balls
- Bowling average: runs conceded per wicket
- Bowling strike rate: legal balls per wicket

### 4. Innings summary

`stats_innings()` calculates the innings totals and run rate, boundary totals,
highest-scoring over, top-scorer index, best-bowler index and last fall-of-wicket
index. Indices refer to the corresponding arrays in the supplied `Innings`.

### 5. Required run rate

`stats_required_run_rate()` calculates the runs-per-over rate required to reach
a target using the number of legal balls remaining. It reports `STATS_NO_DATA`
when runs are still required but no balls remain.

### 6. Graph-ready series for Component 4

The module can create series for:
- Runs per over
- Wickets per over
- Cumulative runs
- Batter runs
- Batter strike rates
- Bowler wickets
- Bowler economy
- Fall of wickets
- Fours and sixes
- Two-innings runs comparison
- Two-innings wickets comparison

Each series is represented by `StatsSeries`, containing a title, a point array
and a count. Each `StatsPoint` contains numeric `x` and `y` values and a label.
Component 4 can map these points to its own graph-rendering structures.

## Build and test

### Requirements

- GCC or another C99-compatible C compiler
- GNU Make (optional; direct compiler commands are also provided)

### Recommended test (GCC)

From a terminal, change into this folder and run:

```sh
gcc -std=c99 -Wall -Wextra -Werror -pedantic \
    stats_engine.c test_stats_engine.c -o test_stats_engine
./test_stats_engine
```

Expected successful output:

```text
All Component 3 tests passed.
```

The strict compiler flags make warnings fail the build, which helps catch
potential portability and correctness issues.

### Using the Makefile

```sh
make test
```

To compile the production implementation as an object file:

```sh
make stats_engine.o
```

To remove generated binaries and object files:

```sh
make clean
```

On Windows, these commands can be run in a terminal with GCC installed
(for example, MinGW-w64). If `make` is unavailable, use the direct GCC command.

## Integration into the full project

1. Ensure the application includes the authoritative Component 2
   `match_model.h` in its include path.
2. Add `stats_engine.c` to the application build.
3. Include `stats_engine.h` wherever statistics are required.
4. Pass a valid `Innings` or `Match` from Component 2 to the relevant function.
5. For graph output, initialize a `StatsSeries` before building it, then pass
   `series.points` and `series.count` to an adapter for Component 4.
6. Release the series when finished.

Example:

```c
#include "stats_engine.h"

void prepare_runs_graph(const Innings *innings)
{
    StatsSeries series;
    StatsStatus status;

    stats_series_init(&series);

    status = stats_graph_runs_per_over(innings, &series);
    if (status == STATS_OK) {
        /* Adapt series.points / series.count to Component 4 here. */
    }

    stats_series_free(&series);
}
```

**Memory ownership:** `StatsSeries` owns its allocated `points` after a
successful graph-series build. Call `stats_series_free()` when finished.
Always call `stats_series_init()` before the first use of a `StatsSeries`.

**Testing vs application build:** `test_stats_engine.c` contains its own
`main()` function. Compile it for testing only; do not add it to the final
application build.

## Status codes

- `STATS_OK` — operation completed successfully
- `STATS_NO_DATA` — calculation is not meaningful with the available data
- `STATS_INVALID_ARGUMENT` — a required pointer or argument is invalid
- `STATS_INVALID_DATA` — supplied match data is inconsistent or invalid
- `STATS_BUFFER_TOO_SMALL` — caller-provided output buffer is too small
- `STATS_NO_MEMORY` — memory allocation failed

## Scope and integration boundary

This submission implements Component 3 only. It does not replace Components 1,
2 or 4, and it does not claim that the complete multi-component application has
been integrated or tested. The included tests exercise the statistics engine
against the Component 2 model interface snapshot included here. Before final
team integration, compile the entire project using the team's shared headers
and Component 4 adapter.
