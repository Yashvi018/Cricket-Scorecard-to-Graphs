#include "stats_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

static int safe_name(const char *s, size_t cap)
{
    return s != NULL && memchr(s, '\0', cap) != NULL && s[0] != '\0';
}

static int valid_player(const Player *p)
{
    long long boundary_runs;
    if (!p || !safe_name(p->name, sizeof(p->name))) return 0;
    if (p->runs < 0 || p->balls_faced < 0 || p->fours < 0 ||
        p->sixes < 0 || p->wickets < 0 || p->balls_bowled < 0 ||
        p->runs_conceded < 0) return 0;
    boundary_runs = 4LL * p->fours + 6LL * p->sixes;
    if (boundary_runs > p->runs) return 0;
    if (p->fours > p->balls_faced || p->sixes > p->balls_faced ||
        p->fours + (long long)p->sixes > p->balls_faced) return 0;
    return 1;
}

StatsStatus stats_validate_innings(const Innings *in)
{
    size_t i;
    if (!in) return STATS_INVALID_ARGUMENT;
    if (!safe_name(in->batting_team, sizeof(in->batting_team)))
        return STATS_INVALID_DATA;
    if (in->total_runs < 0 || in->wickets < 0 || in->wickets > 10 ||
        in->legal_balls < 0) return STATS_INVALID_DATA;
    if (in->batter_count > (size_t)INT_MAX ||
        in->bowler_count > (size_t)INT_MAX ||
        in->fow_count > (size_t)INT_MAX) return STATS_INVALID_DATA;
    if ((in->batter_count && !in->batters) ||
        (in->bowler_count && !in->bowlers) ||
        (in->over_count && !in->overs) ||
        (in->fow_count && !in->fow)) return STATS_INVALID_DATA;

    for (i = 0; i < in->batter_count; ++i)
        if (!valid_player(&in->batters[i])) return STATS_INVALID_DATA;
    for (i = 0; i < in->bowler_count; ++i)
        if (!valid_player(&in->bowlers[i])) return STATS_INVALID_DATA;

    for (i = 0; i < in->over_count; ++i) {
        const Over *o = &in->overs[i];
        if (o->over_number < 1 || o->runs < 0 || o->wickets < 0 ||
            o->wickets > 10) return STATS_INVALID_DATA;
        if (i && o->over_number <= in->overs[i - 1].over_number)
            return STATS_INVALID_DATA;
    }
    if (in->fow_count > (size_t)in->wickets) return STATS_INVALID_DATA;
    for (i = 0; i < in->fow_count; ++i) {
        const FallOfWicket *w = &in->fow[i];
        if (w->wicket_number < 1 || w->wicket_number > in->wickets ||
            w->team_score < 0 || w->team_score > in->total_runs ||
            w->over_number < 0 || w->ball_in_over < 0 ||
            w->ball_in_over > 6 ||
            !safe_name(w->player_out, sizeof(w->player_out)))
            return STATS_INVALID_DATA;
        if (i && w->wicket_number <= in->fow[i - 1].wicket_number)
            return STATS_INVALID_DATA;
    }
    return STATS_OK;
}

StatsStatus stats_format_overs(int legal_balls, char *buffer, size_t size)
{
    int n;
    if (!buffer || size == 0 || legal_balls < 0)
        return STATS_INVALID_ARGUMENT;
    n = snprintf(buffer, size, "%d.%d", legal_balls / 6, legal_balls % 6);
    if (n < 0 || (size_t)n >= size) return STATS_BUFFER_TOO_SMALL;
    return STATS_OK;
}

StatsStatus stats_batting(const Player *p, BattingStats *out)
{
    long long br;
    if (!p || !out) return STATS_INVALID_ARGUMENT;
    memset(out, 0, sizeof(*out));
    if (!valid_player(p)) return STATS_INVALID_DATA;
    br = 4LL * p->fours + 6LL * p->sixes;
    out->strike_rate = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
    out->boundary_runs = (int)br;
    out->boundary_count = p->fours + p->sixes;
    return p->balls_faced ? STATS_OK : STATS_NO_DATA;
}

StatsStatus stats_bowling(const Player *p, BowlingStats *out)
{
    int n;
    if (!p || !out) return STATS_INVALID_ARGUMENT;
    memset(out, 0, sizeof(*out));
    if (!valid_player(p)) return STATS_INVALID_DATA;
    n = snprintf(out->overs, sizeof(out->overs), "%d.%d",
                 p->balls_bowled / 6, p->balls_bowled % 6);
    if (n < 0 || (size_t)n >= sizeof(out->overs)) return STATS_BUFFER_TOO_SMALL;
    out->economy = p->balls_bowled
        ? 6.0 * p->runs_conceded / p->balls_bowled : 0.0;
    out->bowling_average = p->wickets
        ? (double)p->runs_conceded / p->wickets : 0.0;
    out->bowling_strike_rate = p->wickets
        ? (double)p->balls_bowled / p->wickets : 0.0;
    if (p->balls_bowled == 0 && p->wickets == 0) return STATS_NO_DATA;
    return STATS_OK;
}

StatsStatus stats_required_run_rate(int target, int current, int balls, double *out)
{
    int needed;
    if (!out) return STATS_INVALID_ARGUMENT;
    *out = 0.0;
    if (target < 0 || current < 0 || balls < 0)
        return STATS_INVALID_ARGUMENT;
    needed = target - current;
    if (needed <= 0) { *out = 0.0; return STATS_OK; }
    if (balls == 0) { *out = 0.0; return STATS_NO_DATA; }
    *out = 6.0 * needed / balls;
    return STATS_OK;
}

StatsStatus stats_innings(const Innings *in, InningsStats *out)
{
    size_t i;
    StatsStatus st;
    long long fours = 0, sixes = 0;
    int top = -1, best = -1, highest_runs = -1, highest_over = -1;
    if (!out) return STATS_INVALID_ARGUMENT;
    st = stats_validate_innings(in);
    if (st != STATS_OK) return st;
    memset(out, 0, sizeof(*out));
    out->top_scorer_index = -1;
    out->best_bowler_index = -1;
    out->last_wicket_index = -1;
    out->total_runs = in->total_runs;
    out->wickets = in->wickets;
    out->legal_balls = in->legal_balls;
    (void)stats_format_overs(in->legal_balls, out->overs, sizeof(out->overs));
    out->run_rate = in->legal_balls
        ? 6.0 * in->total_runs / in->legal_balls : 0.0;

    for (i = 0; i < in->batter_count; ++i) {
        const Player *p = &in->batters[i];
        if (fours > LLONG_MAX - p->fours ||
            sixes > LLONG_MAX - p->sixes) return STATS_INVALID_DATA;
        fours += p->fours;
        sixes += p->sixes;
        if (top < 0 || p->runs > in->batters[top].runs) top = (int)i;
    }
    if (fours > INT_MAX || sixes > INT_MAX) return STATS_INVALID_DATA;
    out->total_fours = (int)fours;
    out->total_sixes = (int)sixes;
    if (4LL * fours + 6LL * sixes > INT_MAX) return STATS_INVALID_DATA;
    out->boundary_runs = (int)(4LL * fours + 6LL * sixes);
    if (fours + sixes > INT_MAX) return STATS_INVALID_DATA;
    out->boundary_count = (int)(fours + sixes);
    out->top_scorer_index = top;

    for (i = 0; i < in->bowler_count; ++i) {
        const Player *p = &in->bowlers[i];
        if (p->wickets > 0 &&
            (best < 0 || p->wickets > in->bowlers[best].wickets ||
             (p->wickets == in->bowlers[best].wickets &&
              p->runs_conceded < in->bowlers[best].runs_conceded)))
            best = (int)i;
    }
    out->best_bowler_index = best;

    for (i = 0; i < in->over_count; ++i) {
        if (in->overs[i].runs > highest_runs) {
            highest_runs = in->overs[i].runs;
            highest_over = in->overs[i].over_number;
        }
    }
    out->highest_over_runs = highest_runs < 0 ? 0 : highest_runs;
    out->highest_over_number = highest_over;
    if (in->fow_count) out->last_wicket_index = (int)(in->fow_count - 1);
    return STATS_OK;
}

void stats_series_init(StatsSeries *s)
{
    if (!s) return;
    s->title[0] = '\0';
    s->points = NULL;
    s->count = 0;
}

void stats_series_free(StatsSeries *s)
{
    if (!s) return;
    free(s->points);
    stats_series_init(s);
}

static StatsStatus series_allocate(StatsSeries *out, const char *title, size_t count)
{
    StatsPoint *p = NULL;
    if (!out || !title) return STATS_INVALID_ARGUMENT;
    if (count) {
        if (count > (size_t)-1 / sizeof(*p)) return STATS_NO_MEMORY;
        p = (StatsPoint *)calloc(count, sizeof(*p));
        if (!p) return STATS_NO_MEMORY;
    }
    free(out->points);
    out->points = p;
    out->count = count;
    (void)snprintf(out->title, sizeof(out->title), "%s", title);
    return STATS_OK;
}

static StatsStatus validate_for_graph(const Innings *in, StatsSeries *out)
{
    if (!out) return STATS_INVALID_ARGUMENT;
    return stats_validate_innings(in);
}

StatsStatus stats_graph_runs_per_over(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Runs per over", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = in->overs[i].runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "Over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_wickets_per_over(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Wickets per over", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = in->overs[i].wickets;
        (void)snprintf(out->points[i].label, NAME_LEN, "Over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_cumulative_runs(const Innings *in, StatsSeries *out)
{
    size_t i;
    long long total = 0;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Cumulative runs", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        if (total > LLONG_MAX - (long long)in->overs[i].runs) {
            stats_series_free(out);
            return STATS_INVALID_DATA;
        }
        total += in->overs[i].runs;
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = (double)total;
        (void)snprintf(out->points[i].label, NAME_LEN, "After over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_batter_runs(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    st = series_allocate(out, "Batter runs", in->batter_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->batter_count; ++i) {
        out->points[i].x = (double)(i + 1);
        out->points[i].y = in->batters[i].runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->batters[i].name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_batter_strike_rates(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    st = series_allocate(out, "Batter strike rates", in->batter_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->batter_count; ++i) {
        const Player *p = &in->batters[i];
        out->points[i].x = (double)(i + 1);
        out->points[i].y = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", p->name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_bowler_wickets(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->bowler_count) return STATS_NO_DATA;
    st = series_allocate(out, "Bowler wickets", in->bowler_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->bowler_count; ++i) {
        out->points[i].x = (double)(i + 1);
        out->points[i].y = in->bowlers[i].wickets;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->bowlers[i].name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_bowler_economy(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->bowler_count) return STATS_NO_DATA;
    st = series_allocate(out, "Bowler economy", in->bowler_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->bowler_count; ++i) {
        const Player *p = &in->bowlers[i];
        out->points[i].x = (double)(i + 1);
        out->points[i].y = p->balls_bowled
            ? 6.0 * p->runs_conceded / p->balls_bowled : 0.0;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", p->name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_fall_of_wickets(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->fow_count) return STATS_NO_DATA;
    st = series_allocate(out, "Fall of wickets", in->fow_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->fow_count; ++i) {
        out->points[i].x = in->fow[i].team_score;
        out->points[i].y = in->fow[i].wicket_number;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->fow[i].player_out);
    }
    return STATS_OK;
}

StatsStatus stats_graph_boundaries(const Innings *in, StatsSeries *out)
{
    long long fours = 0, sixes = 0;
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    for (i = 0; i < in->batter_count; ++i) {
        if (fours > LLONG_MAX - in->batters[i].fours ||
            sixes > LLONG_MAX - in->batters[i].sixes) return STATS_INVALID_DATA;
        fours += in->batters[i].fours;
        sixes += in->batters[i].sixes;
    }
    st = series_allocate(out, "Fours and sixes", 2);
    if (st != STATS_OK) return st;
    out->points[0].x = 1; out->points[0].y = (double)fours;
    (void)snprintf(out->points[0].label, NAME_LEN, "Fours");
    out->points[1].x = 2; out->points[1].y = (double)sixes;
    (void)snprintf(out->points[1].label, NAME_LEN, "Sixes");
    return STATS_OK;
}

static StatsStatus innings_comparison(const Match *m, StatsSeries *out, int wickets)
{
    int i;
    StatsStatus st;
    if (!m || !out) return STATS_INVALID_ARGUMENT;
    for (i = 0; i < 2; ++i) {
        st = stats_validate_innings(&m->innings[i]);
        if (st != STATS_OK) return st;
    }
    st = series_allocate(out, wickets ? "Innings wickets comparison" :
                         "Innings runs comparison", 2);
    if (st != STATS_OK) return st;
    for (i = 0; i < 2; ++i) {
        const Innings *in = &m->innings[i];
        out->points[i].x = i + 1;
        out->points[i].y = wickets ? in->wickets : in->total_runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "%.49s", in->batting_team);
    }
    return STATS_OK;
}

StatsStatus stats_graph_innings_runs_comparison(const Match *m, StatsSeries *out)
{
    return innings_comparison(m, out, 0);
}

StatsStatus stats_graph_innings_wickets_comparison(const Match *m, StatsSeries *out)
{
    return innings_comparison(m, out, 1);
}

StatsStatus stats_print_innings_report(const Innings *in)
{
    InningsStats s;
    StatsStatus st = stats_innings(in, &s);
    size_t i;
    if (st != STATS_OK) return st;

    printf("\n========== %s: INNINGS REPORT ==========\n", in->batting_team);
    printf("Score             : %d/%d\n", s.total_runs, s.wickets);
    printf("Overs             : %s\n", s.overs);
    printf("Run rate          : %.2f\n", s.run_rate);
    printf("Fours / Sixes     : %d / %d\n", s.total_fours, s.total_sixes);
    printf("Boundary runs     : %d (%d boundaries)\n",
           s.boundary_runs, s.boundary_count);
    if (s.top_scorer_index >= 0) {
        const Player *p = &in->batters[s.top_scorer_index];
        BattingStats bs;
        StatsStatus bst = stats_batting(p, &bs);
        printf("Top scorer        : %s - %d (%d balls)",
               p->name, p->runs, p->balls_faced);
        if (bst == STATS_OK) printf(", SR %.2f", bs.strike_rate);
        printf("\n");
    } else printf("Top scorer        : unavailable\n");

    if (s.best_bowler_index >= 0) {
        const Player *p = &in->bowlers[s.best_bowler_index];
        BowlingStats bw;
        StatsStatus bws = stats_bowling(p, &bw);
        printf("Best bowler       : %s - %d wicket(s)",
               p->name, p->wickets);
        if (bws == STATS_OK) printf(", economy %.2f", bw.economy);
        printf("\n");
    } else printf("Best bowler       : unavailable\n");

    if (s.highest_over_number >= 0)
        printf("Highest-scoring over: Over %d (%d runs)\n",
               s.highest_over_number, s.highest_over_runs);
    if (s.last_wicket_index >= 0) {
        const FallOfWicket *w = &in->fow[s.last_wicket_index];
        printf("Last wicket       : %s, %d/%d at %d.%d\n",
               w->player_out, w->wicket_number, w->team_score,
               w->over_number, w->ball_in_over);
    } else printf("Last wicket       : unavailable\n");

    if (in->batter_count) {
        printf("\nBATTING\n");
        printf("%-20s %6s %6s %6s %6s %8s\n",
               "Player", "Runs", "Balls", "4s", "6s", "SR");
        for (i = 0; i < in->batter_count; ++i) {
            const Player *p = &in->batters[i];
            double sr = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
            printf("%-20.20s %6d %6d %6d %6d %8.2f\n",
                   p->name, p->runs, p->balls_faced,
                   p->fours, p->sixes, sr);
        }
    }
    if (in->bowler_count) {
        printf("\nBOWLING\n");
        printf("%-20s %7s %7s %7s %8s %8s\n",
               "Player", "Overs", "Runs", "Wkts", "Econ", "Avg");
        for (i = 0; i < in->bowler_count; ++i) {
            const Player *p = &in->bowlers[i];
            BowlingStats bw;
            (void)stats_bowling(p, &bw);
            printf("%-20.20s %7s %7d %7d %8.2f %8.2f\n",
                   p->name, bw.overs, p->runs_conceded, p->wickets,
                   bw.economy, bw.bowling_average);
        }
    }
    printf("========================================\n");
    return STATS_OK;
}
