#include <stdio.h>
#include <string.h>
#include "stats_legacy_compat.h"

#define CHECK(x) do { if (!(x)) { \
    fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #x); return 1; \
} } while (0)

int main(void)
{
    Player batter;
    Over overs[3];
    Innings innings;
    BatterStats batting;
    int runs[3], cumulative[3], wickets[3];

    memset(&batter, 0, sizeof(batter));
    memset(&innings, 0, sizeof(innings));
    strcpy(batter.name, "Test Batter");
    batter.runs = 60;
    batter.balls_faced = 30;
    batter.fours = 9;
    batter.sixes = 4;

    strcpy(innings.batting_team, "Test XI");
    innings.total_runs = 80;
    innings.wickets = 2;
    innings.legal_balls = 18;
    innings.batters = &batter;
    innings.batter_count = 1;
    overs[0] = (Over){1, 8, 0};
    overs[1] = (Over){2, 12, 1};
    overs[2] = (Over){3, 6, 1};
    innings.overs = overs;
    innings.over_count = 3;

    stats_batter(&batter, 1, &batting);
    CHECK(batting.strike_rate > 199.9f && batting.strike_rate < 200.1f);
    CHECK(batting.average == 60.0f);
    CHECK(batting.boundary_pct == 100.0f);

    CHECK(stats_over_runs(&innings, runs, 3) == 3);
    CHECK(runs[0] == 8 && runs[1] == 12 && runs[2] == 6);
    CHECK(stats_cumulative_runs(&innings, cumulative, 3) == 3);
    CHECK(cumulative[0] == 8 && cumulative[1] == 20 && cumulative[2] == 26);
    CHECK(stats_over_wickets(&innings, wickets, 3) == 3);
    CHECK(wickets[0] == 0 && wickets[1] == 1 && wickets[2] == 1);

    puts("Legacy Component 5 compatibility tests passed.");
    return 0;
}
