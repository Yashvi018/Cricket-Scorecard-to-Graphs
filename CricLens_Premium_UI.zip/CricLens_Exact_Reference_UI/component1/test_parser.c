/* Demo for Component 1.
   ./test_parser scores.csv              reads "name, score" lines from a file
   ./test_parser                         type "name, score" lines in
   ./test_parser --match sample_match.txt  reads a full scorecard into the Match model */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "component1_input_parser.h"
#include "component1_match_loader.h"
#include "match_store.h"

int main(int argc, char **argv)
{
    Dataset ds;
    Match m;
    char err[200];
    int n;
    size_t i;

    if (argc > 2 && strcmp(argv[1], "--match") == 0) {
        memset(&m, 0, sizeof m);
        if (!load_match_file(argv[2], &m, err, sizeof err)) {
            printf("Error: %s\n", err);
            return EXIT_FAILURE;
        }
        printf("Loaded %s: %s v %s at %s\n", m.match_id, m.team1, m.team2, m.venue);
        for (i = 0; i < 2; ++i)
            printf("  %s %d/%d, %zu batters, %zu bowlers, %zu overs, %zu wickets\n", m.innings[i].batting_team,
                   m.innings[i].total_runs, m.innings[i].wickets, m.innings[i].batter_count,
                   m.innings[i].bowler_count, m.innings[i].over_count, m.innings[i].fow_count);
        match_free(&m);
        return EXIT_SUCCESS;
    }

    dataset_init(&ds);
    n = (argc > 1) ? load_file(argv[1], &ds) : load_interactive(&ds);
    if (n <= 0) {
        fprintf(stderr, "No valid data was read.\n");
        dataset_free(&ds);
        return EXIT_FAILURE;
    }
    printf("\nParsed %d entr%s:\n%-4s %-*s %s\n", n, n == 1 ? "y" : "ies", "#", MAX_LABEL, "Label", "Value");
    for (i = 0; i < ds.count; ++i)
        printf("%-4zu %-*s %.2f\n", i + 1, MAX_LABEL, ds.points[i].label, ds.points[i].value);
    dataset_free(&ds);
    return EXIT_SUCCESS;
}
