#ifndef COMPONENT1_MATCH_LOADER_H
#define COMPONENT1_MATCH_LOADER_H
/* Component 1 addition: reads a full scorecard text file into the Component 2 Match model.

   File format: one record per line, comma separated, '#' starts a comment.
     MATCH,match_id,team1,team2,venue,date
     INNINGS,n,batting_team,total_runs,wickets,legal_balls          (n is 1 or 2)
     BATTER,n,name,runs,balls_faced,fours,sixes
     BOWLER,n,name,wickets,balls_bowled,runs_conceded
     OVER,n,over_number,runs,wickets
     FOW,n,wicket_number,team_score,over_number,ball_in_over,player_out
   The MATCH line must come first. Names must not contain commas.
   The finished Match is checked with match_validate(). */

#include <stddef.h>
#include "match_model.h"

/* Returns 1 on success (caller must call match_free on *match, which must be zeroed beforehand)
   or 0 on failure, with a message such as "line 7: runs must be a whole number" in error. */
int load_match_file(const char *path, Match *match, char *error, size_t error_size);

#endif
