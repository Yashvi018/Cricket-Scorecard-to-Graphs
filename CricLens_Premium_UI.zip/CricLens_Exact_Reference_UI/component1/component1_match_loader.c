#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "component1_match_loader.h"
#include "match_store.h"
#include "match_validate.h"

#define LOADER_LINE   512
#define LOADER_FIELDS 8
#define LOADER_MSG    120

static char *trim(char *s)
{
    char *end;
    while (isspace((unsigned char)*s)) ++s;
    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) --end;
    *end = '\0';
    return s;
}

static int split(char *s, char *f[], int max)
{
    int n = 0, i;
    f[n++] = s;
    for (; *s && n < max; ++s) {
        if (*s == ',') { *s = '\0'; f[n++] = s + 1; }
    }
    for (i = 0; i < n; ++i) f[i] = trim(f[i]);
    return n;
}

static int num(const char *s, int *out)
{
    char *end;
    long v;
    if (*s == '\0') return 0;
    v = strtol(s, &end, 10);
    if (*end != '\0' || v < 0 || v > 1000000L) return 0;
    *out = (int)v;
    return 1;
}

static int copy_text(char *dst, size_t size, const char *src)
{
    if (strlen(src) >= size) return 0;
    strcpy(dst, src);
    return 1;
}

static int bad(char *msg, const char *text)
{
    snprintf(msg, LOADER_MSG, "%s", text);
    return 0;
}

static int parse_record(Match *m, char *f[], int n, int *have_match, char *msg)
{
    Innings *in;
    int idx, c;

    if (strcmp(f[0], "MATCH") == 0) {
        if (n != 6) return bad(msg, "MATCH needs 5 fields: id, team1, team2, venue, date");
        if (!copy_text(m->match_id, MATCH_ID_LEN, f[1]) || !copy_text(m->team1, NAME_LEN, f[2]) ||
            !copy_text(m->team2, NAME_LEN, f[3]) || !copy_text(m->venue, VENUE_LEN, f[4]) ||
            !copy_text(m->date, DATE_LEN, f[5]))
            return bad(msg, "a MATCH field is too long");
        *have_match = 1;
        return 1;
    }
    if (!*have_match) return bad(msg, "the MATCH line must come first");
    if (n < 2 || !num(f[1], &idx) || idx < 1 || idx > 2) return bad(msg, "innings number must be 1 or 2");
    in = &m->innings[idx - 1];

    if (strcmp(f[0], "INNINGS") == 0) {
        if (n != 6) return bad(msg, "INNINGS needs 5 fields");
        if (!copy_text(in->batting_team, NAME_LEN, f[2])) return bad(msg, "batting team name too long");
        if (!num(f[3], &in->total_runs) || !num(f[4], &in->wickets) || !num(f[5], &in->legal_balls))
            return bad(msg, "runs, wickets and balls must be whole numbers");
        return 1;
    }
    if (strcmp(f[0], "BATTER") == 0 || strcmp(f[0], "BOWLER") == 0) {
        int is_bat = (f[0][1] == 'A');
        Player *np, *p;
        size_t *count = is_bat ? &in->batter_count : &in->bowler_count;
        Player **arr = is_bat ? &in->batters : &in->bowlers;
        if (n != (is_bat ? 7 : 6)) return bad(msg, is_bat ? "BATTER needs 6 fields" : "BOWLER needs 5 fields");
        np = (Player *)realloc(*arr, (*count + 1) * sizeof(Player));
        if (!np) return bad(msg, "out of memory");
        *arr = np;
        p = &np[*count];
        memset(p, 0, sizeof *p);
        (*count)++;
        if (!copy_text(p->name, NAME_LEN, f[2])) return bad(msg, "player name too long");
        if (is_bat) {
            if (!num(f[3], &p->runs) || !num(f[4], &p->balls_faced) || !num(f[5], &p->fours) || !num(f[6], &p->sixes))
                return bad(msg, "batter numbers must be whole numbers");
        } else if (!num(f[3], &p->wickets) || !num(f[4], &p->balls_bowled) || !num(f[5], &p->runs_conceded)) {
            return bad(msg, "bowler numbers must be whole numbers");
        }
        return 1;
    }
    if (strcmp(f[0], "OVER") == 0) {
        Over *np;
        if (n != 5) return bad(msg, "OVER needs 4 fields");
        np = (Over *)realloc(in->overs, (in->over_count + 1) * sizeof(Over));
        if (!np) return bad(msg, "out of memory");
        in->overs = np;
        c = (int)in->over_count++;
        if (!num(f[2], &np[c].over_number) || !num(f[3], &np[c].runs) || !num(f[4], &np[c].wickets))
            return bad(msg, "over numbers must be whole numbers");
        return 1;
    }
    if (strcmp(f[0], "FOW") == 0) {
        FallOfWicket *np, *w;
        if (n != 7) return bad(msg, "FOW needs 6 fields");
        np = (FallOfWicket *)realloc(in->fow, (in->fow_count + 1) * sizeof(FallOfWicket));
        if (!np) return bad(msg, "out of memory");
        in->fow = np;
        w = &np[in->fow_count++];
        memset(w, 0, sizeof *w);
        if (!num(f[2], &w->wicket_number) || !num(f[3], &w->team_score) || !num(f[4], &w->over_number) || !num(f[5], &w->ball_in_over))
            return bad(msg, "fall of wicket numbers must be whole numbers");
        if (!copy_text(w->player_out, NAME_LEN, f[6])) return bad(msg, "player name too long");
        return 1;
    }
    return bad(msg, "unknown record type");
}

static void set_error(char *e, size_t size, int line, const char *msg)
{
    if (!e || size == 0) return;
    if (line > 0) snprintf(e, size, "line %d: %s", line, msg); else snprintf(e, size, "%s", msg);
}

int load_match_file(const char *path, Match *match, char *error, size_t error_size)
{
    FILE *fp;
    char line[LOADER_LINE], msg[LOADER_MSG] = "", verr[160], *f[LOADER_FIELDS], *s;
    int line_no = 0, have_match = 0, ok = 1;
    Match tmp;

    if (!path || !match) { set_error(error, error_size, 0, "missing argument"); return 0; }
    fp = fopen(path, "r");
    if (!fp) { set_error(error, error_size, 0, "cannot open the file"); return 0; }
    memset(&tmp, 0, sizeof tmp);

    while (ok && fgets(line, sizeof line, fp)) {
        ++line_no;
        if (!strchr(line, '\n') && !feof(fp)) { set_error(error, error_size, line_no, "line is too long"); ok = 0; break; }
        s = trim(line);
        if (*s == '\0' || *s == '#') continue;
        if (!parse_record(&tmp, f, split(s, f, LOADER_FIELDS), &have_match, msg)) {
            set_error(error, error_size, line_no, msg);
            ok = 0;
        }
    }
    fclose(fp);
    if (ok && !have_match) { set_error(error, error_size, 0, "the file has no MATCH line"); ok = 0; }
    if (ok && !match_validate(&tmp, verr, sizeof verr)) {
        if (error && error_size) snprintf(error, error_size, "invalid match: %s", verr);
        ok = 0;
    }
    if (!ok) { match_free(&tmp); return 0; }
    *match = tmp;
    return 1;
}
