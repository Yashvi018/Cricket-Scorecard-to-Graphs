/* CricLens native Windows desktop GUI -- plain C, Win32 API + GDI only.
 *
 * Highlights of this interface:
 *   - flicker-free double-buffered rendering, DPI-aware and fully resizable layout
 *   - animated splash screen, count-up scores, animated chart reveals
 *   - anti-aliased chart plots (2x supersampling in GDI, no external libraries)
 *   - interactive charts: hover crosshair + tooltips, wicket markers, average-rate line
 *   - custom navigation bar with hover / pressed / active states and keyboard shortcuts
 *   - runtime-generated application icon, Desktop + Start Menu shortcut installer
 *
 * Data comes from the integrated Components 1-5 through the Component 5 adapter (sg5_*).
 */
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sg5_viz.h"
#include "desktop_shell_win32.h"

#define PI 3.14159265358979323846
#define SSC 2            /* supersampling factor for chart plots */
#define SPLASH_MS 2000
#define ANIM_MS 1100

/* ------------------------------------------------------------------ palette */
#define CL_BG_TOP  RGB(6, 10, 30)
#define CL_BG_BOT  RGB(16, 21, 54)
#define CL_HDR     RGB(8, 15, 42)
#define CL_PANEL   RGB(17, 24, 58)
#define CL_PANEL_B RGB(12, 18, 46)
#define CL_PLOT    RGB(12, 18, 46)
#define CL_EDGE    RGB(62, 72, 116)
#define CL_GRID    RGB(32, 41, 80)
#define CL_TEXT    RGB(242, 240, 252)
#define CL_MUTED   RGB(150, 158, 198)
#define CL_PINK    RGB(255, 86, 120)
#define CL_GOLD    RGB(246, 196, 83)
#define CL_GOLD_DK RGB(150, 112, 40)
#define CL_GREEN   RGB(60, 210, 115)
#define CL_RED     RGB(226, 48, 72)
#define CL_INK     RGB(20, 22, 34)

/* ------------------------------------------------------------------- state */
typedef enum { VIEW_WORM, VIEW_MAN1, VIEW_MAN2, VIEW_PSHIP1, VIEW_PSHIP2, VIEW_AWARDS, VIEW_COUNT } View;
enum { T_PREV, T_NEXT, T_WORM, T_MAN1, T_MAN2, T_PS1, T_PS2, T_AWARDS, T_IMPORT, T_ABOUT, T_COUNT };

static const char *TAB_LABEL[T_COUNT] = {"< Previous", "Next >", "Worm", "Manhattan 1", "Manhattan 2",
                                         "Partnerships 1", "Partnerships 2", "Awards", "Import scorecard", "About"};
static const char *TAB_HINT[T_COUNT] = {
    "Previous match  (Left arrow)", "Next match  (Right arrow)", "Cumulative runs, over by over  (1)",
    "Runs per over, first innings  (2)", "Runs per over, second innings  (3)", "Partnerships, first innings  (4)",
    "Partnerships, second innings  (5)", "Player of the match and special awards  (6)",
    "Load a scorecard text file  (Ctrl+O)", "About CricLens and desktop shortcut  (F1)"};

typedef struct { int margin, hdr_b, nav_t, nav_b, card_t, card_b, res_t, res_b, chart_t, chart_b, status_t; } Lay;
typedef struct { int bx0, by0, bx1, by1, px0, py0, px1, py1, n, ymax, ystep; } Geo;

static HWND g_hwnd;
static HDC g_mem;
static HBITMAP g_membmp;
static HGDIOBJ g_memold;
static int g_w, g_h, g_full;
static double g_s = 1.0;
static WINDOWPLACEMENT g_wp;

static HFONT f_cap, f_capb, f_body, f_bold, f_tab, f_h2, f_mid, f_big, f_title, f_ital, f_rot;
static HICON g_icon_big, g_icon_small;
static unsigned char *g_logo_hdr, *g_logo_splash;

static Sg5Match g_match;
static int g_match_index;
static View g_view = VIEW_WORM;
static DWORD g_t_start, g_t_anim;
static int g_splash = 1;

static RECT g_tab[T_COUNT];
static int g_hot = -1, g_down = -1, g_tracking;
static int g_mx = -1, g_my = -1;

static HBITMAP g_plot;
static int g_plot_w, g_plot_h, g_plot_valid, g_plot_key;

static char g_status[200];
static DWORD g_status_until;

/* ----------------------------------------------------------------- helpers */
static int U(double v) { return (int)(v * g_s + 0.5); }
static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double ease_out(double t) { t = 1.0 - clampd(t, 0, 1); return 1.0 - t * t * t; }
static double ease_back(double t)
{
    const double c1 = 1.70158, c3 = c1 + 1.0;
    t = clampd(t, 0, 1) - 1.0;
    return 1.0 + c3 * t * t * t + c1 * t * t;
}
static COLORREF lerp_col(COLORREF a, COLORREF b, double t)
{
    t = clampd(t, 0, 1);
    return RGB((int)(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t + 0.5),
               (int)(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t + 0.5),
               (int)(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t + 0.5));
}
static COLORREF lighten(COLORREF c, double t) { return lerp_col(c, RGB(255, 255, 255), t); }

static double anim_el(void) { return (double)(GetTickCount() - g_t_anim); }
static double chart_prog(void) { double t = anim_el() / (double)ANIM_MS; return t >= 1.0 ? 1.0 : ease_out(t); }
static void restart_anim(void) { g_t_anim = GetTickCount(); g_plot_valid = 0; }
static void flash(const char *s) { snprintf(g_status, sizeof g_status, "%s", s); g_status_until = GetTickCount() + 5000; }

static HFONT mkfont(int px, int weight, const char *face, int italic, int rot)
{
    return CreateFontA(-px, 0, rot, rot, weight, italic ? TRUE : FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                       OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
}
static void kill_font(HFONT *f) { if (*f) { DeleteObject(*f); *f = NULL; } }
static void kill_all_fonts(void)
{
    kill_font(&f_cap); kill_font(&f_capb); kill_font(&f_body); kill_font(&f_bold); kill_font(&f_tab);
    kill_font(&f_h2); kill_font(&f_mid); kill_font(&f_big); kill_font(&f_title); kill_font(&f_ital); kill_font(&f_rot);
}
static void make_fonts(void)
{
    kill_all_fonts();
    f_cap = mkfont(U(13), FW_NORMAL, "Segoe UI", 0, 0);
    f_capb = mkfont(U(13), FW_BOLD, "Segoe UI", 0, 0);
    f_body = mkfont(U(15), FW_NORMAL, "Segoe UI", 0, 0);
    f_bold = mkfont(U(15), FW_BOLD, "Segoe UI", 0, 0);
    f_tab = mkfont(U(15), FW_SEMIBOLD, "Segoe UI", 0, 0);
    f_h2 = mkfont(U(22), FW_BOLD, "Georgia", 0, 0);
    f_mid = mkfont(U(28), FW_BOLD, "Georgia", 0, 0);
    f_big = mkfont(U(40), FW_BOLD, "Georgia", 0, 0);
    f_title = mkfont(U(40), FW_BOLD, "Georgia", 0, 0);
    f_ital = mkfont(U(17), FW_NORMAL, "Georgia", 1, 0);
    f_rot = mkfont(U(15), FW_NORMAL, "Segoe UI", 0, 900);
}

/* ------------------------------------------------------ drawing primitives */
static void fill(HDC dc, int l, int t, int r, int b, COLORREF c)
{
    RECT rc;
    rc.left = l; rc.top = t; rc.right = r; rc.bottom = b;
    SetBkColor(dc, c);
    ExtTextOutA(dc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
}
static void vgrad(HDC dc, int l, int t, int r, int b, COLORREF c1, COLORREF c2)
{
    int i, h = b - t;
    if (h <= 0) return;
    for (i = 0; i < h; i++) fill(dc, l, t + i, r, t + i + 1, lerp_col(c1, c2, h > 1 ? (double)i / (h - 1) : 0.0));
}
static void line_(HDC dc, int x1, int y1, int x2, int y2, COLORREF c, int w, int style)
{
    HPEN p = CreatePen(style, w, c), old = (HPEN)SelectObject(dc, p);
    SetBkMode(dc, TRANSPARENT);
    MoveToEx(dc, x1, y1, NULL); LineTo(dc, x2, y2);
    SelectObject(dc, old); DeleteObject(p);
}
static void rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void outline_rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF edge, int ew)
{
    HPEN pen = CreatePen(PS_SOLID, ew, edge);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH)), op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
/* Gradient-filled rounded rectangle with an outline. */
static void rrect_grad(HDC dc, int l, int t, int r, int b, int rad, COLORREF c1, COLORREF c2, COLORREF edge, int ew)
{
    HRGN rg = CreateRoundRectRgn(l, t, r + 2, b + 2, rad, rad);
    SelectClipRgn(dc, rg);
    vgrad(dc, l, t, r + 1, b + 1, c1, c2);
    SelectClipRgn(dc, NULL);
    DeleteObject(rg);
    if (ew > 0) outline_rrect(dc, l, t, r, b, rad, edge, ew);
}
static void circle(HDC dc, int cx, int cy, int r, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void ring(HDC dc, int cx, int cy, int r, COLORREF edge, int ew)
{
    HPEN pen = CreatePen(PS_SOLID, ew, edge);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH)), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
static void poly(HDC dc, const POINT *pts, int n, COLORREF fillc, COLORREF edge)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = CreatePen(PS_SOLID, 1, edge);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Polygon(dc, pts, n);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(br); DeleteObject(pen);
}
/* Text anchored at x, vertically centred on yc. align: 0 left, 1 centre, 2 right. */
static void txtc(HDC dc, int x, int yc, const char *s, COLORREF c, HFONT f, int align)
{
    RECT r;
    UINT fm = DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP;
    r.top = yc - U(40); r.bottom = yc + U(40);
    if (align == 1) { r.left = x - 4000; r.right = x + 4000; fm |= DT_CENTER; }
    else if (align == 2) { r.left = x - 8000; r.right = x; fm |= DT_RIGHT; }
    else { r.left = x; r.right = x + 8000; fm |= DT_LEFT; }
    SelectObject(dc, f); SetBkMode(dc, TRANSPARENT); SetTextColor(dc, c);
    DrawTextA(dc, s, -1, &r, fm);
}
static int tw(HDC dc, HFONT f, const char *s)
{
    SIZE z;
    SelectObject(dc, f);
    GetTextExtentPoint32A(dc, s, (int)strlen(s), &z);
    return z.cx;
}
static void txt_rot(HDC dc, int x, int cy, const char *s, COLORREF c)
{
    SIZE z;
    HGDIOBJ o = SelectObject(dc, f_rot);
    GetTextExtentPoint32A(dc, s, (int)strlen(s), &z);
    SetBkMode(dc, TRANSPARENT); SetTextColor(dc, c);
    TextOutA(dc, x, cy + z.cx / 2, s, (int)strlen(s));
    SelectObject(dc, o);
}
static void blit_rgba(HDC dc, const unsigned char *buf, int src, int x, int y, int dim)
{
    BITMAPINFO bi;
    if (!buf || dim < 1) return;
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = src; bi.bmiHeader.biHeight = -src;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    SetStretchBltMode(dc, HALFTONE);
    SetBrushOrgEx(dc, 0, 0, NULL);
    StretchDIBits(dc, x, y, dim, dim, 0, 0, src, src, buf, &bi, DIB_RGB_COLORS, SRCCOPY);
}

/* -------------------------------------------------------------- match data */
static void load_current(void)
{
    if (sg5_load_match(g_match_index, &g_match) != 0) memset(&g_match, 0, sizeof g_match);
    restart_anim();
}
static int runs_at(const InningsPlot *p, int v)
{
    if (v <= 0 || p->overs < 1) return 0;
    if (v > p->overs) return p->total_runs;
    return p->cumulative_runs[v - 1 < SG5_MAX_OVERS ? v - 1 : SG5_MAX_OVERS - 1];
}
static int wkts_at(const InningsPlot *p, int v)
{
    int i, s = 0;
    if (v > p->overs) v = p->overs;
    for (i = 0; i < v && i < SG5_MAX_OVERS; i++) s += p->wicket_in_over[i];
    return s;
}
static void initials(const char *name, char *out)
{
    int n = 0, nw = 1;
    for (; *name && n < 2; name++) {
        if (*name == ' ') { nw = 1; continue; }
        if (nw && isalpha((unsigned char)*name)) out[n++] = (char)toupper((unsigned char)*name);
        nw = 0;
    }
    if (n == 0) out[n++] = '?';
    out[n] = 0;
}
static int is_winner(const InningsPlot *p)
{
    size_t n = strlen(p->team);
    return n > 0 && strncmp(g_match.result, p->team, n) == 0;
}
static void nice_scale(int raw, int *ymax, int *step)
{
    static const int st[] = {5, 10, 20, 25, 50, 100, 200, 250, 500};
    int i;
    if (raw < 1) raw = 1;
    for (i = 0; i < 9; i++) {
        if ((raw + st[i] - 1) / st[i] <= 8) {
            *step = st[i];
            *ymax = ((raw + st[i] - 1) / st[i]) * st[i];
            if (*ymax < st[i]) *ymax = st[i];
            return;
        }
    }
    *step = 1000; *ymax = ((raw + 999) / 1000) * 1000;
}

/* ------------------------------------------------------------------ layout */
static Lay lay(void)
{
    Lay L;
    L.margin = U(18); L.hdr_b = U(96);
    L.nav_t = U(108); L.nav_b = U(148);
    L.card_t = U(160); L.card_b = U(264);
    L.res_t = U(274); L.res_b = U(306);
    L.chart_t = U(318);
    L.status_t = g_h - U(30);
    L.chart_b = L.status_t - U(10);
    return L;
}
static void chart_area(const Lay *L, RECT *r)
{
    r->left = L->margin + U(14); r->right = g_w - L->margin - U(14);
    r->top = L->chart_t + U(58); r->bottom = L->chart_b - U(10);
}
static int tab_is_view(int t) { return t >= T_WORM && t <= T_AWARDS; }

static void compute_tabs(HDC dc, const Lay *L)
{
    int i, total, padx = U(18), gap = U(8), x, avail = g_w - 2 * L->margin, extra;
    int wd[T_COUNT];
    for (;;) {
        total = gap * (T_COUNT - 1) + gap * 2;
        for (i = 0; i < T_COUNT; i++) { wd[i] = tw(dc, f_tab, TAB_LABEL[i]) + 2 * padx; total += wd[i]; }
        if (total <= avail || padx <= U(5)) break;
        padx -= U(2);
    }
    extra = (avail - total) / T_COUNT;
    if (extra > U(14)) extra = U(14);
    if (extra < 0) extra = 0;
    x = L->margin;
    for (i = 0; i < T_COUNT; i++) {
        g_tab[i].left = x; g_tab[i].right = x + wd[i] + extra;
        g_tab[i].top = L->nav_t; g_tab[i].bottom = L->nav_b;
        x = g_tab[i].right + gap;
        if (i == T_NEXT || i == T_AWARDS) x += gap;
    }
}
static int hit_tab(int x, int y)
{
    int i;
    POINT p;
    p.x = x; p.y = y;
    for (i = 0; i < T_COUNT; i++) if (PtInRect(&g_tab[i], p)) return i;
    return -1;
}

/* ----------------------------------------------------------------- tooltip */
static void tooltip(HDC dc, int mx, int my, int n, const char **lines, const COLORREF *cols)
{
    int i, wmax = 0, lh = U(22), pad = U(12), W, H, x, y;
    for (i = 0; i < n; i++) { int w = tw(dc, i == 0 ? f_bold : f_body, lines[i]); if (w > wmax) wmax = w; }
    W = wmax + 2 * pad; H = n * lh + 2 * pad - U(4);
    x = mx + U(18); y = my + U(18);
    if (x + W > g_w - U(8)) x = mx - W - U(18);
    if (x < U(8)) x = U(8);
    if (y + H > g_h - U(8)) y = g_h - U(8) - H;
    rrect(dc, x + U(3), y + U(4), x + W + U(3), y + H + U(4), U(12), RGB(3, 5, 16), RGB(3, 5, 16), 0);
    rrect(dc, x, y, x + W, y + H, U(12), RGB(22, 30, 70), CL_GOLD_DK, 1);
    for (i = 0; i < n; i++)
        txtc(dc, x + pad, y + pad + lh * i + lh / 2 - U(2), lines[i], cols[i], i == 0 ? f_bold : f_body, 0);
}

/* ---------------------------------------------------------- small glyphs */
static void glyph_calendar(HDC dc, int x, int yc, int s)
{
    int t = yc - s / 2;
    rrect(dc, x, t, x + s, t + s, U(4), CL_HDR, CL_GOLD, 2);
    fill(dc, x + 1, t + 1, x + s, t + s / 3, CL_GOLD);
    line_(dc, x + s / 3, t - U(2), x + s / 3, t + U(3), CL_GOLD, 2, PS_SOLID);
    line_(dc, x + 2 * s / 3, t - U(2), x + 2 * s / 3, t + U(3), CL_GOLD, 2, PS_SOLID);
    fill(dc, x + s / 4, t + s / 2, x + s / 4 + U(3), t + s / 2 + U(3), CL_GOLD);
    fill(dc, x + s / 2, t + s / 2, x + s / 2 + U(3), t + s / 2 + U(3), CL_GOLD);
    fill(dc, x + s / 4, t + 3 * s / 4 - U(1), x + s / 4 + U(3), t + 3 * s / 4 + U(2), CL_GOLD);
}
static void glyph_stadium(HDC dc, int x, int yc, int s)
{
    ring(dc, x + s / 2, yc, s / 2, CL_GOLD, 2);
    ring(dc, x + s / 2, yc, s / 4, CL_GOLD, 2);
    line_(dc, x + s / 2 - s / 4, yc, x + s / 2 + s / 4, yc, CL_GOLD, 1, PS_SOLID);
}
static void glyph_bars(HDC dc, int x, int yc, int s)
{
    int w = s / 4, i;
    for (i = 0; i < 3; i++) {
        int h = s * (i + 2) / 5;
        fill(dc, x + i * (w + U(2)), yc + s / 2 - h, x + i * (w + U(2)) + w, yc + s / 2, CL_GOLD);
    }
}
static void draw_ball(HDC dc, int cx, int cy, int r)
{
    circle(dc, cx, cy, r, CL_RED, lighten(CL_RED, 0.2), 1);
    circle(dc, cx - r / 3, cy - r / 3, r / 3, RGB(255, 140, 156), RGB(255, 140, 156), 0);
    line_(dc, cx - r + U(3), cy + r / 3, cx + r - U(3), cy - r / 3, RGB(250, 232, 214), 1, PS_SOLID);
}

/* -------------------------------------------------------------- header/nav */
static void draw_header(HDC dc, const Lay *L)
{
    int m = L->margin, tile = U(68), ty = (L->hdr_b - tile) / 2, tx, divx, tx2, wt, ws, vend;
    char buf[160];
    const char *title = g_match.info.title[0] ? g_match.info.title : "CricLens Match Centre";

    fill(dc, 0, 0, g_w, L->hdr_b, CL_HDR);
    fill(dc, 0, L->hdr_b - U(2), g_w, L->hdr_b, CL_GOLD_DK);
    blit_rgba(dc, g_logo_hdr, 256, m, ty, tile);
    tx = m + tile + U(14);
    txtc(dc, tx, U(34), "CricLens", CL_GOLD, f_title, 0);
    SetTextCharacterExtra(dc, U(2));
    txtc(dc, tx + U(2), U(71), "CRICKET ANALYTICS DESKTOP", CL_TEXT, f_capb, 0);
    ws = tw(dc, f_capb, "CRICKET ANALYTICS DESKTOP");
    SetTextCharacterExtra(dc, 0);
    wt = tw(dc, f_title, "CricLens");
    divx = tx + (wt > ws ? wt : ws) + U(24);
    line_(dc, divx, U(18), divx, L->hdr_b - U(20), CL_GOLD_DK, 2, PS_SOLID);

    tx2 = divx + U(24);
    txtc(dc, tx2, U(34), title, CL_TEXT, f_h2, 0);
    glyph_stadium(dc, tx2, U(70), U(22));
    txtc(dc, tx2 + U(32), U(70), g_match.info.venue, CL_TEXT, f_body, 0);
    vend = tx2 + U(32) + tw(dc, f_body, g_match.info.venue) + U(34);
    glyph_calendar(dc, vend, U(70), U(20));
    snprintf(buf, sizeof buf, "%s", g_match.info.date);
    txtc(dc, vend + U(30), U(70), buf, CL_TEXT, f_body, 0);
    vend += U(30) + tw(dc, f_body, buf);

    if (g_w - m - U(330) > vend + U(20)) {
        int bl = g_w - m - U(320), br = g_w - m, bt = U(16), bb = L->hdr_b - U(18);
        rrect(dc, bl, bt, br, bb, U(14), CL_HDR, CL_GOLD, 2);
        txtc(dc, bl + U(20), (bt + bb) / 2, "Analyze \xB7 Visualize \xB7 Celebrate", CL_GOLD, f_ital, 0);
        line_(dc, br - U(84), (bt + bb) / 2 + U(14), br - U(48), (bt + bb) / 2 + U(2), CL_GOLD_DK, 2, PS_SOLID);
        line_(dc, br - U(76), (bt + bb) / 2 + U(20), br - U(46), (bt + bb) / 2 + U(8), RGB(110, 80, 34), 2, PS_SOLID);
        draw_ball(dc, br - U(38), (bt + bb) / 2, U(17));
    }
}

static void draw_nav(HDC dc, const Lay *L)
{
    int i;
    compute_tabs(dc, L);
    for (i = 0; i < T_COUNT; i++) {
        const RECT *r = &g_tab[i];
        int active = tab_is_view(i) && (i - T_WORM) == (int)g_view;
        int hot = (g_hot == i), down = (g_down == i && hot);
        COLORREF c1, c2, edge, tc;
        if (active) { c1 = RGB(255, 216, 118); c2 = RGB(222, 166, 52); edge = RGB(255, 232, 170); tc = CL_INK; }
        else if (down) { c1 = RGB(14, 22, 50); c2 = RGB(10, 16, 40); edge = CL_GOLD; tc = CL_GOLD; }
        else if (hot) { c1 = RGB(48, 64, 116); c2 = RGB(32, 44, 88); edge = CL_GOLD; tc = CL_TEXT; }
        else { c1 = RGB(30, 42, 80); c2 = RGB(22, 31, 62); edge = RGB(66, 80, 122); tc = CL_TEXT; }
        if (active) rrect(dc, r->left - 2, r->top - 2, r->right + 2, r->bottom + 2, U(14), CL_BG_TOP, CL_GOLD_DK, 1);
        rrect_grad(dc, r->left, r->top, r->right, r->bottom, U(12), c1, c2, edge, 1);
        txtc(dc, (r->left + r->right) / 2, (r->top + r->bottom) / 2 - (down ? 0 : 1), TAB_LABEL[i], tc, active ? f_bold : f_tab, 1);
    }
}

/* ------------------------------------------------------------ score cards */
static void draw_cards(HDC dc, const Lay *L)
{
    int gap = U(16), cw = (g_w - 2 * L->margin - gap) / 2, k;
    double cnt = ease_out(anim_el() / 1100.0);
    for (k = 0; k < 2; k++) {
        const InningsPlot *p = &g_match.in[k];
        int x = L->margin + k * (cw + gap), r = x + cw, t = L->card_t, b = L->card_b, band = U(34);
        COLORREF acc = k ? CL_GOLD : CL_PINK;
        COLORREF b1 = k ? RGB(252, 214, 110) : RGB(240, 60, 108), b2 = k ? RGB(228, 170, 52) : RGB(204, 36, 84);
        COLORREF bt = k ? CL_INK : RGB(255, 255, 255);
        HRGN rg = CreateRoundRectRgn(x, t, r + 2, b + 2, U(16), U(16));
        char buf[160], ini[4];
        int runs = (int)(p->total_runs * cnt + 0.5), wk = (int)(p->wickets * cnt + 0.5);
        double rr = p->balls ? 6.0 * p->total_runs / p->balls : 0.0;
        int win = is_winner(p), bcx = x + U(48), bcy = t + band + (b - t - band) / 2;
        int c_ov = r - U(62), c_rr = r - U(172), sep1 = r - U(226), sep2 = r - U(116);

        SelectClipRgn(dc, rg);
        vgrad(dc, x, t, r + 1, b + 1, RGB(24, 31, 70), RGB(14, 20, 50));
        vgrad(dc, x, t, r + 1, t + band, b1, b2);
        SelectClipRgn(dc, NULL);
        DeleteObject(rg);
        outline_rrect(dc, x, t, r, b, U(16), win ? lighten(acc, 0.25) : lerp_col(acc, CL_PANEL, 0.45), win ? 2 : 1);
        snprintf(buf, sizeof buf, "%s Innings \x96 %s", k ? "2nd" : "1st", p->team);
        txtc(dc, x + cw / 2, t + band / 2, buf, bt, f_h2, 1);
        if (win) {
            int w = tw(dc, f_capb, "WINNER") + U(18);
            rrect(dc, r - w - U(10), t + U(7), r - U(10), t + band - U(7), U(10), b2, bt, 1);
            txtc(dc, r - U(10) - w / 2, t + band / 2, "WINNER", bt, f_capb, 1);
        }
        /* crest with team initials */
        initials(p->team, ini);
        circle(dc, bcx, bcy, U(30), RGB(10, 15, 40), acc, 3);
        circle(dc, bcx, bcy, U(25), lerp_col(acc, CL_PANEL_B, 0.78), lerp_col(acc, CL_PANEL_B, 0.78), 0);
        txtc(dc, bcx, bcy, ini, acc, f_h2, 1);
        /* score, run rate, overs */
        snprintf(buf, sizeof buf, "%d/%d", runs, wk);
        txtc(dc, x + U(92), bcy, buf, CL_TEXT, f_big, 0);
        line_(dc, sep1, t + band + U(14), sep1, b - U(14), CL_EDGE, 1, PS_SOLID);
        line_(dc, sep2, t + band + U(14), sep2, b - U(14), CL_EDGE, 1, PS_SOLID);
        txtc(dc, c_rr, bcy - U(17), "Run Rate", CL_MUTED, f_body, 1);
        snprintf(buf, sizeof buf, "%.2f", rr * cnt);
        txtc(dc, c_rr, bcy + U(13), buf, CL_TEXT, f_mid, 1);
        txtc(dc, c_ov, bcy - U(17), "Overs", CL_MUTED, f_body, 1);
        snprintf(buf, sizeof buf, "%d.%d", p->balls / 6, p->balls % 6);
        txtc(dc, c_ov, bcy + U(13), buf, CL_TEXT, f_mid, 1);
    }
}

static void draw_result(HDC dc, const Lay *L)
{
    char buf[160];
    int w, cx = g_w / 2, cy = (L->res_t + L->res_b) / 2;
    if (!g_match.result[0]) return;
    snprintf(buf, sizeof buf, "%s", g_match.result);
    w = tw(dc, f_bold, buf) + U(86);
    rrect_grad(dc, cx - w / 2, L->res_t, cx + w / 2, L->res_b, U(16), RGB(46, 38, 22), RGB(30, 26, 22), CL_GOLD_DK, 1);
    txtc(dc, cx, cy, buf, CL_GOLD, f_bold, 1);
    circle(dc, cx - w / 2 + U(22), cy, U(4), CL_GOLD, CL_GOLD, 0);
    circle(dc, cx + w / 2 - U(22), cy, U(4), CL_GOLD, CL_GOLD, 0);
}

/* ------------------------------------------------------------ chart plots */
static double gx(const Geo *g, double v) { return g->px0 + (g->px1 - g->px0) * v / g->n; }
static double gy(const Geo *g, double v) { return g->py1 - (g->py1 - g->py0) * v / g->ymax; }
#define BX(g, v) ((int)((gx(g, (v)) - (g)->bx0) * SSC + 0.5))
#define BY(g, v) ((int)((gy(g, (v)) - (g)->by0) * SSC + 0.5))

static void geo_common(Geo *g)
{
    g->bx0 = g->px0 - U(14); g->by0 = g->py0 - U(14);
    g->bx1 = g->px1 + U(14); g->by1 = g->py1 + U(10);
}
static void worm_geo(const RECT *a, Geo *g)
{
    int k, i, raw = 10, n1 = g_match.in[0].overs, n2 = g_match.in[1].overs;
    g->px0 = a->left + U(72); g->px1 = a->right - U(86);
    g->py0 = a->top + U(10); g->py1 = a->bottom - U(80);
    g->n = n1 > n2 ? n1 : n2;
    if (g->n < 1) g->n = 1;
    if (g->n > SG5_MAX_OVERS) g->n = SG5_MAX_OVERS;
    for (k = 0; k < 2; k++) {
        if (g_match.in[k].total_runs > raw) raw = g_match.in[k].total_runs;
        for (i = 0; i < g_match.in[k].overs && i < SG5_MAX_OVERS; i++)
            if (g_match.in[k].cumulative_runs[i] > raw) raw = g_match.in[k].cumulative_runs[i];
    }
    nice_scale(raw, &g->ymax, &g->ystep);
    geo_common(g);
}
static void bars_geo(const RECT *a, int k, Geo *g)
{
    int n = g_match.in[k].overs, mx = sg5_max_over_runs(&g_match);
    g->px0 = a->left + U(66); g->px1 = a->right - U(20);
    g->py0 = a->top + U(36); g->py1 = a->bottom - U(58);
    if (n < 1) n = 1;
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    g->n = n;
    nice_scale(mx + mx / 8 + 1, &g->ymax, &g->ystep);
    geo_common(g);
}

static void plot_worm(HDC d, const Geo *g, double prog)
{
    int k, i, t;
    double xv = prog * g->n;
    HPEN gp = CreatePen(PS_SOLID, SSC, CL_GRID), old = (HPEN)SelectObject(d, gp);

    for (t = 0; t <= g->ymax; t += g->ystep) { MoveToEx(d, BX(g, 0), BY(g, t), NULL); LineTo(d, BX(g, g->n), BY(g, t)); }
    for (i = 0; i <= g->n; i++) { MoveToEx(d, BX(g, i), BY(g, g->ymax), NULL); LineTo(d, BX(g, i), BY(g, 0)); }
    SelectObject(d, old); DeleteObject(gp);
    gp = CreatePen(PS_SOLID, SSC * 2, CL_MUTED); old = (HPEN)SelectObject(d, gp);
    MoveToEx(d, BX(g, 0), BY(g, g->ymax), NULL); LineTo(d, BX(g, 0), BY(g, 0)); LineTo(d, BX(g, g->n), BY(g, 0));
    SelectObject(d, old); DeleteObject(gp);

    for (k = 1; k >= 0; k--) {           /* first innings drawn last so it stays on top */
        const InningsPlot *p = &g_match.in[k];
        int ns = p->overs;
        COLORREF col = k ? CL_GOLD : CL_PINK;
        HPEN pn, rp;
        HBRUSH br;
        int r = SSC * U(4);
        if (ns < 1) continue;
        if (ns > SG5_MAX_OVERS) ns = SG5_MAX_OVERS;
        pn = CreatePen(PS_SOLID, SSC * U(3), col); old = (HPEN)SelectObject(d, pn);
        MoveToEx(d, BX(g, 0), BY(g, 0), NULL);
        for (i = 1; i <= ns; i++) {
            double prev = (i == 1) ? 0.0 : p->cumulative_runs[i - 2];
            if (i <= xv) LineTo(d, BX(g, i), BY(g, p->cumulative_runs[i - 1]));
            else {
                double fr = xv - (i - 1);
                if (fr > 0) LineTo(d, BX(g, xv), BY(g, prev + (p->cumulative_runs[i - 1] - prev) * fr));
                break;
            }
        }
        SelectObject(d, old); DeleteObject(pn);
        br = CreateSolidBrush(col); rp = CreatePen(PS_SOLID, SSC, CL_PLOT);
        {
            HGDIOBJ ob = SelectObject(d, br), op = SelectObject(d, rp);
            for (i = 1; i <= ns && i <= xv; i++) {
                int cx = BX(g, i), cy = BY(g, p->cumulative_runs[i - 1]);
                Ellipse(d, cx - r, cy - r, cx + r + 1, cy + r + 1);
            }
            SelectObject(d, ob); SelectObject(d, op);
        }
        DeleteObject(br); DeleteObject(rp);
        rp = CreatePen(PS_SOLID, SSC * 2, RGB(255, 255, 255));           /* fallen wickets: white rings */
        {
            HGDIOBJ ob = SelectObject(d, GetStockObject(NULL_BRUSH)), op = SelectObject(d, rp);
            int r2 = SSC * U(8);
            for (i = 1; i <= ns && i <= xv; i++) {
                if (p->wicket_in_over[i - 1] > 0) {
                    int cx = BX(g, i), cy = BY(g, p->cumulative_runs[i - 1]);
                    Ellipse(d, cx - r2, cy - r2, cx + r2 + 1, cy + r2 + 1);
                }
            }
            SelectObject(d, ob); SelectObject(d, op);
        }
        DeleteObject(rp);
    }
}

static void plot_bars(HDC d, const Geo *g, int k, double prog)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->overs, i, t, maxv = 0, bands = 6;
    COLORREF acc = k ? CL_GOLD : CL_PINK;
    HPEN gp = CreatePen(PS_SOLID, SSC, CL_GRID), old = (HPEN)SelectObject(d, gp);
    double slot, barw;

    for (t = 0; t <= g->ymax; t += g->ystep) { MoveToEx(d, BX(g, 0), BY(g, t), NULL); LineTo(d, BX(g, g->n), BY(g, t)); }
    SelectObject(d, old); DeleteObject(gp);
    if (n < 1) return;
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    for (i = 0; i < n; i++) if (p->runs_per_over[i] > maxv) maxv = p->runs_per_over[i];
    slot = (double)(g->px1 - g->px0) / n;
    barw = slot * 0.64;
    for (i = 0; i < n; i++) {
        double st = (double)i / n * 0.45, e = ease_out((prog - st) / 0.55);
        double v = p->runs_per_over[i] * e;
        double x0 = (g->px0 - g->bx0) + slot * i + (slot - barw) / 2.0, x1 = x0 + barw;
        double y1 = gy(g, 0) - g->by0, y0 = gy(g, v) - g->by0;
        COLORREF col = (p->runs_per_over[i] == maxv) ? lighten(acc, 0.32) : acc;
        int b;
        if (y1 - y0 < 1.0) continue;
        for (b = 0; b < bands; b++) {
            double ya = y0 + (y1 - y0) * b / bands, yb = y0 + (y1 - y0) * (b + 1) / bands;
            COLORREF c = lerp_col(lighten(col, 0.25), lerp_col(col, CL_PLOT, 0.4), (double)b / (bands - 1));
            fill(d, (int)(x0 * SSC), (int)(ya * SSC), (int)(x1 * SSC), (int)(yb * SSC) + 1, c);
        }
        fill(d, (int)(x0 * SSC), (int)(y0 * SSC), (int)(x1 * SSC), (int)(y0 * SSC) + SSC * 2, lighten(col, 0.6));
    }
    gp = CreatePen(PS_SOLID, SSC * 2, CL_MUTED); old = (HPEN)SelectObject(d, gp);
    MoveToEx(d, BX(g, 0), BY(g, g->ymax), NULL); LineTo(d, BX(g, 0), BY(g, 0)); LineTo(d, BX(g, g->n), BY(g, 0));
    SelectObject(d, old); DeleteObject(gp);
}

/* Renders the plot at 2x into a memory bitmap and shrinks it with HALFTONE for smooth, anti-aliased lines. */
static void render_plot(const Geo *g, int view, double prog)
{
    int bw = g->bx1 - g->bx0, bh = g->by1 - g->by0, W = bw * SSC, H = bh * SSC;
    HDC sdc = GetDC(NULL), big = CreateCompatibleDC(sdc), small_;
    HBITMAP bb = CreateCompatibleBitmap(sdc, W, H);
    HGDIOBJ ob = SelectObject(big, bb), os;

    fill(big, 0, 0, W, H, CL_PLOT);
    if (view == VIEW_WORM) plot_worm(big, g, prog);
    else plot_bars(big, g, view == VIEW_MAN2 ? 1 : 0, prog);
    if (!g_plot || g_plot_w != bw || g_plot_h != bh) {
        if (g_plot) DeleteObject(g_plot);
        g_plot = CreateCompatibleBitmap(sdc, bw, bh);
        g_plot_w = bw; g_plot_h = bh;
    }
    small_ = CreateCompatibleDC(sdc);
    os = SelectObject(small_, g_plot);
    SetStretchBltMode(small_, HALFTONE);
    SetBrushOrgEx(small_, 0, 0, NULL);
    StretchBlt(small_, 0, 0, bw, bh, big, 0, 0, W, H, SRCCOPY);
    SelectObject(small_, os); DeleteDC(small_);
    SelectObject(big, ob); DeleteObject(bb); DeleteDC(big);
    ReleaseDC(NULL, sdc);
}
static void show_plot(HDC dc, const Geo *g, int view, double prog)
{
    int key = view * 1000 + g_match_index * 10 + (g_w ^ (g_h << 3));
    HDC t;
    if (!g_plot_valid || g_plot_key != key || prog < 1.0) {
        render_plot(g, view, prog);
        g_plot_key = key;
        g_plot_valid = (prog >= 1.0);
    }
    t = CreateCompatibleDC(dc);
    SelectObject(t, g_plot);
    BitBlt(dc, g->bx0, g->by0, g->bx1 - g->bx0, g->by1 - g->by0, t, 0, 0, SRCCOPY);
    DeleteDC(t);
}

/* ------------------------------------------------------------ chart views */
static void axis_title_x(HDC dc, const Geo *g, const char *s)
{
    txtc(dc, (g->px0 + g->px1) / 2, g->py1 + U(34), s, CL_TEXT, f_bold, 1);
}
static void y_labels(HDC dc, const Geo *g)
{
    int t;
    char b[16];
    for (t = 0; t <= g->ymax; t += g->ystep) {
        snprintf(b, sizeof b, "%d", t);
        txtc(dc, g->px0 - U(10), (int)(gy(g, t) + 0.5), b, CL_TEXT, f_body, 2);
    }
}

static void view_worm(HDC dc, const RECT *a)
{
    Geo g;
    double prog = chart_prog();
    int i, step = 1, k, ypos[2];
    char b[64];
    worm_geo(a, &g);
    show_plot(dc, &g, VIEW_WORM, prog);
    y_labels(dc, &g);
    if ((g.px1 - g.px0) / g.n < U(34)) step = 2;
    if ((g.px1 - g.px0) / g.n < U(17)) step = 5;
    for (i = 0; i <= g.n; i += step) {
        snprintf(b, sizeof b, "%d", i);
        txtc(dc, (int)(gx(&g, i) + 0.5), g.py1 + U(14), b, CL_TEXT, f_body, 1);
    }
    axis_title_x(dc, &g, "Overs");
    txt_rot(dc, a->left + U(6), (g.py0 + g.py1) / 2, "Cumulative Runs", CL_TEXT);

    /* legend */
    {
        int w0 = tw(dc, f_body, g_match.in[0].team), w1 = tw(dc, f_body, g_match.in[1].team);
        int total = U(30) + w0 + U(40) + U(30) + w1, x = (g.px0 + g.px1) / 2 - total / 2, y = g.py1 + U(64), wx = g.px1 - U(96);
        line_(dc, x, y, x + U(22), y, CL_PINK, 3, PS_SOLID); circle(dc, x + U(11), y, U(4), CL_PINK, CL_PINK, 0);
        txtc(dc, x + U(30), y, g_match.in[0].team, CL_TEXT, f_body, 0);
        x += U(30) + w0 + U(40);
        line_(dc, x, y, x + U(22), y, CL_GOLD, 3, PS_SOLID); circle(dc, x + U(11), y, U(4), CL_GOLD, CL_GOLD, 0);
        txtc(dc, x + U(30), y, g_match.in[1].team, CL_TEXT, f_body, 0);
        if (wx > x + U(30) + w1 + U(30)) {      /* wicket key, only if there is room */
            ring(dc, wx, y, U(6), RGB(255, 255, 255), 2);
            txtc(dc, wx + U(14), y, "Wicket", CL_MUTED, f_body, 0);
        }
    }
    /* end-of-innings score pills */
    if (prog >= 0.999) {
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            ypos[k] = p->overs > 0 ? (int)(gy(&g, p->total_runs) + 0.5) : -10000;
        }
        if (abs(ypos[0] - ypos[1]) < U(28)) { if (ypos[1] >= ypos[0]) ypos[1] = ypos[0] + U(28); else ypos[0] = ypos[1] + U(28); }
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            int w, x;
            if (p->overs < 1) continue;
            snprintf(b, sizeof b, "%d/%d", p->total_runs, p->wickets);
            w = tw(dc, f_bold, b) + U(20);
            x = (int)(gx(&g, p->overs) + 0.5) + U(10);
            rrect(dc, x, ypos[k] - U(13), x + w, ypos[k] + U(13), U(10), k ? CL_GOLD : CL_PINK, lighten(k ? CL_GOLD : CL_PINK, 0.4), 1);
            txtc(dc, x + w / 2, ypos[k], b, k ? CL_INK : RGB(255, 255, 255), f_bold, 1);
        }
    }
    /* hover crosshair + tooltip */
    if (g_mx >= g.px0 - U(6) && g_mx <= g.px1 + U(6) && g_my >= g.py0 && g_my <= g.py1) {
        int v = (int)(((g_mx - g.px0) * (double)g.n) / (g.px1 - g.px0) + 0.5), r0, r1, w0, w1, hx;
        const char *ln[4];
        COLORREF cl[4];
        char l0[64], l1[160], l2[160], l3[160];
        if (v < 0) v = 0;
        if (v > g.n) v = g.n;
        hx = (int)(gx(&g, v) + 0.5);
        line_(dc, hx, g.py0, hx, g.py1, RGB(140, 150, 205), 1, PS_DOT);
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            if (p->overs < 1) continue;
            circle(dc, hx, (int)(gy(&g, runs_at(p, v)) + 0.5), U(7), k ? CL_GOLD : CL_PINK, RGB(255, 255, 255), 2);
        }
        r0 = runs_at(&g_match.in[0], v); r1 = runs_at(&g_match.in[1], v);
        w0 = wkts_at(&g_match.in[0], v); w1 = wkts_at(&g_match.in[1], v);
        snprintf(l0, sizeof l0, "After over %d", v);
        snprintf(l1, sizeof l1, "%s   %d/%d", g_match.in[0].team, r0, w0);
        snprintf(l2, sizeof l2, "%s   %d/%d", g_match.in[1].team, r1, w1);
        if (r0 == r1) snprintf(l3, sizeof l3, "Scores level");
        else snprintf(l3, sizeof l3, "%s lead by %d", r0 > r1 ? g_match.in[0].team : g_match.in[1].team, abs(r0 - r1));
        ln[0] = l0; ln[1] = l1; ln[2] = l2; ln[3] = l3;
        cl[0] = CL_GOLD; cl[1] = CL_PINK; cl[2] = CL_GOLD; cl[3] = CL_GREEN;
        tooltip(dc, g_mx, g_my, 4, ln, cl);
    }
}

static void view_bars(HDC dc, const RECT *a, int k)
{
    const InningsPlot *p = &g_match.in[k];
    Geo g;
    double prog = chart_prog(), slot;
    int n = p->overs, i, step = 1, hover;
    char b[96];
    COLORREF acc = k ? CL_GOLD : CL_PINK;
    bars_geo(a, k, &g);
    if (n < 1) { txtc(dc, (a->left + a->right) / 2, (a->top + a->bottom) / 2, "No chart data available", CL_MUTED, f_body, 1); return; }
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    show_plot(dc, &g, k ? VIEW_MAN2 : VIEW_MAN1, prog);
    y_labels(dc, &g);
    slot = (double)(g.px1 - g.px0) / n;
    if (slot < U(26)) step = 2;
    if (slot < U(14)) step = 5;
    for (i = 0; i < n; i++) {
        int cx = (int)(g.px0 + slot * i + slot / 2);
        if (i % step == 0) { snprintf(b, sizeof b, "%d", i + 1); txtc(dc, cx, g.py1 + U(14), b, CL_TEXT, f_body, 1); }
    }
    axis_title_x(dc, &g, "Overs");
    txt_rot(dc, a->left + U(6), (g.py0 + g.py1) / 2, "Runs per over", CL_TEXT);

    if (prog >= 0.95) {
        double avg = p->balls ? 6.0 * p->total_runs / p->balls : 0.0;
        int ay = (int)(gy(&g, avg) + 0.5);
        for (i = 0; i < n; i++) {
            int cx = (int)(g.px0 + slot * i + slot / 2), top = (int)(gy(&g, p->runs_per_over[i]) + 0.5);
            if (n <= 24 && p->runs_per_over[i] > 0) {
                snprintf(b, sizeof b, "%d", p->runs_per_over[i]);
                txtc(dc, cx, top - U(11), b, CL_TEXT, f_capb, 1);
            }
            if (p->wicket_in_over[i] > 0) {
                int by = top - U(33);
                circle(dc, cx, by, U(9), CL_RED, RGB(255, 190, 200), 1);
                txtc(dc, cx, by, "W", RGB(255, 255, 255), f_capb, 1);
            }
        }
        line_(dc, g.px0, ay, g.px1, ay, RGB(235, 235, 250), 1, PS_DASH);
        snprintf(b, sizeof b, "avg %.2f / over", avg);
        {
            int w = tw(dc, f_capb, b) + U(14);
            rrect(dc, g.px1 - w, ay - U(24), g.px1, ay - U(4), U(8), RGB(30, 38, 84), CL_EDGE, 1);
            txtc(dc, g.px1 - w / 2, ay - U(14), b, CL_TEXT, f_capb, 1);
        }
    }
    if (g_mx >= g.px0 && g_mx <= g.px1 && g_my >= g.py0 - U(30) && g_my <= g.py1) {
        hover = (int)((g_mx - g.px0) / slot);
        if (hover >= n) hover = n - 1;
        if (hover >= 0) {
            int x0 = (int)(g.px0 + slot * hover + slot * 0.18), x1 = (int)(g.px0 + slot * hover + slot * 0.82);
            int top = (int)(gy(&g, p->runs_per_over[hover]) + 0.5), wk = p->wicket_in_over[hover];
            const char *ln[3];
            COLORREF cl[3];
            char l0[64], l1[96], l2[96];
            HPEN pen = CreatePen(PS_SOLID, 2, RGB(255, 255, 255));
            HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH)), op = SelectObject(dc, pen);
            Rectangle(dc, x0 - 2, top - 2, x1 + 3, g.py1 + 1);
            SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
            snprintf(l0, sizeof l0, "Over %d", hover + 1);
            snprintf(l1, sizeof l1, "%d runs  (cumulative %d)", p->runs_per_over[hover], runs_at(p, hover + 1));
            if (wk > 0) snprintf(l2, sizeof l2, "%d wicket%s fell", wk, wk == 1 ? "" : "s");
            else snprintf(l2, sizeof l2, "No wicket");
            ln[0] = l0; ln[1] = l1; ln[2] = l2;
            cl[0] = acc; cl[1] = CL_TEXT; cl[2] = wk > 0 ? CL_PINK : CL_MUTED;
            tooltip(dc, g_mx, g_my, 3, ln, cl);
        }
    }
}

static void view_partner(HDC dc, const RECT *a, int k)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->num_partnerships, i, mx = 1, rh, top, namew = U(250), valw = U(112), bx0, bx1, hover = -1;
    COLORREF acc = k ? CL_GOLD : CL_PINK;
    double el = anim_el();
    if (n > SG5_MAX_PSHIPS) n = SG5_MAX_PSHIPS;
    if (n < 1) { txtc(dc, (a->left + a->right) / 2, (a->top + a->bottom) / 2, "No partnership data available", CL_MUTED, f_body, 1); return; }
    for (i = 0; i < n; i++) if (p->pship_runs[i] > mx) mx = p->pship_runs[i];
    top = a->top + U(26);
    rh = (a->bottom - top) / n;
    if (rh > U(50)) rh = U(50);
    bx0 = a->left + U(70) + namew; bx1 = a->right - valw;
    if (bx1 - bx0 < U(80)) { namew = U(150); bx0 = a->left + U(70) + namew; }
    txtc(dc, a->left + U(70), a->top + U(8), "BATTING PAIR", CL_MUTED, f_capb, 0);
    txtc(dc, bx0, a->top + U(8), "RUNS ADDED", CL_MUTED, f_capb, 0);
    txtc(dc, a->right - U(8), a->top + U(8), "SHARE OF TOTAL", CL_MUTED, f_capb, 2);
    for (i = 0; i < n; i++) {
        int ry = top + i * rh, cy = ry + rh / 2, bh = rh - U(16), bwid, over;
        double e = ease_out((el - i * 90.0) / 600.0);
        char b[160], nm[160];
        if (bh > U(26)) bh = U(26);
        bwid = (int)((bx1 - bx0) * ((double)p->pship_runs[i] / mx) * e);
        over = (g_mx >= a->left && g_mx <= a->right && g_my >= ry && g_my < ry + rh);
        if (over) { hover = i; rrect(dc, a->left, ry + U(2), a->right, ry + rh - U(2), U(12), RGB(24, 33, 76), CL_EDGE, 1); }
        circle(dc, a->left + U(30), cy, U(15), CL_PLOT, acc, 2);
        snprintf(b, sizeof b, "W%d", i + 1);
        txtc(dc, a->left + U(30), cy, b, acc, f_capb, 1);
        if (p->pship_bat2[i][0]) snprintf(nm, sizeof nm, "%s & %s%s", p->pship_bat1[i], p->pship_bat2[i], p->pship_unbeaten[i] ? "*" : "");
        else snprintf(nm, sizeof nm, "%s%s", p->pship_bat1[i], p->pship_unbeaten[i] ? "*" : "");
        txtc(dc, a->left + U(58), cy, nm, CL_TEXT, f_body, 0);
        rrect(dc, bx0, cy - bh / 2, bx1, cy + bh / 2, U(10), CL_PLOT, CL_GRID, 1);
        if (bwid > U(4)) {
            COLORREF c = p->pship_unbeaten[i] ? lighten(acc, 0.3) : acc;
            rrect_grad(dc, bx0, cy - bh / 2, bx0 + bwid, cy + bh / 2, U(10), lighten(c, 0.25), lerp_col(c, CL_PLOT, 0.35), lighten(c, 0.4), 1);
        }
        snprintf(b, sizeof b, "%d", (int)(p->pship_runs[i] * e + 0.5));
        txtc(dc, bx1 + U(14), cy, b, CL_TEXT, f_bold, 0);
        snprintf(b, sizeof b, "%d%%", p->total_runs ? p->pship_runs[i] * 100 / p->total_runs : 0);
        txtc(dc, a->right - U(8), cy, b, CL_MUTED, f_body, 2);
    }
    if (hover >= 0) {
        const char *ln[3];
        COLORREF cl[3];
        char l0[48], l1[180], l2[100];
        snprintf(l0, sizeof l0, "Wicket %d partnership", hover + 1);
        snprintf(l1, sizeof l1, "%s%s%s", p->pship_bat1[hover], p->pship_bat2[hover][0] ? " & " : "", p->pship_bat2[hover]);
        snprintf(l2, sizeof l2, "%d runs%s", p->pship_runs[hover], p->pship_unbeaten[hover] ? "  (unbeaten)" : "");
        ln[0] = l0; ln[1] = l1; ln[2] = l2;
        cl[0] = acc; cl[1] = CL_TEXT; cl[2] = CL_GOLD;
        tooltip(dc, g_mx, g_my, 3, ln, cl);
    }
}

static void award_glyph(HDC dc, int i, int x, int y, int s, double e)
{
    COLORREF gold = lerp_col(CL_PANEL, CL_GOLD, e);
    POINT pts[10];
    int j, cx = x + s / 2, cy = y + s / 2;
    circle(dc, cx, cy, s / 2, CL_PLOT, lerp_col(CL_PANEL, CL_GOLD_DK, e), 2);
    if (i == 0) {                                   /* star */
        for (j = 0; j < 10; j++) {
            double ang = -PI / 2 + j * PI / 5, rad = (j % 2 ? 0.17 : 0.38) * s;
            pts[j].x = cx + (int)(cos(ang) * rad); pts[j].y = cy + (int)(sin(ang) * rad);
        }
        poly(dc, pts, 10, gold, lighten(gold, 0.3));
    } else if (i == 1) {                            /* ball with a six */
        circle(dc, cx, cy, (int)(0.34 * s), lerp_col(CL_PANEL, CL_PINK, e), lighten(lerp_col(CL_PANEL, CL_PINK, e), 0.3), 2);
        txtc(dc, cx, cy, "6", lerp_col(CL_PANEL, RGB(255, 255, 255), e), f_mid, 1);
    } else if (i == 2) {                            /* stumps and bails */
        int sw = (int)(0.08 * s), sh = (int)(0.5 * s), sx = cx - (int)(0.2 * s), gap = (int)(0.2 * s);
        for (j = 0; j < 3; j++) fill(dc, sx + j * gap - sw / 2, cy - sh / 2 + U(4), sx + j * gap + sw / 2, cy + sh / 2 + U(4), gold);
        fill(dc, sx - sw / 2, cy - sh / 2, sx + gap, cy - sh / 2 + U(3), lighten(gold, 0.3));
        fill(dc, sx + gap + sw / 2, cy - sh / 2, sx + 2 * gap + sw / 2, cy - sh / 2 + U(3), lighten(gold, 0.3));
    } else {                                        /* lightning bolt */
        POINT bp[6];
        static const double bx[6] = {0.58, 0.28, 0.48, 0.40, 0.74, 0.54}, by[6] = {0.12, 0.54, 0.54, 0.90, 0.42, 0.42};
        for (j = 0; j < 6; j++) { bp[j].x = x + (int)(bx[j] * s); bp[j].y = y + (int)(by[j] * s); }
        poly(dc, bp, 6, gold, lighten(gold, 0.3));
    }
}

static void view_awards(HDC dc, const RECT *a)
{
    static const char *heads[4] = {"PLAYER OF THE MATCH", "MOST SIXES", "MOST WICKETS", "SUPER STRIKER"};
    const char *names[4];
    char vals[4][64];
    int i, gap = U(14), cw = (a->right - a->left - gap) / 2, ch = (a->bottom - a->top - gap) / 2;
    names[0] = g_match.aw.man_of_match; names[1] = g_match.aw.most_sixes;
    names[2] = g_match.aw.most_wickets; names[3] = g_match.aw.super_striker;
    snprintf(vals[0], sizeof vals[0], "%d points", g_match.aw.mom_points);
    snprintf(vals[1], sizeof vals[1], "%d sixes", g_match.aw.sixes);
    snprintf(vals[2], sizeof vals[2], "%d wickets", g_match.aw.wickets);
    snprintf(vals[3], sizeof vals[3], "Strike rate %.1f", g_match.aw.strike_rate);
    if (ch > U(170)) ch = U(170);
    for (i = 0; i < 4; i++) {
        double t = clampd((anim_el() - i * 130.0) / 520.0, 0, 1), e = ease_out(t);
        int x = a->left + (i % 2) * (cw + gap), y = a->top + (i / 2) * (ch + gap) + (int)((1.0 - e) * U(34));
        int gs = ch - U(40), cy = y + ch / 2, tx;
        COLORREF edge;
        if (t <= 0) continue;
        if (gs > U(88)) gs = U(88);
        tx = x + U(26) + gs + U(24);
        edge = lerp_col(CL_PANEL, i == 0 ? CL_GOLD : CL_EDGE, e);
        rrect_grad(dc, x, y, x + cw, y + ch, U(18), lerp_col(CL_PANEL, RGB(26, 35, 80), e), lerp_col(CL_PANEL, RGB(15, 21, 52), e), edge, i == 0 ? 2 : 1);
        award_glyph(dc, i, x + U(26), cy - gs / 2, gs, e);
        txtc(dc, tx, cy - U(30), heads[i], lerp_col(CL_PANEL, CL_MUTED, e), f_capb, 0);
        txtc(dc, tx, cy + U(2), names[i][0] ? names[i] : "Not available", lerp_col(CL_PANEL, CL_TEXT, e), f_mid, 0);
        txtc(dc, tx, cy + U(34), vals[i], lerp_col(CL_PANEL, CL_GOLD, e), f_bold, 0);
    }
}

static void draw_chart_panel(HDC dc, const Lay *L)
{
    RECT a;
    char title[200];
    int tcx = L->margin + U(46);
    rrect_grad(dc, L->margin, L->chart_t, g_w - L->margin, L->chart_b, U(18), CL_PANEL, CL_PANEL_B, CL_EDGE, 1);
    glyph_bars(dc, L->margin + U(18), L->chart_t + U(28), U(22));
    switch (g_view) {
    case VIEW_WORM: snprintf(title, sizeof title, "Worm chart \x96 cumulative runs"); break;
    case VIEW_MAN1: case VIEW_MAN2:
        snprintf(title, sizeof title, "Manhattan \x96 runs per over \x96 %s", g_match.in[g_view == VIEW_MAN2 ? 1 : 0].team); break;
    case VIEW_PSHIP1: case VIEW_PSHIP2:
        snprintf(title, sizeof title, "Partnership contributions \x96 %s", g_match.in[g_view == VIEW_PSHIP2 ? 1 : 0].team); break;
    default: snprintf(title, sizeof title, "Match awards"); break;
    }
    txtc(dc, tcx, L->chart_t + U(28), title, CL_TEXT, f_h2, 0);
    if (g_view != VIEW_AWARDS)
        txtc(dc, g_w - L->margin - U(20), L->chart_t + U(28), "Hover over the chart for details", CL_MUTED, f_ital, 2);
    chart_area(L, &a);
    line_(dc, L->margin + U(1), L->chart_t + U(54), g_w - L->margin - U(1), L->chart_t + U(54), CL_GRID, 1, PS_SOLID);
    switch (g_view) {
    case VIEW_WORM: view_worm(dc, &a); break;
    case VIEW_MAN1: view_bars(dc, &a, 0); break;
    case VIEW_MAN2: view_bars(dc, &a, 1); break;
    case VIEW_PSHIP1: view_partner(dc, &a, 0); break;
    case VIEW_PSHIP2: view_partner(dc, &a, 1); break;
    default: view_awards(dc, &a); break;
    }
}

static void draw_status(HDC dc, const Lay *L)
{
    char buf[160], clk[32];
    time_t now = time(NULL);
    struct tm *tmv = localtime(&now);
    int yc = (L->status_t + g_h) / 2, lend, cstart;
    const char *left = "Ready";
    fill(dc, 0, L->status_t, g_w, g_h, CL_HDR);
    line_(dc, 0, L->status_t, g_w, L->status_t, CL_GOLD_DK, 1, PS_SOLID);
    if (GetTickCount() < g_status_until && g_status[0]) left = g_status;
    else if (g_hot >= 0) left = TAB_HINT[g_hot];
    circle(dc, L->margin + U(6), yc, U(6), CL_GREEN, lighten(CL_GREEN, 0.4), 1);
    txtc(dc, L->margin + U(20), yc, left, CL_TEXT, f_cap, 0);
    lend = L->margin + U(20) + tw(dc, f_cap, left);
    snprintf(buf, sizeof buf, "CricLens v1.0  |  Cricket Analytics Suite  |  Match %d of %d", g_match_index + 1, sg5_match_count());
    cstart = g_w / 2 - tw(dc, f_cap, buf) / 2;
    if (cstart > lend + U(30)) txtc(dc, g_w / 2, yc, buf, CL_MUTED, f_cap, 1);
    if (tmv && strftime(clk, sizeof clk, "%I:%M %p", tmv)) txtc(dc, g_w - L->margin, yc, clk, CL_TEXT, f_cap, 2);
}

/* ------------------------------------------------------------------ splash */
static void draw_splash(HDC dc)
{
    double el = (double)(GetTickCount() - g_t_start), t = clampd(el / SPLASH_MS, 0, 1);
    int cx = g_w / 2, cy = g_h / 2 - U(50), r, dim, bw = U(380), by = cy + U(205), k;
    COLORREF bg = RGB(11, 16, 42);
    const char *stage = t < 0.3 ? "Initialising statistics engine..." : (t < 0.6 ? "Parsing match scorecards..." : (t < 0.88 ? "Building charts..." : "Ready"));
    for (k = 0; k < 2; k++) {
        double ph = fmod(el / 1400.0 + k * 0.5, 1.0);
        r = U(96) + (int)(ph * U(130));
        ring(dc, cx, cy, r, lerp_col(CL_GOLD, bg, clampd(ph * 1.15, 0, 1)), 2);
    }
    dim = (int)(U(190) * (0.5 + 0.5 * ease_back(el / 700.0)));
    blit_rgba(dc, g_logo_splash, 256, cx - dim / 2, cy - dim / 2, dim);
    txtc(dc, cx, cy + U(136), "CricLens", lerp_col(bg, CL_GOLD, clampd((el - 350) / 600.0, 0, 1)), f_title, 1);
    SetTextCharacterExtra(dc, U(3));
    txtc(dc, cx, cy + U(172), "CRICKET ANALYTICS DESKTOP", lerp_col(bg, CL_TEXT, clampd((el - 750) / 500.0, 0, 1)), f_capb, 1);
    SetTextCharacterExtra(dc, 0);
    rrect(dc, cx - bw / 2, by, cx + bw / 2, by + U(8), U(8), RGB(24, 32, 70), RGB(24, 32, 70), 0);
    r = (int)(bw * ease_out(t));
    if (r > U(8)) rrect_grad(dc, cx - bw / 2, by, cx - bw / 2 + r, by + U(8), U(8), CL_GOLD, RGB(214, 158, 48), CL_GOLD, 0);
    txtc(dc, cx, by + U(28), stage, CL_MUTED, f_cap, 1);
    txtc(dc, cx, g_h - U(40), "Analyze \xB7 Visualize \xB7 Celebrate", lerp_col(bg, CL_GOLD, clampd((el - 1000) / 600.0, 0, 1)), f_ital, 1);
}

static void draw_scene(HDC dc)
{
    Lay L = lay();
    vgrad(dc, 0, 0, g_w, g_h, CL_BG_TOP, CL_BG_BOT);
    if (g_splash) { draw_splash(dc); return; }
    draw_header(dc, &L);
    draw_nav(dc, &L);
    draw_cards(dc, &L);
    draw_result(dc, &L);
    draw_chart_panel(dc, &L);
    draw_status(dc, &L);
}

/* ----------------------------------------------------------------- actions */
static void select_view(View v) { g_view = v; restart_anim(); InvalidateRect(g_hwnd, NULL, FALSE); }
static void change_match(int delta)
{
    int n = sg5_match_count();
    if (n < 1) return;
    g_match_index = (g_match_index + delta + n) % n;
    load_current();
    InvalidateRect(g_hwnd, NULL, FALSE);
}
static void do_import(HWND w)
{
    OPENFILENAMEA ofn;
    char path[MAX_PATH] = "", err[256] = "";
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = "CricLens scorecard (*.txt)\0*.txt\0All files (*.*)\0*.*\0";
    ofn.lpstrFile = path; ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameA(&ofn)) {
        if (sg5_add_from_file(path, err, sizeof err)) {
            g_match_index = sg5_match_count() - 1;
            load_current();
            snprintf(err, sizeof err, "Scorecard loaded: %s", g_match.info.title);
            flash(err);
        } else {
            MessageBoxA(w, err[0] ? err : "The scorecard could not be read.", "Could not load scorecard", MB_OK | MB_ICONWARNING);
        }
        InvalidateRect(w, NULL, FALSE);
    }
}
static void do_about(HWND w)
{
    int r = MessageBoxA(w,
        "CricLens - Cricket Analytics Desktop  v1.0\n\n"
        "Written entirely in C (Win32 API + GDI).\n"
        "Integrated scorecard parser, match storage, statistics engine and chart renderer.\n\n"
        "Keyboard:  Left/Right = match   1-6 = views   Ctrl+O = import\n"
        "                  Ctrl+S = export image   F11 = full screen\n\n"
        "Create a Desktop shortcut now?",
        "About CricLens", MB_YESNO | MB_ICONINFORMATION);
    if (r == IDYES) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        flash(msg);
        InvalidateRect(w, NULL, FALSE);
    }
}
static int export_bmp(const char *path)
{
    int w = g_w, h = g_h, ok;
    size_t stride = ((size_t)w * 3 + 3) & ~(size_t)3;
    unsigned char *px;
    BITMAPINFO bi;
    BITMAPFILEHEADER bf;
    FILE *f;
    HDC sd;
    if (!g_mem || w < 1 || h < 1) return 0;
    px = (unsigned char *)malloc(stride * (size_t)h);
    if (!px) return 0;
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = h;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 24; bi.bmiHeader.biCompression = BI_RGB;
    SelectObject(g_mem, g_memold);          /* a bitmap must not be selected into a DC for GetDIBits */
    sd = GetDC(NULL);
    ok = GetDIBits(sd, g_membmp, 0, (UINT)h, px, &bi, DIB_RGB_COLORS) == h;
    ReleaseDC(NULL, sd);
    SelectObject(g_mem, g_membmp);
    if (ok) {
        memset(&bf, 0, sizeof bf);
        bf.bfType = 0x4D42;
        bf.bfOffBits = (DWORD)(sizeof bf + sizeof bi.bmiHeader);
        bf.bfSize = (DWORD)(bf.bfOffBits + stride * (size_t)h);
        f = fopen(path, "wb");
        ok = f != NULL;
        if (f) {
            fwrite(&bf, sizeof bf, 1, f);
            fwrite(&bi.bmiHeader, sizeof bi.bmiHeader, 1, f);
            fwrite(px, 1, stride * (size_t)h, f);
            fclose(f);
        }
    }
    free(px);
    return ok;
}
static void do_export(HWND w)
{
    static const char *names[VIEW_COUNT] = {"worm", "manhattan1", "manhattan2", "partnerships1", "partnerships2", "awards"};
    OPENFILENAMEA ofn;
    char path[MAX_PATH], msg[MAX_PATH + 40];
    int sx = g_mx, sy = g_my, sh = g_hot;
    snprintf(path, sizeof path, "CricLens_%s.bmp", names[g_view]);
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = "Bitmap image (*.bmp)\0*.bmp\0";
    ofn.lpstrFile = path; ofn.nMaxFile = MAX_PATH; ofn.lpstrDefExt = "bmp";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    if (!GetSaveFileNameA(&ofn)) return;
    g_mx = g_my = -1; g_hot = -1;                       /* export without hover effects */
    draw_scene(g_mem);
    g_mx = sx; g_my = sy; g_hot = sh;
    if (export_bmp(path)) { snprintf(msg, sizeof msg, "Chart image saved: %s", path); flash(msg); }
    else MessageBoxA(w, "The image could not be saved.", "Export", MB_OK | MB_ICONWARNING);
    InvalidateRect(w, NULL, FALSE);
}
static void do_tab(HWND w, int id)
{
    switch (id) {
    case T_PREV: change_match(-1); break;
    case T_NEXT: change_match(1); break;
    case T_IMPORT: do_import(w); break;
    case T_ABOUT: do_about(w); break;
    default: if (tab_is_view(id)) select_view((View)(id - T_WORM)); break;
    }
}
static void toggle_fullscreen(HWND w)
{
    DWORD st = (DWORD)GetWindowLong(w, GWL_STYLE);
    if (!g_full) {
        MONITORINFO mi;
        memset(&mi, 0, sizeof mi);
        mi.cbSize = sizeof mi;
        g_wp.length = sizeof g_wp;
        if (GetWindowPlacement(w, &g_wp) && GetMonitorInfo(MonitorFromWindow(w, MONITOR_DEFAULTTOPRIMARY), &mi)) {
            SetWindowLong(w, GWL_STYLE, (LONG)(st & ~WS_OVERLAPPEDWINDOW));
            SetWindowPos(w, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top,
                         mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top,
                         SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
            g_full = 1;
        }
    } else {
        SetWindowLong(w, GWL_STYLE, (LONG)(st | WS_OVERLAPPEDWINDOW));
        SetWindowPlacement(w, &g_wp);
        SetWindowPos(w, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        g_full = 0;
    }
}
static void end_splash(void) { g_splash = 0; restart_anim(); }

static void resize_backbuffer(HWND w, int cw, int ch)
{
    HDC sdc;
    if (cw < 1 || ch < 1) return;
    if (g_mem) {
        SelectObject(g_mem, g_memold);
        DeleteObject(g_membmp);
        DeleteDC(g_mem);
    }
    sdc = GetDC(w);
    g_mem = CreateCompatibleDC(sdc);
    g_membmp = CreateCompatibleBitmap(sdc, cw, ch);
    g_memold = SelectObject(g_mem, g_membmp);
    ReleaseDC(w, sdc);
    g_w = cw; g_h = ch;
    g_plot_valid = 0;
}

/* ------------------------------------------------------------ window proc */
static LRESULT CALLBACK window_proc(HWND w, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE:
        g_hwnd = w;
        make_fonts();
        g_icon_big = cl_make_hicon(GetSystemMetrics(SM_CXICON) > 0 ? GetSystemMetrics(SM_CXICON) : 32);
        g_icon_small = cl_make_hicon(GetSystemMetrics(SM_CXSMICON) > 0 ? GetSystemMetrics(SM_CXSMICON) : 16);
        if (g_icon_big) SendMessage(w, WM_SETICON, ICON_BIG, (LPARAM)g_icon_big);
        if (g_icon_small) SendMessage(w, WM_SETICON, ICON_SMALL, (LPARAM)g_icon_small);
        g_logo_hdr = (unsigned char *)malloc(256 * 256 * 4);
        g_logo_splash = (unsigned char *)malloc(256 * 256 * 4);
        if (g_logo_hdr) { cl_render_icon(g_logo_hdr, 256); cl_flatten_icon(g_logo_hdr, 256, CL_HDR); }
        if (g_logo_splash) { cl_render_icon(g_logo_splash, 256); cl_flatten_icon(g_logo_splash, 256, RGB(11, 16, 42)); }
        g_t_start = GetTickCount();
        SetTimer(w, 1, 16, NULL);
        SetTimer(w, 2, 1000, NULL);
        return 0;
    case WM_SIZE:
        if (wp != SIZE_MINIMIZED) { resize_backbuffer(w, LOWORD(lp), HIWORD(lp)); InvalidateRect(w, NULL, FALSE); }
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO *mm = (MINMAXINFO *)lp;
        RECT r;
        r.left = 0; r.top = 0; r.right = U(1000); r.bottom = U(680);
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        mm->ptMinTrackSize.x = r.right - r.left;
        mm->ptMinTrackSize.y = r.bottom - r.top;
        return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_TIMER:
        if (wp == 1) {
            if (g_splash) {
                if (GetTickCount() - g_t_start >= SPLASH_MS) end_splash();
                InvalidateRect(w, NULL, FALSE);
            } else if (anim_el() < ANIM_MS + 250) InvalidateRect(w, NULL, FALSE);
        } else if (wp == 2 && !g_splash) InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_MOUSEMOVE:
        g_mx = (short)LOWORD(lp); g_my = (short)HIWORD(lp);
        if (!g_tracking) {
            TRACKMOUSEEVENT te;
            te.cbSize = sizeof te; te.dwFlags = TME_LEAVE; te.hwndTrack = w; te.dwHoverTime = 0;
            TrackMouseEvent(&te);
            g_tracking = 1;
        }
        if (!g_splash) { g_hot = hit_tab(g_mx, g_my); InvalidateRect(w, NULL, FALSE); }
        return 0;
    case WM_MOUSELEAVE:
        g_tracking = 0; g_mx = g_my = -1; g_hot = -1;
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT && g_hot >= 0 && !g_splash) { SetCursor(LoadCursor(NULL, IDC_HAND)); return TRUE; }
        break;
    case WM_LBUTTONDOWN:
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        g_down = hit_tab((short)LOWORD(lp), (short)HIWORD(lp));
        if (g_down >= 0) SetCapture(w);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_LBUTTONUP: {
        int id = hit_tab((short)LOWORD(lp), (short)HIWORD(lp)), was = g_down;
        if (GetCapture() == w) ReleaseCapture();
        g_down = -1;
        InvalidateRect(w, NULL, FALSE);
        if (was >= 0 && id == was) do_tab(w, id);
        return 0;
    }
    case WM_KEYDOWN: {
        int ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0, shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        if (wp == VK_LEFT) change_match(-1);
        else if (wp == VK_RIGHT) change_match(1);
        else if (wp >= '1' && wp <= '6') select_view((View)(wp - '1'));
        else if (wp == VK_TAB) select_view((View)(((int)g_view + (shift ? VIEW_COUNT - 1 : 1)) % VIEW_COUNT));
        else if (wp == VK_F11) toggle_fullscreen(w);
        else if (wp == VK_ESCAPE && g_full) toggle_fullscreen(w);
        else if (wp == VK_F1) do_about(w);
        else if (ctrl && wp == 'O') do_import(w);
        else if (ctrl && wp == 'S') do_export(w);
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(w, &ps);
        if (g_mem) {
            draw_scene(g_mem);
            BitBlt(dc, 0, 0, g_w, g_h, g_mem, 0, 0, SRCCOPY);
        }
        EndPaint(w, &ps);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(w, 1); KillTimer(w, 2);
        if (g_mem) { SelectObject(g_mem, g_memold); DeleteObject(g_membmp); DeleteDC(g_mem); g_mem = NULL; }
        if (g_plot) DeleteObject(g_plot);
        kill_all_fonts();
        if (g_icon_big) DestroyIcon(g_icon_big);
        if (g_icon_small) DestroyIcon(g_icon_small);
        free(g_logo_hdr); free(g_logo_splash);
        sg5_shutdown();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(w, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE prev, LPSTR cmd, int show)
{
    WNDCLASSA wc;
    HWND w;
    MSG m;
    HDC sd;
    RECT wa, r;
    int cw, ch, ww, wh;
    (void)prev;

    /* "CricLens.exe --install" creates the Desktop / Start Menu shortcuts and exits. */
    if (cmd && strstr(cmd, "--install")) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        if (!strstr(cmd, "--quiet")) MessageBoxA(NULL, msg, "CricLens setup", MB_OK | MB_ICONINFORMATION);
        return 0;
    }
    cl_enable_dpi_awareness();
    sd = GetDC(NULL);
    g_s = GetDeviceCaps(sd, LOGPIXELSX) / 96.0;
    ReleaseDC(NULL, sd);
    if (g_s < 1.0) g_s = 1.0;
    if (!sg5_init()) { MessageBoxA(NULL, "Could not initialise CricLens match data.", "CricLens", MB_OK | MB_ICONERROR); return 1; }
    load_current();

    ZeroMemory(&wc, sizeof wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = window_proc; wc.hInstance = instance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL; wc.lpszClassName = "CricLensNativeWindow";
    if (!RegisterClassA(&wc)) { sg5_shutdown(); return 1; }

    SystemParametersInfoA(SPI_GETWORKAREA, 0, &wa, 0);
    cw = U(1180); ch = U(780);
    if (cw > wa.right - wa.left - U(40)) cw = wa.right - wa.left - U(40);
    if (ch > wa.bottom - wa.top - U(60)) ch = wa.bottom - wa.top - U(60);
    r.left = 0; r.top = 0; r.right = cw; r.bottom = ch;
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    ww = r.right - r.left; wh = r.bottom - r.top;
    w = CreateWindowExA(0, wc.lpszClassName, "CricLens - Cricket Analytics Desktop", WS_OVERLAPPEDWINDOW,
                        wa.left + (wa.right - wa.left - ww) / 2, wa.top + (wa.bottom - wa.top - wh) / 2, ww, wh,
                        NULL, NULL, instance, NULL);
    if (!w) { sg5_shutdown(); return 1; }
    cl_apply_dark_titlebar(w, CL_HDR);
    ShowWindow(w, show);
    UpdateWindow(w);
    while (GetMessageA(&m, NULL, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageA(&m); }
    return (int)m.wParam;
}
