/* Worm chart: cumulative runs after each over, both innings. */
#include "sg5_viz.h"

static void series(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_OVERS];
    char lab[SG5_MAX_OVERS][12];
    int i, rc;

    for (i = 0; i < p->overs; i++) {
        snprintf(lab[i], sizeof lab[i], "%d", i + 1);
        pts[i].label = lab[i];
        pts[i].value = p->cumulative_runs[i];
    }
    printf("\nWorm chart: %s (runs after each over)\n", p->team);
    rc = chart_ascii(CHART_LINE, pts, p->overs);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_worm_show(const Sg5Match *m)
{
    series(&m->in[0]);
    series(&m->in[1]);
}

void sg5_worm_svg(FILE *f, const Sg5Match *m)
{
    static const char *col[2] = {"#ff5d73", "#2dd4bf"};
    int i, o, mx = 1, maxo = 20;
    double step;

    for (i = 0; i < 2; i++) {
        if (m->in[i].total_runs > mx) mx = m->in[i].total_runs;
        if (m->in[i].overs > maxo) maxo = m->in[i].overs;
    }
    step = 450.0 / maxo;
    fputs("<svg class=sv viewBox='0 0 500 240' role=img aria-label='Worm chart of cumulative runs per over'>"
          "<line class=ax x1=40 y1=200 x2=490 y2=200 /><line class=ax x1=40 y1=20 x2=40 y2=200 />", f);
    for (o = 0; o <= maxo; o += 5) fprintf(f, "<text x=%g y=216 text-anchor=middle>%d</text>", 40 + o * step, o);
    fprintf(f, "<text x=265 y=233 text-anchor=middle>Overs</text><text x=36 y=24 text-anchor=end>%d</text>", mx);
    for (i = 0; i < 2; i++) {
        const InningsPlot *p = &m->in[i];
        fprintf(f, "<polygon fill='%s' fill-opacity=.12 points='40,200", col[i]);
        for (o = 0; o < p->overs; o++) fprintf(f, " %g,%g", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx);
        fprintf(f, " %g,200'/><polyline fill=none stroke='%s' stroke-width=3 stroke-linejoin=round points='40,200", 40 + p->overs * step, col[i]);
        for (o = 0; o < p->overs; o++) fprintf(f, " %g,%g", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx);
        fputs("'/>", f);
        for (o = 0; o < p->overs; o++)
            if (p->wicket_in_over[o])
                fprintf(f, "<circle cx=%g cy=%g r=4.5 fill='#fff' stroke='%s' stroke-width=2/>", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx, col[i]);
    }
    fprintf(f, "<text x=50 y=12 style='fill:%s'>%s</text><text x=270 y=12 style='fill:%s'>%s</text></svg>", col[0], m->in[0].team, col[1], m->in[1].team);
}
