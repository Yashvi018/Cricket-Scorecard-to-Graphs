/* Manhattan chart: runs per over as bars, wicket overs marked W. */
#include "sg5_viz.h"

void sg5_manhattan_show(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_OVERS];
    char lab[SG5_MAX_OVERS][16];
    int i, rc;

    for (i = 0; i < p->overs; i++) {
        snprintf(lab[i], sizeof lab[i], "Over %d%s", i + 1, p->wicket_in_over[i] ? " W" : "");
        pts[i].label = lab[i];
        pts[i].value = p->runs_per_over[i];
    }
    printf("\nManhattan chart: %s\n", p->team);
    rc = chart_ascii(CHART_BAR, pts, p->overs);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_manhattan_svg(FILE *f, const InningsPlot *p, int mx)
{
    int o, maxo = p->overs > 20 ? p->overs : 20;
    double step = 450.0 / maxo, bw = step * 0.8;

    fputs("<svg class=sv viewBox='0 0 500 232' role=img aria-label='Manhattan chart of runs per over'>"
          "<line class=ax x1=40 y1=200 x2=490 y2=200 /><line class=ax x1=40 y1=20 x2=40 y2=200 />", f);
    fprintf(f, "<text x=36 y=24 text-anchor=end>%d</text>", mx);
    for (o = 0; o < p->overs; o++) {
        double h = p->runs_per_over[o] * 170.0 / mx, x = 40 + o * step;
        const char *c = p->runs_per_over[o] >= 12 ? "#2dd4bf" : p->runs_per_over[o] >= 8 ? "#a78bfa" : "#60a5fa";
        fprintf(f, "<rect x=%g y=%g width=%g height=%g rx=3 fill='%s'/>", x + step * 0.1, 200 - h, bw, h, c);
        if (p->wicket_in_over[o])
            fprintf(f, "<circle cx=%g cy=%g r=7 fill='#ff5d73'/><text class=wk x=%g y=%g>W</text>", x + step / 2, 190 - h, x + step / 2, 193 - h);
        if (o % 5 == 4) fprintf(f, "<text x=%g y=216 text-anchor=middle>%d</text>", x + step / 2, o + 1);
    }
    fputs("<text x=265 y=230 text-anchor=middle>Overs</text></svg>", f);
}
