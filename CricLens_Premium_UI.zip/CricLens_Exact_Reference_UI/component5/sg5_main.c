/* Command-line entry point for the optional text menu. The Windows desktop GUI has its own WinMain entry point. */
#include "sg5_viz.h"

int main(int argc, char **argv)
{
    if (!sg5_init()) {
        fputs("Could not load the sample matches.\n", stderr);
        return 1;
    }
    (void)argc; (void)argv;
    sg5_menu_run();
    sg5_shutdown();
    return 0;
}
