/* Match awards: man of the match, most sixes, most wickets, super striker. */
#include "sg5_viz.h"

void sg5_awards_show(const Sg5Match *m)
{
    printf("\nMatch awards\n");
    printf("  Man of the match: %s (%d points)\n", m->aw.man_of_match, m->aw.mom_points);
    printf("  Most sixes:       %s (%d)\n", m->aw.most_sixes, m->aw.sixes);
    printf("  Most wickets:     %s (%d)\n", m->aw.most_wickets, m->aw.wickets);
    printf("  Super striker:    %s (strike rate %.1f)\n", m->aw.super_striker, m->aw.strike_rate);
}

