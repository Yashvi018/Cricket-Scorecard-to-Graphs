/* Three fictional T20 matches built directly as Component 2 Match structs.
   Used until real scorecard files are loaded. Totals, wickets, overs and fall of wickets all agree. */
#include <stdlib.h>
#include <string.h>
#include "sg5_viz.h"

typedef struct {
    int overs, balls;
    int runs[20];      /* runs in each over */
    int wk_over[10];   /* 0-based over of each wicket */
    int n_wk;
    int np;            /* partnerships: wickets, plus one if not out */
    int pr[11];        /* partnership runs (they add up to the total) */
    int pb[11];        /* partnership balls (they add up to the balls bowled) */
} Raw;

static const char *TEAMS[3][2] = {
    {"Sydney Skylarks", "Melbourne Meteors"}, {"Perth Pelicans", "Adelaide Admirals"}, {"Hobart Harriers", "Darwin Dingoes"}};
static const char *ORDER[3][2][11] = {
    {{"Jack", "Oliver", "Lachlan", "Mitchell", "Cooper", "Ryan", "Nathan", "Harry", "Callum", "Riley", "Blake"},
     {"Liam", "Hamish", "Angus", "Bailey", "Tom", "Jordan", "Dylan", "Flynn", "Archie", "Ethan", "Max"}},
    {{"Cameron", "Jake", "Hudson", "Kyle", "Josh", "Zac", "Finn", "Connor", "Ben", "Declan", "Toby"},
     {"Sam", "Aidan", "Brodie", "Chase", "Darcy", "Elliot", "Fraser", "Grant", "Heath", "Isaac", "Jarrod"}},
    {{"Xavier", "Wyatt", "Spencer", "Noah", "Marcus", "Lewis", "Owen", "Patrick", "Quinn", "Reid", "Scott"},
     {"Trent", "Wade", "Alex", "Billy", "Craig", "Damon", "Evan", "Gus", "Hugo", "Ian", "Kane"}}};
static const char *VENUES[3] = {"Harbourside Oval", "Swan River Park", "Derwent Ground"};
static const char *DATES[3] = {"2026-09-05", "2026-09-12", "2026-09-19"};
static const char *IDS[3] = {"SKY-MEL-01", "PER-ADE-02", "HOB-DAR-03"};

static const Raw RAW[3][2] = {
    {{20, 120, {6, 9, 4, 12, 8, 7, 10, 5, 11, 14, 6, 9, 8, 15, 7, 10, 12, 9, 16, 13}, {2, 6, 9, 12, 14, 17}, 6, 7,
      {24, 31, 18, 42, 20, 35, 21}, {14, 20, 11, 25, 15, 20, 15}},
     {20, 120, {5, 8, 11, 6, 9, 12, 7, 10, 4, 13, 8, 6, 9, 11, 5, 8, 12, 6, 9, 7}, {1, 4, 5, 8, 10, 13, 15, 16, 18}, 9, 10,
      {12, 18, 9, 20, 8, 16, 24, 13, 22, 24}, {9, 15, 8, 14, 10, 12, 16, 10, 14, 12}}},
    {{20, 120, {8, 11, 6, 9, 15, 10, 7, 12, 9, 6, 13, 8, 10, 14, 7, 9, 11, 16, 8, 12}, {3, 7, 11, 15, 18}, 5, 6,
      {38, 27, 45, 30, 33, 28}, {24, 18, 26, 16, 20, 16}},
     {17, 102, {9, 12, 8, 14, 10, 17, 6, 11, 13, 9, 15, 12, 8, 16, 10, 14, 18}, {5, 10, 14}, 3, 4,
      {52, 60, 48, 42}, {30, 28, 24, 20}}},
    {{20, 120, {4, 7, 5, 9, 6, 8, 3, 10, 7, 5, 9, 6, 8, 11, 4, 7, 9, 6, 10, 8}, {2, 4, 7, 9, 11, 13, 14, 16, 18, 19}, 10, 10,
      {12, 15, 8, 20, 10, 14, 11, 17, 13, 22}, {12, 14, 10, 16, 12, 14, 10, 12, 10, 10}},
     {20, 120, {6, 9, 7, 5, 10, 8, 6, 11, 7, 9, 5, 8, 10, 6, 9, 7, 8, 4, 3, 0}, {3, 6, 9, 12, 15, 17, 18, 19}, 8, 9,
      {15, 12, 18, 10, 20, 13, 16, 14, 20}, {13, 12, 16, 10, 18, 12, 14, 13, 12}}}};

static int build_innings(Innings *in, int m, int i)
{
    const Raw *r = &RAW[m][i];
    int k, j, w, total = 0, run = 0;

    memset(in, 0, sizeof *in);
    snprintf(in->batting_team, NAME_LEN, "%s", TEAMS[m][i]);
    in->wickets = r->n_wk;
    in->legal_balls = r->balls;
    in->batter_count = (size_t)r->np + 1;
    in->bowler_count = 5;
    in->over_count = (size_t)r->overs;
    in->fow_count = (size_t)r->n_wk;
    in->batters = (Player *)calloc(in->batter_count, sizeof(Player));
    in->bowlers = (Player *)calloc(in->bowler_count, sizeof(Player));
    in->overs = (Over *)calloc(in->over_count, sizeof(Over));
    in->fow = (FallOfWicket *)calloc(in->fow_count > 0 ? in->fow_count : 1, sizeof(FallOfWicket));
    if (!in->batters || !in->bowlers || !in->overs || !in->fow) return 0;

    for (k = 0; k <= r->np; k++) snprintf(in->batters[k].name, NAME_LEN, "%s", ORDER[m][i][k]);
    for (k = 0; k < r->np; k++) {   /* each partnership is shared between its two batters */
        int a = (r->pr[k] + 1) / 2, ab = (r->pb[k] + 1) / 2;
        in->batters[k].runs += a;               in->batters[k + 1].runs += r->pr[k] - a;
        in->batters[k].balls_faced += ab;       in->batters[k + 1].balls_faced += r->pb[k] - ab;
    }
    for (k = 0; k <= r->np; k++) {
        in->batters[k].fours = in->batters[k].runs / 8;
        in->batters[k].sixes = in->batters[k].runs / 20;
    }
    for (j = 0; j < 5; j++) snprintf(in->bowlers[j].name, NAME_LEN, "%s", ORDER[m][1 - i][6 + j]);
    for (k = 0; k < r->overs; k++) {
        w = 0;
        for (j = 0; j < r->n_wk; j++) if (r->wk_over[j] == k) w++;
        in->overs[k].over_number = k + 1;
        in->overs[k].runs = r->runs[k];
        in->overs[k].wickets = w;
        total += r->runs[k];
        in->bowlers[k % 5].balls_bowled += 6;
        in->bowlers[k % 5].runs_conceded += r->runs[k];
        in->bowlers[k % 5].wickets += w;
    }
    in->total_runs = total;
    for (k = 0; k < r->n_wk; k++) {
        run += r->pr[k];
        in->fow[k].wicket_number = k + 1;
        in->fow[k].team_score = run;
        in->fow[k].over_number = r->wk_over[k] + 1;
        in->fow[k].ball_in_over = 3;
        snprintf(in->fow[k].player_out, NAME_LEN, "%s", ORDER[m][i][k]);
    }
    return 1;
}

int sg5_sample_matches(MatchStore *store)
{
    int m, i, ok;
    Match mt;

    for (m = 0; m < 3; m++) {
        memset(&mt, 0, sizeof mt);
        snprintf(mt.match_id, MATCH_ID_LEN, "%s", IDS[m]);
        snprintf(mt.team1, NAME_LEN, "%s", TEAMS[m][0]);
        snprintf(mt.team2, NAME_LEN, "%s", TEAMS[m][1]);
        snprintf(mt.venue, VENUE_LEN, "%s", VENUES[m]);
        snprintf(mt.date, DATE_LEN, "%s", DATES[m]);
        ok = 1;
        for (i = 0; i < 2 && ok; i++) ok = build_innings(&mt.innings[i], m, i);
        ok = ok && store_add_match(store, &mt);
        match_free(&mt);
        if (!ok) return 0;
    }
    return 1;
}
