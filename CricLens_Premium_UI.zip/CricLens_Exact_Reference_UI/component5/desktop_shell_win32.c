/* CricLens desktop shell helpers -- plain C using the Win32 / COM shell APIs. */
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0700
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "desktop_shell_win32.h"

/* ---------------------------------------------------------------- icon art */

typedef struct { double r, g, b, a; } Px;

static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double mixd(double a, double b, double t) { return a + (b - a) * t; }

/* One sample of the icon artwork at (u,v) in [0,1]^2:
 * a navy rounded tile with a gold border, a glowing gold ring and a red cricket ball with seam stitching. */
static Px icon_sample(double u, double v)
{
    Px o = {0, 0, 0, 0};
    const double corner = 0.20, R = 0.255;
    double px = fabs(u - 0.5) - (0.5 - corner), py = fabs(v - 0.5) - (0.5 - corner);
    double ox = px > 0 ? px : 0, oy = py > 0 ? py : 0;
    double inner = px > py ? px : py;
    double d, r, g, b, dx, dy, rr, glow;

    if (inner > 0) inner = 0;
    d = sqrt(ox * ox + oy * oy) + inner - corner;
    if (d > 0) return o;                                   /* outside the rounded tile */

    r = mixd(10, 30, v); g = mixd(18, 36, v); b = mixd(52, 88, v);
    dx = u - 0.5; dy = v - 0.5; rr = sqrt(dx * dx + dy * dy);
    glow = exp(-pow((rr - 0.28) / 0.09, 2.0)) * 0.22;
    r = mixd(r, 246, glow); g = mixd(g, 196, glow); b = mixd(b, 83, glow);

    if (d > -0.038) {                                      /* gold border */
        r = mixd(255, 196, v); g = mixd(214, 142, v); b = mixd(110, 40, v);
    } else if (rr < R) {                                   /* the ball */
        double hx = dx + 0.35 * R, hy = dy + 0.40 * R;
        double h = clampd(sqrt(hx * hx + hy * hy) / (1.6 * R), 0, 1);
        double shade = 1.0 - 0.30 * pow(rr / R, 3.0);
        double ca = cos(0.61), sa = sin(0.61);
        double u2 = dx * ca + dy * sa, v2 = -dx * sa + dy * ca;
        double minor = 0.46 * R;
        double f = sqrt((u2 / R) * (u2 / R) + (v2 / minor) * (v2 / minor));
        double sd = (f - 1.0) * minor;
        double th = atan2(v2 / 0.46, u2);
        r = mixd(255, 196, h) * shade; g = mixd(120, 22, h) * shade; b = mixd(140, 52, h) * shade;
        if (fabs(sd) < 0.007) { r = 140; g = 12; b = 38; }                         /* raised seam */
        else if ((fabs(sd - 0.021) < 0.0055 || fabs(sd + 0.021) < 0.0055) && sin(th * 30.0) > 0.0) {
            r = 246; g = 236; b = 214;                                             /* stitches */
        }
    } else if (rr > R + 0.016 && rr < R + 0.032) {          /* gold ring */
        r = mixd(r, 246, 0.9); g = mixd(g, 196, 0.9); b = mixd(b, 83, 0.9);
    }
    o.r = clampd(r, 0, 255); o.g = clampd(g, 0, 255); o.b = clampd(b, 0, 255); o.a = 1.0;
    return o;
}

void cl_render_icon(unsigned char *bgra, int size)
{
    const int N = 3;
    int x, y, sx, sy;
    for (y = 0; y < size; y++) {
        for (x = 0; x < size; x++) {
            double ar = 0, ag = 0, ab = 0, aa = 0;
            unsigned char *o = bgra + ((size_t)y * (size_t)size + (size_t)x) * 4;
            for (sy = 0; sy < N; sy++) {
                for (sx = 0; sx < N; sx++) {
                    Px p = icon_sample((x + (sx + 0.5) / N) / size, (y + (sy + 0.5) / N) / size);
                    ar += p.r * p.a; ag += p.g * p.a; ab += p.b * p.a; aa += p.a;
                }
            }
            if (aa <= 0) { o[0] = o[1] = o[2] = o[3] = 0; }
            else {
                o[0] = (unsigned char)(ab / aa + 0.5);
                o[1] = (unsigned char)(ag / aa + 0.5);
                o[2] = (unsigned char)(ar / aa + 0.5);
                o[3] = (unsigned char)(255.0 * aa / (N * N) + 0.5);
            }
        }
    }
}

void cl_flatten_icon(unsigned char *p, int size, COLORREF bg)
{
    int i, n = size * size, br = GetRValue(bg), bgc = GetGValue(bg), bb = GetBValue(bg);
    for (i = 0; i < n; i++, p += 4) {
        int a = p[3];
        p[0] = (unsigned char)((p[0] * a + bb * (255 - a)) / 255);
        p[1] = (unsigned char)((p[1] * a + bgc * (255 - a)) / 255);
        p[2] = (unsigned char)((p[2] * a + br * (255 - a)) / 255);
        p[3] = 255;
    }
}

HICON cl_make_hicon(int size)
{
    BITMAPINFO bi;
    void *bits = NULL;
    HDC dc;
    HBITMAP color, mask;
    ICONINFO ii;
    HICON icon;
    size_t stride = (size_t)((size + 15) / 16) * 2;
    unsigned char *mbits;

    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = size;
    bi.bmiHeader.biHeight = -size;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    dc = GetDC(NULL);
    color = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    ReleaseDC(NULL, dc);
    if (!color || !bits) { if (color) DeleteObject(color); return NULL; }
    cl_render_icon((unsigned char *)bits, size);
    mbits = (unsigned char *)calloc(stride * (size_t)size, 1);
    mask = CreateBitmap(size, size, 1, 1, mbits);
    free(mbits);
    ii.fIcon = TRUE; ii.xHotspot = 0; ii.yHotspot = 0; ii.hbmMask = mask; ii.hbmColor = color;
    icon = CreateIconIndirect(&ii);
    DeleteObject(color);
    DeleteObject(mask);
    return icon;
}

/* ------------------------------------------------------------- .ico writer */

static void put16(unsigned char *p, unsigned v) { p[0] = (unsigned char)(v & 255); p[1] = (unsigned char)((v >> 8) & 255); }
static void put32(unsigned char *p, unsigned long v)
{
    p[0] = (unsigned char)(v & 255); p[1] = (unsigned char)((v >> 8) & 255);
    p[2] = (unsigned char)((v >> 16) & 255); p[3] = (unsigned char)((v >> 24) & 255);
}

int cl_write_ico_file(const char *path)
{
    static const int sizes[7] = {16, 24, 32, 48, 64, 128, 256};
    const int n = 7;
    size_t img[7], total = 6 + 16 * (size_t)n, off, i;
    unsigned char *buf, *tmp;
    FILE *f;
    int ok;

    for (i = 0; i < (size_t)n; i++) {
        size_t s = (size_t)sizes[i], and_stride = ((s + 31) / 32) * 4;
        img[i] = 40 + s * s * 4 + and_stride * s;
        total += img[i];
    }
    buf = (unsigned char *)calloc(total, 1);
    if (!buf) return 0;
    put16(buf, 0); put16(buf + 2, 1); put16(buf + 4, (unsigned)n);
    off = 6 + 16 * (size_t)n;
    for (i = 0; i < (size_t)n; i++) {
        int s = sizes[i], y;
        size_t and_stride = (((size_t)s + 31) / 32) * 4;
        unsigned char *e = buf + 6 + 16 * i, *im = buf + off;
        e[0] = (unsigned char)(s >= 256 ? 0 : s); e[1] = e[0]; e[2] = 0; e[3] = 0;
        put16(e + 4, 1); put16(e + 6, 32); put32(e + 8, (unsigned long)img[i]); put32(e + 12, (unsigned long)off);
        put32(im, 40); put32(im + 4, (unsigned long)s); put32(im + 8, (unsigned long)s * 2);
        put16(im + 12, 1); put16(im + 14, 32); put32(im + 16, 0);
        put32(im + 20, (unsigned long)((size_t)s * (size_t)s * 4 + and_stride * (size_t)s));
        tmp = (unsigned char *)malloc((size_t)s * (size_t)s * 4);
        if (!tmp) { free(buf); return 0; }
        cl_render_icon(tmp, s);
        for (y = 0; y < s; y++)                          /* ICO pixel rows are stored bottom-up */
            memcpy(im + 40 + (size_t)(s - 1 - y) * (size_t)s * 4, tmp + (size_t)y * (size_t)s * 4, (size_t)s * 4);
        free(tmp);
        off += img[i];
    }
    f = fopen(path, "wb");
    ok = f && fwrite(buf, 1, total, f) == total;
    if (f) fclose(f);
    free(buf);
    return ok;
}

/* --------------------------------------------------------------- shortcuts */

static int make_link(const char *lnk, const char *exe, const char *dir, const char *icon)
{
    IShellLinkA *sl = NULL;
    IPersistFile *pf = NULL;
    WCHAR wide[MAX_PATH];
    int ok = 0;

    if (FAILED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkA, (void **)&sl)) || !sl)
        return 0;
    sl->lpVtbl->SetPath(sl, exe);
    sl->lpVtbl->SetWorkingDirectory(sl, dir);
    sl->lpVtbl->SetDescription(sl, "CricLens - Cricket Analytics Desktop");
    sl->lpVtbl->SetIconLocation(sl, icon, 0);
    if (SUCCEEDED(sl->lpVtbl->QueryInterface(sl, &IID_IPersistFile, (void **)&pf)) && pf) {
        MultiByteToWideChar(CP_ACP, 0, lnk, -1, wide, MAX_PATH);
        ok = SUCCEEDED(pf->lpVtbl->Save(pf, wide, TRUE));
        pf->lpVtbl->Release(pf);
    }
    sl->lpVtbl->Release(sl);
    return ok;
}

int cl_install_shortcuts(char *msg, size_t msg_size)
{
    char exe[MAX_PATH], dir[MAX_PATH], ico[MAX_PATH + 16], folder[MAX_PATH], lnk[MAX_PATH + 16];
    char *slash;
    int made = 0, have_ico, desktop_ok = 0, start_ok = 0;
    HRESULT hr;

    GetModuleFileNameA(NULL, exe, MAX_PATH);
    strncpy(dir, exe, MAX_PATH - 1); dir[MAX_PATH - 1] = 0;
    slash = strrchr(dir, '\\');
    if (slash) *slash = 0;
    snprintf(ico, sizeof ico, "%s\\CricLens.ico", dir);
    have_ico = cl_write_ico_file(ico);

    hr = CoInitialize(NULL);
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_DESKTOPDIRECTORY, NULL, 0, folder))) {
        snprintf(lnk, sizeof lnk, "%s\\CricLens.lnk", folder);
        desktop_ok = make_link(lnk, exe, dir, have_ico ? ico : exe);
    }
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_PROGRAMS, NULL, 0, folder))) {
        snprintf(lnk, sizeof lnk, "%s\\CricLens.lnk", folder);
        start_ok = make_link(lnk, exe, dir, have_ico ? ico : exe);
    }
    if (SUCCEEDED(hr)) CoUninitialize();
    made = desktop_ok + start_ok;

    if (msg && msg_size) {
        if (made == 2) snprintf(msg, msg_size, "CricLens shortcuts created on your Desktop and in the Start Menu.");
        else if (desktop_ok) snprintf(msg, msg_size, "CricLens shortcut created on your Desktop.");
        else if (start_ok) snprintf(msg, msg_size, "CricLens shortcut created in the Start Menu.");
        else snprintf(msg, msg_size, "Could not create the shortcuts. You can create one manually from CricLens.exe.");
    }
    return made;
}

/* ------------------------------------------------------- window appearance */

void cl_apply_dark_titlebar(HWND hwnd, COLORREF caption)
{
    typedef HRESULT (WINAPI *DwmSetFn)(HWND, DWORD, LPCVOID, DWORD);
    HMODULE dwm = LoadLibraryA("dwmapi.dll");
    DwmSetFn fn;
    if (!dwm) return;
    fn = (DwmSetFn)(void *)GetProcAddress(dwm, "DwmSetWindowAttribute");
    if (fn) {
        BOOL dark = TRUE;
        COLORREF text = RGB(246, 196, 83);
        fn(hwnd, 20, &dark, sizeof dark);          /* DWMWA_USE_IMMERSIVE_DARK_MODE */
        fn(hwnd, 35, &caption, sizeof caption);    /* DWMWA_CAPTION_COLOR (Windows 11) */
        fn(hwnd, 36, &text, sizeof text);          /* DWMWA_TEXT_COLOR (Windows 11) */
    }
    FreeLibrary(dwm);
}

void cl_enable_dpi_awareness(void)
{
    typedef BOOL (WINAPI *DpiFn)(void);
    HMODULE u = GetModuleHandleA("user32.dll");
    DpiFn fn = u ? (DpiFn)(void *)GetProcAddress(u, "SetProcessDPIAware") : NULL;
    if (fn) fn();
}
