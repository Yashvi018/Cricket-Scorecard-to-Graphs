#ifndef DESKTOP_SHELL_WIN32_H
#define DESKTOP_SHELL_WIN32_H
/* Windows "desktop application" helpers for CricLens, written in plain C.
 *  - the CricLens app icon is rasterised in code (no image files needed)
 *  - a multi-size .ico file is written so shortcuts can use it
 *  - Desktop and Start Menu shortcuts are created through the Windows shell COM API
 *  - DPI awareness and a dark, brand-coloured title bar
 */
#include <windows.h>

/* Straight (non-premultiplied) top-down BGRA pixels, size x size. */
void  cl_render_icon(unsigned char *bgra, int size);
/* Composite an icon buffer over a solid colour and make it fully opaque. */
void  cl_flatten_icon(unsigned char *bgra, int size, COLORREF background);
HICON cl_make_hicon(int size);
int   cl_write_ico_file(const char *path);
/* Writes CricLens.ico next to the .exe, then creates the Desktop and Start Menu
 * shortcuts. Returns the number of shortcuts created; msg receives a summary. */
int   cl_install_shortcuts(char *msg, size_t msg_size);
void  cl_apply_dark_titlebar(HWND hwnd, COLORREF caption);
void  cl_enable_dpi_awareness(void);
#endif
