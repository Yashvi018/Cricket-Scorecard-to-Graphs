/* Partnership chart: runs added by each partnership (worked out by the statistics engine). */
#include "sg5_viz.h"

void sg5_partnership_show(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_PSHIPS];
    char lab[SG5_MAX_PSHIPS][40];
    int i, rc;

    for (i = 0; i < p->num_partnerships; i++) {
        snprintf(lab[i], sizeof lab[i], "%.14s-%.14s%s", p->pship_bat1[i], p->pship_bat2[i], p->pship_unbeaten[i] ? "*" : "");
        pts[i].label = lab[i];
        pts[i].value = p->pship_runs[i];
    }
    printf("\nPartnerships: %s (* = not out)\n", p->team);
    rc = chart_ascii(CHART_BAR, pts, p->num_partnerships);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_partnership_svg(FILE *f, const InningsPlot *p)
{
    static const char *pal[5] = {"#2dd4bf", "#a78bfa", "#60a5fa", "#fb923c", "#f4d58d"};
    int i, mp = 1;

    for (i = 0; i < p->num_partnerships; i++) if (p->pship_runs[i] > mp) mp = p->pship_runs[i];
    fprintf(f, "<svg class=sv viewBox='0 0 500 %d' role=img aria-label='Partnership runs'>", p->num_partnerships * 24 + 12);
    for (i = 0; i < p->num_partnerships; i++) {
        double w = p->pship_runs[i] * 300.0 / mp;
        fprintf(f, "<text x=0 y=%d>%.12s-%.12s</text><rect x=130 y=%d width=%g height=16 rx=4 fill='%s'/><text x=%g y=%d>%d runs%s</text>",
                22 + i * 24, p->pship_bat1[i], p->pship_bat2[i], 10 + i * 24, w, pal[i % 5], 136 + w, 22 + i * 24,
                p->pship_runs[i], p->pship_unbeaten[i] ? " (not out)" : "");
    }
    fputs("</svg>", f);
}
