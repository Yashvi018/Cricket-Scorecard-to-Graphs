/* Adapter: the only subgroup 5 file that reads Component 2's Match structs directly. */
#include <string.h>
#include "sg5_viz.h"
#include "component1_match_loader.h"

static MatchStore g_store;

int sg5_init(void)
{
    store_init(&g_store);
    if (!sg5_sample_matches(&g_store)) {
        store_free(&g_store);
        return 0;
    }
    return 1;
}

void sg5_shutdown(void)
{
    store_free(&g_store);
}

int sg5_match_count(void)
{
    return (int)g_store.count;
}

void sg5_match_title(int index, char *buf, size_t size)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    if (m) snprintf(buf, size, "%s v %s", m->team1, m->team2);
    else snprintf(buf, size, "(no match)");
}

static void fill_innings(const Innings *in, InningsPlot *p)
{
    Partnership ps[SG5_MAX_PSHIPS];
    int i, n;

    memset(p, 0, sizeof *p);
    snprintf(p->team, NAME_LEN, "%s", in->batting_team);
    p->total_runs = in->total_runs;
    p->wickets = in->wickets;
    p->balls = in->legal_balls;
    p->overs = stats_over_runs(in, p->runs_per_over, SG5_MAX_OVERS);
    stats_cumulative_runs(in, p->cumulative_runs, SG5_MAX_OVERS);
    stats_over_wickets(in, p->wicket_in_over, SG5_MAX_OVERS);
    n = stats_partnerships(in, ps, SG5_MAX_PSHIPS);
    for (i = 0; i < n; i++) {
        snprintf(p->pship_bat1[i], NAME_LEN, "%.49s", ps[i].bat1);
        snprintf(p->pship_bat2[i], NAME_LEN, "%.49s", ps[i].bat2);
        p->pship_runs[i] = ps[i].runs;
        p->pship_unbeaten[i] = ps[i].unbeaten;
    }
    p->num_partnerships = n;
}

int sg5_load_match(int index, Sg5Match *out)
{
    const Match *m = store_get_match(&g_store, (size_t)index);

    if (!m || !out) return -1;
    memset(out, 0, sizeof *out);
    snprintf(out->info.title, sizeof out->info.title, "%s v %s", m->team1, m->team2);
    snprintf(out->info.venue, VENUE_LEN, "%s", m->venue);
    snprintf(out->info.date, DATE_LEN, "%s", m->date);
    fill_innings(&m->innings[0], &out->in[0]);
    fill_innings(&m->innings[1], &out->in[1]);
    if (!stats_awards(m, &out->aw) || !stats_result(m, out->result, sizeof out->result)) return -1;
    return 0;
}

int sg5_add_from_file(const char *path, char *error, size_t error_size)
{
    Match m;
    int ok;

    memset(&m, 0, sizeof m);
    if (!load_match_file(path, &m, error, error_size)) return 0;
    ok = store_add_match(&g_store, &m);
    match_free(&m);
    if (!ok && error && error_size) snprintf(error, error_size, "the match could not be stored");
    return ok;
}

int sg5_max_over_runs(const Sg5Match *m)
{
    int i, k, mx = 10;

    for (i = 0; i < 2; i++)
        for (k = 0; k < m->in[i].overs; k++)
            if (m->in[i].runs_per_over[k] > mx) mx = m->in[i].runs_per_over[k];
    return mx;
}
