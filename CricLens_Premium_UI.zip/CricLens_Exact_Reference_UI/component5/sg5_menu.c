/* Terminal menu with safe input (fgets + strtol). */
#include <stdlib.h>
#include <string.h>
#include "sg5_viz.h"

static int read_int(const char *prompt, int lo, int hi)
{
    char buf[64], *end;
    long v;

    for (;;) {
        printf("%s", prompt);
        if (fgets(buf, sizeof buf, stdin) == NULL) return lo;
        v = strtol(buf, &end, 10);
        if (end != buf && (*end == '\n' || *end == '\0') && v >= lo && v <= hi) return (int)v;
        printf("Please enter a number from %d to %d.\n", lo, hi);
    }
}

void sg5_menu_run(void)
{
    Sg5Match m;
    char path[200], err[200], title[140];
    int sel = 0, c, i;

    if (sg5_load_match(sel, &m) != 0) {
        printf("No match data available.\n");
        return;
    }
    for (;;) {
        printf("\n=== CricLens ===  Current: %s\n", m.info.title);
        printf("1 Choose match   2 Worm chart   3 Manhattan (1st)   4 Manhattan (2nd)\n");
        printf("5 Partnerships (1st)   6 Partnerships (2nd)   7 Awards   8 Load a scorecard file   0 Exit\n");
        c = read_int("Choice: ", 0, 8);
        switch (c) {
        case 1:
            for (i = 0; i < sg5_match_count(); i++) {
                sg5_match_title(i, title, sizeof title);
                printf("  %d. %s\n", i + 1, title);
            }
            sel = read_int("Match number: ", 1, sg5_match_count()) - 1;
            if (sg5_load_match(sel, &m) != 0) printf("Could not load that match.\n");
            else printf("%s\n", m.result);
            break;
        case 2: sg5_worm_show(&m); break;
        case 3: sg5_manhattan_show(&m.in[0]); break;
        case 4: sg5_manhattan_show(&m.in[1]); break;
        case 5: sg5_partnership_show(&m.in[0]); break;
        case 6: sg5_partnership_show(&m.in[1]); break;
        case 7: sg5_awards_show(&m); break;
        case 8:
            printf("Scorecard file path: ");
            if (fgets(path, sizeof path, stdin) != NULL) {
                path[strcspn(path, "\r\n")] = '\0';
                if (sg5_add_from_file(path, err, sizeof err)) {
                    sel = sg5_match_count() - 1;
                    if (sg5_load_match(sel, &m) == 0) printf("Loaded. %s\n", m.result);
                } else {
                    printf("Could not load the file: %s\n", err);
                }
            }
            break;
        default: return;
        }
    }
}
