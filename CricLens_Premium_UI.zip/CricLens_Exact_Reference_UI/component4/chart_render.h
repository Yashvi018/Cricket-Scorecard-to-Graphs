#ifndef CHART_RENDER_H
#define CHART_RENDER_H
/* Component 4: Graph rendering engine. Public interface.
   Draws bar, line and pie charts as ASCII text, SVG files or BMP files. */

#ifndef DATAPOINT_DEFINED
#define DATAPOINT_DEFINED
typedef struct {
    const char *label;
    double value;
} DataPoint;
#endif

typedef enum { CHART_BAR = 0, CHART_LINE = 1, CHART_PIE = 2 } ChartKind;

#define CHART_OK        0
#define CHART_ERR_ARGS  (-1)   /* no data, negative or all-zero values, line chart with fewer than 2 points */
#define CHART_ERR_FILE  (-2)   /* output file could not be written */

/* Up to 1000 points. Labels must not be NULL. Data is not modified or kept. */
int chart_ascii(ChartKind kind, const DataPoint *data, int count);
int chart_svg(const char *path, ChartKind kind, const char *title, const DataPoint *data, int count);
int chart_bmp(const char *path, ChartKind kind, const DataPoint *data, int count);   /* no text labels in BMP */
const char *chart_error_message(int code);

#endif
