/*
 * Component 4: Graph Rendering Engine (module; test_render.c has the demo)
 *
 * Features:
 *   - Bar, line, and pie charts
 *   - ASCII terminal rendering
 *   - SVG vector output
 *   - 24-bit uncompressed BMP output
 *   - Static mock data; no external libraries
 *
 * Build: see README.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#define MAX_CHART_POINTS 1000
#define PALETTE_N 5
#define CANVAS_W 800
#define CANVAS_H 500
#define LEFT 70
#define RIGHT 40
#define TOP 55
#define BOTTOM 70
#define PI 3.14159265358979323846

#include "chart_render.h"
typedef struct { unsigned char r, g, b; } Color;
typedef struct { int w, h; Color *pixels; } Canvas;

static const DataPoint *g_data;   /* set by the public functions below */
static int g_n;
static const Color PALETTE[PALETTE_N] = {
    {52, 120, 200}, {230, 126, 34}, {46, 160, 67},
    {155, 89, 182}, {220, 65, 80}
};

static double max_value(void) {
    double m = 0.0; int i;
    for (i = 0; i < g_n; ++i) if (g_data[i].value > m) m = g_data[i].value;
    return m;
}
static double total_value(void) {
    double s = 0.0; int i;
    for (i = 0; i < g_n; ++i) s += g_data[i].value;
    return s;
}
static void color_hex(Color c, char out[8]) {
    (void)snprintf(out, 8, "#%02X%02X%02X", c.r, c.g, c.b);
}

/* ----------------------------- ASCII ----------------------------------- */
static void ascii_bar(void) {
    int i, n; printf("\n=== BAR CHART (ASCII) ===\n");
    for (i = 0; i < g_n; ++i) {
        n = (int)(g_data[i].value / max_value() * 40.0 + 0.5);
        printf("%-16.16s | ", g_data[i].label);
        while (n-- > 0) putchar('#');
        printf(" %.0f\n", g_data[i].value);
    }
}
static void ascii_line(void) {
    int row, col, i; const int width = 50, height = 12;
    char grid[13][51];
    memset(grid, ' ', sizeof(grid));
    for (row = 0; row < height; ++row) grid[row][width] = '\0';
    for (i = 0; i < g_n; ++i) {
        int x = i * (width - 1) / (g_n - 1);
        int y = height - 1 - (int)(g_data[i].value / max_value() * (height - 1));
        grid[y][x] = '*';
        if (i > 0) {
            int px = (i - 1) * (width - 1) / (g_n - 1);
            int py = height - 1 - (int)(g_data[i - 1].value / max_value() * (height - 1));
            int dx = x - px, dy = y - py, steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy), k;
            for (k = 1; k < steps; ++k) {
                int xx = px + (int)lround((double)dx * k / steps);
                int yy = py + (int)lround((double)dy * k / steps);
                if (xx >= 0 && xx < width && yy >= 0 && yy < height && grid[yy][xx] == ' ') grid[yy][xx] = '.';
            }
        }
    }
    printf("\n=== LINE CHART (ASCII) ===\n");
    for (row = 0; row < height; ++row) printf("%3d | %s\n", (height - 1 - row) * (int)(max_value() / (height - 1)), grid[row]);
    printf("    +--------------------------------------------------\n     ");
    { char axis[64]; int last = -1, len, pos, j; memset(axis, ' ', sizeof(axis)); axis[62] = '\0';
      for (i = 0; i < g_n; ++i) { pos = i * (width - 1) / (g_n - 1); len = (int)strlen(g_data[i].label);
        if (pos > last && pos + len <= 62) { for (j = 0; j < len; ++j) axis[pos + j] = g_data[i].label[j]; last = pos + len; } }
      printf("%s", axis); }
    putchar('\n');
    (void)col;
}
static void ascii_pie(void) {
    int i; double total = total_value();
    printf("\n=== PIE CHART (ASCII SHARE BARS) ===\n");
    for (i = 0; i < g_n; ++i) {
        int n = (int)(g_data[i].value / total * 40.0 + 0.5);
        printf("%-16.16s | ", g_data[i].label);
        while (n-- > 0) putchar('#');
        printf(" %5.1f%%\n", g_data[i].value / total * 100.0);
    }
    printf("(ASCII uses proportional share bars; SVG/BMP render a true pie.)\n");
}

/* ------------------------ Minimal raster drawing ----------------------- */
static Canvas canvas_create(int w, int h, Color bg) {
    Canvas c; size_t i, count = (size_t)w * (size_t)h;
    c.w = w; c.h = h; c.pixels = (Color *)malloc(count * sizeof(Color));
    if (!c.pixels) { fprintf(stderr, "Out of memory creating canvas\n"); exit(EXIT_FAILURE); }
    for (i = 0; i < count; ++i) c.pixels[i] = bg;
    return c;
}
static void pixel(Canvas *c, int x, int y, Color color) {
    if (x >= 0 && x < c->w && y >= 0 && y < c->h) c->pixels[(size_t)y * c->w + x] = color;
}
static void line(Canvas *c, int x0, int y0, int x1, int y1, Color color) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) { int e2; pixel(c, x0, y0, color); if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
static void rect_fill(Canvas *c, int x0, int y0, int x1, int y1, Color color) {
    int x, y; if (x0 > x1) { int t=x0; x0=x1; x1=t; } if (y0 > y1) { int t=y0; y0=y1; y1=t; }
    for (y = y0; y <= y1; ++y) for (x = x0; x <= x1; ++x) pixel(c, x, y, color);
}
static void circle_wedge(Canvas *c, int cx, int cy, int r, double a0, double a1, Color color) {
    int x, y;
    for (y = cy-r; y <= cy+r; ++y) for (x = cx-r; x <= cx+r; ++x) {
        double dx=x-cx, dy=cy-y, a, rr=dx*dx+dy*dy;
        if (rr > (double)r*r) continue;
        a = atan2(dy, dx); if (a < 0) a += 2*PI;
        if (a0 <= a1 ? (a >= a0 && a <= a1) : (a >= a0 || a <= a1)) pixel(c,x,y,color);
    }
}
static void bmp_u16(FILE *f, uint16_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); }
static void bmp_u32(FILE *f, uint32_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); fputc((v >> 16) & 255, f); fputc((v >> 24) & 255, f); }
static int write_bmp(const char *path, const Canvas *c) {
    FILE *f = fopen(path, "wb"); int x, y; uint32_t row_size = ((uint32_t)c->w * 3u + 3u) & ~3u;
    uint32_t image_size = row_size * (uint32_t)c->h;
    if (!f) { perror(path); return 0; }
    fputc('B', f); fputc('M', f); bmp_u32(f, 54u + image_size); bmp_u16(f,0); bmp_u16(f,0); bmp_u32(f,54);
    bmp_u32(f,40); bmp_u32(f,(uint32_t)c->w); bmp_u32(f,(uint32_t)c->h); bmp_u16(f,1); bmp_u16(f,24);
    bmp_u32(f,0); bmp_u32(f,image_size); bmp_u32(f,2835); bmp_u32(f,2835); bmp_u32(f,0); bmp_u32(f,0);
    for (y = c->h - 1; y >= 0; --y) {
        for (x = 0; x < c->w; ++x) { Color p = c->pixels[(size_t)y*c->w+x]; fputc(p.b,f); fputc(p.g,f); fputc(p.r,f); }
        for (x = c->w * 3; x < (int)row_size; ++x) fputc(0,f);
    }
    if (fclose(f) != 0) { perror("closing BMP"); return 0; } return 1;
}
static void canvas_free(Canvas *c) { free(c->pixels); c->pixels = NULL; }

/* Simple bitmap-style labels are intentionally omitted from BMP: the test
   focuses on chart geometry, color regions, axes, and output file validity. */
static Canvas raster_chart(int kind) {
    Color white={255,255,255}, black={35,35,35}, grey={220,220,220};
    Canvas c=canvas_create(CANVAS_W,CANVAS_H,white); int i;
    int plot_h=CANVAS_H-TOP-BOTTOM, plot_w=CANVAS_W-LEFT-RIGHT;
    if (kind == 2) {
        double a=0.0, total=total_value();
        for (i=0;i<g_n;++i) { double next=a+2*PI*g_data[i].value/total; circle_wedge(&c, CANVAS_W/2, CANVAS_H/2, 170, a, next, PALETTE[i % PALETTE_N]); a=next; }
        return c;
    }
    line(&c,LEFT,TOP,LEFT,CANVAS_H-BOTTOM,black); line(&c,LEFT,CANVAS_H-BOTTOM,CANVAS_W-RIGHT,CANVAS_H-BOTTOM,black);
    for (i=1;i<=5;++i) { int y=CANVAS_H-BOTTOM-(plot_h*i/5); line(&c,LEFT,y,CANVAS_W-RIGHT,y,grey); }
    if (kind == 0) {
        int slot=plot_w/g_n, bar_w=slot*55/100;
        for (i=0;i<g_n;++i) { int h=(int)(g_data[i].value/max_value()*(plot_h-10)); int x=LEFT+i*slot+(slot-bar_w)/2; rect_fill(&c,x,CANVAS_H-BOTTOM-h,x+bar_w,CANVAS_H-BOTTOM-1,PALETTE[i % PALETTE_N]); }
    } else {
        int px[g_n], py[g_n];
        for (i=0;i<g_n;++i) { px[i]=LEFT+i*plot_w/(g_n-1); py[i]=CANVAS_H-BOTTOM-(int)(g_data[i].value/max_value()*(plot_h-10)); }
        for (i=0;i<g_n-1;++i) line(&c,px[i],py[i],px[i+1],py[i+1],PALETTE[0]);
        for (i=0;i<g_n;++i) rect_fill(&c,px[i]-5,py[i]-5,px[i]+5,py[i]+5,PALETTE[i % PALETTE_N]);
    }
    return c;
}

/* ------------------------------ SVG ------------------------------------ */
static int svg_bar(FILE *f) {
    int i, slot=600/g_n, bw=slot*55/100; double max=max_value();
    fprintf(f,"<line x1='70' y1='420' x2='760' y2='420' stroke='#222'/><line x1='70' y1='55' x2='70' y2='420' stroke='#222'/>\n");
    for (i=0;i<g_n;++i) { int h=(int)(g_data[i].value/max*330); int x=70+i*slot+(slot-bw)/2; char hex[8]; color_hex(PALETTE[i % PALETTE_N],hex);
        fprintf(f,"<rect x='%d' y='%d' width='%d' height='%d' fill='%s'/><text x='%d' y='445' text-anchor='middle' font-size='14'>%s</text><text x='%d' y='%d' text-anchor='middle' font-size='13'>%.0f</text>\n",x,420-h,bw,h,hex,x+bw/2,g_data[i].label,x+bw/2,415-h,g_data[i].value);
    } return 1;
}
static int svg_line(FILE *f) {
    int i, x[g_n],y[g_n]; double max=max_value();
    fprintf(f,"<line x1='70' y1='420' x2='760' y2='420' stroke='#222'/><line x1='70' y1='55' x2='70' y2='420' stroke='#222'/>\n");
    for(i=0;i<g_n;++i){x[i]=70+i*690/(g_n-1);y[i]=420-(int)(g_data[i].value/max*330);}
    for(i=0;i<g_n-1;++i) fprintf(f,"<line x1='%d' y1='%d' x2='%d' y2='%d' stroke='#3478C8' stroke-width='3'/>\n",x[i],y[i],x[i+1],y[i+1]);
    for(i=0;i<g_n;++i) fprintf(f,"<circle cx='%d' cy='%d' r='6' fill='%s'/><text x='%d' y='445' text-anchor='middle' font-size='14'>%s</text><text x='%d' y='%d' text-anchor='middle' font-size='13'>%.0f</text>\n",x[i],y[i],"#3478C8",x[i],g_data[i].label,x[i],y[i]-12,g_data[i].value);
    return 1;
}
static int svg_pie(FILE *f) {
    double a= -PI/2, total=total_value(); int i; const double cx=400,cy=250,r=170;
    for(i=0;i<g_n;++i){ double next=a+2*PI*g_data[i].value/total; double x1=cx+r*cos(a),y1=cy+r*sin(a),x2=cx+r*cos(next),y2=cy+r*sin(next); char hex[8]; color_hex(PALETTE[i % PALETTE_N],hex);
        fprintf(f,"<path d='M %.2f %.2f L %.2f %.2f A %.2f %.2f 0 %d 1 %.2f %.2f Z' fill='%s' stroke='white' stroke-width='2'/>\n",cx,cy,x1,y1,r,r,(next-a)>PI?1:0,x2,y2,hex); a=next;
    }
    for(i=0;i<g_n;++i){char hex[8];color_hex(PALETTE[i % PALETTE_N],hex);fprintf(f,"<rect x='620' y='%d' width='14' height='14' fill='%s'/><text x='642' y='%d' font-size='14'>%s (%.1f%%)</text>\n",130+i*30,hex,142+i*30,g_data[i].label,g_data[i].value/total*100.0);}
    return 1;
}
static int write_svg(const char *path, int kind, const char *title) {
    FILE *f=fopen(path,"w"); if(!f){perror(path);return 0;}
    fprintf(f,"<?xml version='1.0' encoding='UTF-8'?>\n<svg xmlns='http://www.w3.org/2000/svg' width='800' height='500' viewBox='0 0 800 500'>\n<rect width='100%%' height='100%%' fill='white'/><text x='400' y='30' text-anchor='middle' font-size='22' font-family='sans-serif'>%s</text>\n",title);
    if(kind==0) svg_bar(f); else if(kind==1) svg_line(f); else svg_pie(f);
    fprintf(f,"</svg>\n"); if(fclose(f)!=0){perror("closing SVG");return 0;} return 1;
}


/* ------------------------- Public interface --------------------------- */
static int set_data(ChartKind kind, const DataPoint *d, int n) {
    int i;
    if (!d || n < 1 || n > MAX_CHART_POINTS || (int)kind < 0 || (int)kind > 2 || (kind == CHART_LINE && n < 2))
        return CHART_ERR_ARGS;
    for (i = 0; i < n; ++i)
        if (!d[i].label || d[i].value < 0.0) return CHART_ERR_ARGS;
    g_data = d; g_n = n;
    return max_value() > 0.0 ? CHART_OK : CHART_ERR_ARGS;
}

int chart_ascii(ChartKind kind, const DataPoint *data, int count) {
    int rc = set_data(kind, data, count);
    if (rc != CHART_OK) return rc;
    if (kind == CHART_BAR) ascii_bar(); else if (kind == CHART_LINE) ascii_line(); else ascii_pie();
    return CHART_OK;
}

int chart_svg(const char *path, ChartKind kind, const char *title, const DataPoint *data, int count) {
    int rc = set_data(kind, data, count);
    if (rc != CHART_OK || !path) return CHART_ERR_ARGS;
    return write_svg(path, (int)kind, title ? title : "Chart") ? CHART_OK : CHART_ERR_FILE;
}

int chart_bmp(const char *path, ChartKind kind, const DataPoint *data, int count) {
    Canvas c; int ok, rc = set_data(kind, data, count);
    if (rc != CHART_OK || !path) return CHART_ERR_ARGS;
    c = raster_chart((int)kind);
    ok = write_bmp(path, &c);
    canvas_free(&c);
    return ok ? CHART_OK : CHART_ERR_FILE;
}

const char *chart_error_message(int code) {
    switch (code) {
    case CHART_OK:       return "OK";
    case CHART_ERR_ARGS: return "Invalid chart data (empty, negative, all zero, or too few points).";
    case CHART_ERR_FILE: return "Could not write the chart file.";
    default:             return "Unknown chart error.";
    }
}
