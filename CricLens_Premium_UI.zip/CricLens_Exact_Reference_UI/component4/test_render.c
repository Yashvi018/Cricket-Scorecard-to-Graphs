/* Demo for Component 4: draws the original five-team test data in all formats. */
#include <stdio.h>
#include "chart_render.h"

int main(void)
{
    static const DataPoint data[5] = {{"Tigers", 78}, {"Eagles", 92}, {"Sharks", 64}, {"Falcons", 85}, {"Wolves", 71}};
    static const char *names[3] = {"bar", "line", "pie"};
    char path[64];
    int k, rc, ok = 1;

    for (k = 0; k < 3; ++k) {
        rc = chart_ascii((ChartKind)k, data, 5);
        if (rc != CHART_OK) { printf("%s\n", chart_error_message(rc)); ok = 0; }
        snprintf(path, sizeof path, "chart_%s.svg", names[k]);
        if (chart_svg(path, (ChartKind)k, "Mock Cricket Scores", data, 5) == CHART_OK) printf("Wrote %s\n", path); else ok = 0;
        snprintf(path, sizeof path, "chart_%s.bmp", names[k]);
        if (chart_bmp(path, (ChartKind)k, data, 5) == CHART_OK) printf("Wrote %s\n", path); else ok = 0;
    }
    printf(ok ? "\nPASS\n" : "\nFAIL\n");
    return ok ? 0 : 1;
}
