@echo off
setlocal
cd /d "%~dp0"
where gcc >nul 2>nul
if errorlevel 1 (
  echo GCC was not found.
  echo Install MSYS2 with the UCRT64 GCC toolchain, then add its ucrt64\bin folder to PATH.
  echo Download: https://www.msys2.org/
  pause
  exit /b 1
)
echo Building CricLens native Windows desktop application...
gcc -std=gnu99 -O2 -Wall -Wextra -Icomponent1 -Icomponent2 -Icomponent3 -Icomponent4 -Icomponent5 ^
 component1\component1_input_parser.c component1\component1_match_loader.c ^
 component2\match_store.c component2\match_validate.c ^
 component3\stats_engine.c component3\stats_legacy_compat.c ^
 component4\chart_render.c ^
 component5\sg5_adapter.c component5\sg5_awards.c component5\sg5_manhattan.c ^
 component5\sg5_partnership.c component5\sg5_sample_data.c component5\sg5_worm.c ^
 component5\sg5_menu.c component5\desktop_shell_win32.c component5\desktop_gui_win32.c ^
 -o CricLens.exe -static -s -mwindows -lm -lgdi32 -luser32 -lcomdlg32 -lshell32 -lole32 -luuid
if errorlevel 1 (
  echo Build failed. See compiler messages above.
  pause
  exit /b 1
)
echo Build successful. Creating Desktop and Start Menu shortcuts...
"%~dp0CricLens.exe" --install --quiet
echo Starting CricLens...
start "" "%~dp0CricLens.exe"
endlocal
