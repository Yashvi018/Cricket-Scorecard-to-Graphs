# CricLens test report

## Verified in the Linux build environment
- `make test` passes (Components 1-4 and the legacy compatibility layer).
- `desktop_gui_win32.c` and `desktop_shell_win32.c` pass a syntax/type check (`-Wall -Wextra`, also `-std=c99 -pedantic`)
  against a stand-in Win32 header. This catches typos and type errors but is NOT a real Windows compile.
- The icon rasteriser and `.ico` writer were executed natively: the `.ico` contains 7 sizes (16-256 px) and
  decodes with an independent image reader; the rendered icon was inspected visually.

## Still to verify on a Windows PC (MSYS2 UCRT64 GCC)
- `build_windows.bat` compiles and links without errors.
- Splash, dashboard, hover tooltips, animations and all six views look and behave as intended.
- Desktop and Start Menu shortcuts are created and the desktop icon launches the app.
- Import scorecard (Ctrl+O) and image export (Ctrl+S).
