@echo off
cd /d "%~dp0"
if not exist CricLens.exe (
  echo CricLens.exe not found. Run build_windows.bat first.
  pause
  exit /b 1
)
CricLens.exe --install
