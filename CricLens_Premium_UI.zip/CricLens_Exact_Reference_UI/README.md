# CricLens — Integrated C Project

This folder combines the five CricLens subgroups and uses the improved Component 3 statistics engine.

## Components

- **Component 1 — Input and parsing** (`component1/`): parses scorecard files and loads match data.
- **Component 2 — Data model and storage** (`component2/`): shared `Match`/`Innings`/`Player` structures, validation, and storage.
- **Component 3 — Statistics** (`component3/stats_engine.c`, `stats_engine.h`): improved statistics calculations, validation, innings summaries, required run rate, and graph-ready series. Its `match_model.h` is kept identical to Component 2's shared header.
- **Component 4 — Graph rendering** (`component4/`): ASCII, SVG, and BMP chart rendering.
- **Component 5 — Charts, menu, and awards** (`component5/`): sample matches, visualizations, partnerships, and awards.

## Integration design

Component 2's `match_model.h` is the canonical shared data model. Component 3's improved API is retained unchanged. Component 5 still calls the earlier statistics API, so `component3/stats_legacy_compat.c` and `stats_legacy_compat.h` provide a compatibility layer for those older calls. This lets the enhanced Component 3 coexist with the existing Components 4 and 5 without changing their public interfaces.

## Requirements

- GCC or another C99-compatible compiler
- GNU Make
- Standard C math library (`-lm`, already included in the Makefile)

## Build

From this directory:

```sh
make
```

This creates the `criclens` executable.

## Run

```sh
./criclens
```

The cross-platform command-line build opens the Component 5 text menu and uses its included sample matches. The Windows desktop build opens the native graphical application.

## Test

```sh
make test
```

The test target runs:

1. Improved Component 3 automated tests.
2. Component 3 legacy-API compatibility tests (the bridge used by Component 5).
3. Component 1 scorecard-loader test using `component1/sample_match.txt`.
4. Component 2 storage test.
5. Component 4 chart-rendering test (writes SVG/BMP demo charts).

The Component 1 parser's interactive `name, score` mode can also be tested separately with `./test_parser` or by supplying a data file. The full application itself is built as part of `make test`.

## Important notes

- `component1/sample_match.txt` is the scorecard input example.
- Component 5 currently initializes its own fictional sample matches; it is not automatically loading `sample_match.txt` at startup. Use its file-import option where available to add a parsed scorecard.
- The legacy compatibility module preserves existing Component 5 calls. Batting calculations and over-series data are delegated to the improved Component 3 API; partnership, awards and result functions retain their legacy interface. New code should use the improved API in `stats_engine.h`.

## Native Windows desktop application (C)

The project also includes `component5/desktop_gui_win32.c`, a native graphical Windows application written in C using the Win32 API and GDI. It uses the integrated Components 1–5 and provides match switching, worm/Manhattan/partnership charts, awards, and scorecard import. It does not use HTML, CSS, JavaScript, Electron, or a browser for its desktop interface.

On Windows, install the MSYS2 UCRT64 GCC toolchain and run `build_windows.bat` to build and launch `CricLens.exe`. See `README_DESKTOP_WINDOWS.md` for setup instructions.

The native Windows desktop submission does not include a browser-based interface or a web-export module.


## Native Windows desktop interface

The Windows desktop build uses `component5/desktop_gui_win32.c`, a C/Win32/GDI interface. It includes the polished dark CricLens dashboard with match details, innings score cards, custom navigation, and charts. See `README_DESKTOP_WINDOWS.md` for build and launch instructions.
