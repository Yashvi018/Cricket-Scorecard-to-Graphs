/*
 * CricLens Complete - single-file native Windows desktop application
 * Generated from the supplied CricLens_Dashboard_UI_C_Only project.
 * All application implementation is C; Windows UI uses Win32/GDI.
 * Build with the accompanying Build-CricLens.bat on Windows with MinGW-w64 GCC.
 */

/* ================= HEADER: component2/match_model.h ================= */
#ifndef MATCH_MODEL_H
#define MATCH_MODEL_H

#include <stddef.h>

#define NAME_LEN 50
#define VENUE_LEN 80
#define DATE_LEN 20
#define MATCH_ID_LEN 20

typedef struct {
    char name[NAME_LEN];
    int runs;
    int balls_faced;
    int fours;
    int sixes;
    int wickets;
    int balls_bowled;
    int runs_conceded;
} Player;

typedef struct {
    int over_number;
    int runs;
    int wickets;
} Over;

typedef struct {
    int wicket_number;
    int team_score;
    int over_number;
    int ball_in_over;
    char player_out[NAME_LEN];
} FallOfWicket;

typedef struct {
    char batting_team[NAME_LEN];
    int total_runs;
    int wickets;
    int legal_balls;

    Player *batters;
    size_t batter_count;

    Player *bowlers;
    size_t bowler_count;

    Over *overs;
    size_t over_count;

    FallOfWicket *fow;
    size_t fow_count;
} Innings;

typedef struct {
    char match_id[MATCH_ID_LEN];
    char team1[NAME_LEN];
    char team2[NAME_LEN];
    char venue[VENUE_LEN];
    char date[DATE_LEN];
    Innings innings[2];
} Match;

#endif


/* ================= HEADER: component1/component1_input_parser.h ================= */
/*
 * component1_input_parser.h
 * Component 1: Input and Parsing - Cricket Score Graph Project
 *
 * Public interface for reading cricket scores (team/player + runs) from a
 * file or the keyboard, validating them, and producing a Dataset whose
 * `points` array uses the same DataPoint layout as Component 4.
 */
#ifndef COMPONENT1_INPUT_PARSER_H
#define COMPONENT1_INPUT_PARSER_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------ Constants ------------------------------- */
#define MAX_LINE   256   /* longest input line read                         */
#define MAX_LABEL  32    /* longest label kept (incl. terminating '\0')     */
#define MAX_POINTS 1000  /* maximum number of entries in a Dataset          */

/* ------------------------------- Types ---------------------------------- */
/* Shared with Component 4 (graph rendering). The guard lets both headers
   define it without a redefinition error. */
#ifndef DATAPOINT_DEFINED
#define DATAPOINT_DEFINED
typedef struct {
    const char *label;
    double value;
} DataPoint;
#endif

typedef struct {
    DataPoint *points;   /* labels are heap copies owned by the dataset */
    size_t count;
    size_t capacity;
} Dataset;

typedef enum {
    PARSE_OK,
    PARSE_SKIP,          /* blank line or comment                  */
    PARSE_BAD_FORMAT,    /* no label/score separator, empty field  */
    PARSE_BAD_VALUE      /* score is not a valid non-negative number */
} ParseStatus;

/* --------------------------- Dataset helpers ---------------------------- */
/* Initialise an empty dataset. Call before any other use. */
void dataset_init(Dataset *ds);

/* Free all labels and the points array; leaves ds empty and reusable. */
void dataset_free(Dataset *ds);

/* Append a (label, value) pair; the label is copied.
   Returns 1 on success, 0 on out-of-memory or MAX_POINTS reached. */
int dataset_add(Dataset *ds, const char *label, double value);

/* -------------------------------- Parsing ------------------------------- */
/* Parse "245", "78.5" or "245/6" (runs/wickets; only runs kept).
   Returns 1 and sets *out on success, 0 on invalid input. */
int parse_value(const char *s, double *out);

/* Parse one input line into a label and score.
   Returns PARSE_OK (label_out/value_out filled) or another ParseStatus. */
ParseStatus parse_line(const char *line, char label_out[MAX_LABEL], double *value_out);

/* --------------------------------- Input -------------------------------- */
/* Load entries from a file. Bad lines are reported on stderr and skipped;
   a non-numeric first line is treated as a header.
   Returns the number of entries added, or -1 if the file cannot be opened. */
int load_file(const char *path, Dataset *ds);

/* Read entries from the keyboard until a blank line or EOF.
   Returns the number of entries added. */
int load_interactive(Dataset *ds);

#ifdef __cplusplus
}
#endif

#endif /* COMPONENT1_INPUT_PARSER_H */


/* ================= HEADER: component2/match_store.h ================= */
#ifndef MATCH_STORE_H
#define MATCH_STORE_H
typedef struct {
    Match *matches;
    size_t count;
    size_t capacity;
} MatchStore;

void store_init(MatchStore *store);
void match_free(Match *match);
void store_free(MatchStore *store);

int store_add_match(MatchStore *store, const Match *match);
Match *store_get_match(MatchStore *store, size_t index);
int store_remove_match(MatchStore *store, size_t index);
void store_list_matches(const MatchStore *store);

int match_save(const Match *match, const char *filename);
/* match_load expects an empty/zero-initialized destination Match. */
int match_load(Match *match, const char *filename);

#endif



/* ================= HEADER: component2/match_validate.h ================= */
#ifndef MATCH_VALIDATE_H
#define MATCH_VALIDATE_H
#ifdef __cplusplus
extern "C" {
#endif

/* Validate the structure and basic score ranges of a match.
   Returns 1 when valid and 0 when invalid. If error_message is non-NULL,
   writes a short explanation into the supplied buffer. */
int match_validate(const Match *match, char *error_message, size_t message_size);

#ifdef __cplusplus
}
#endif

#endif


/* ================= HEADER: component1/component1_match_loader.h ================= */
#ifndef COMPONENT1_MATCH_LOADER_H
#define COMPONENT1_MATCH_LOADER_H
/* Component 1 addition: reads a full scorecard text file into the Component 2 Match model.

   File format: one record per line, comma separated, '#' starts a comment.
     MATCH,match_id,team1,team2,venue,date
     INNINGS,n,batting_team,total_runs,wickets,legal_balls          (n is 1 or 2)
     BATTER,n,name,runs,balls_faced,fours,sixes
     BOWLER,n,name,wickets,balls_bowled,runs_conceded
     OVER,n,over_number,runs,wickets
     FOW,n,wicket_number,team_score,over_number,ball_in_over,player_out
   The MATCH line must come first. Names must not contain commas.
   The finished Match is checked with match_validate(). */

#include <stddef.h>
/* Returns 1 on success (caller must call match_free on *match, which must be zeroed beforehand)
   or 0 on failure, with a message such as "line 7: runs must be a whole number" in error. */
int load_match_file(const char *path, Match *match, char *error, size_t error_size);

#endif


/* ================= HEADER: component3/stats_engine.h ================= */
#ifndef STATS_ENGINE_H
#define STATS_ENGINE_H

/*
 * Component 3: Cricket Statistics Engine
 * Compatible with the team's match_model.h (Component 2).
 *
 * This module calculates cricket statistics and builds graph-ready series.
 * It does NOT render graphs; Component 4 owns rendering.
 *
 * Compile as C99 or later.
 */
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

#define STATS_NAME_LEN NAME_LEN
#define STATS_TITLE_LEN 64

typedef enum {
    STATS_OK = 0,
    STATS_NO_DATA,
    STATS_INVALID_ARGUMENT,
    STATS_INVALID_DATA,
    STATS_BUFFER_TOO_SMALL,
    STATS_NO_MEMORY
} StatsStatus;

typedef struct {
    double strike_rate;       /* runs per 100 balls */
    int boundary_runs;        /* 4*fours + 6*sixes */
    int boundary_count;       /* fours + sixes */
} BattingStats;

typedef struct {
    char overs[24];           /* e.g. "3.4" (3 overs, 4 balls) */
    double economy;           /* runs conceded per 6 legal balls */
    double bowling_average;   /* runs conceded per wicket */
    double bowling_strike_rate; /* legal balls per wicket */
} BowlingStats;

typedef struct {
    int total_runs;
    int wickets;
    int legal_balls;
    char overs[24];
    double run_rate;
    int total_fours;
    int total_sixes;
    int boundary_runs;
    int boundary_count;
    int highest_over_runs;
    int highest_over_number;
    int top_scorer_index;     /* -1 if no batter data */
    int best_bowler_index;    /* -1 if no bowler data */
    int last_wicket_index;    /* -1 if no fall-of-wicket data */
} InningsStats;

/* A point is deliberately simple for Component 4 to render in Pure C. */
typedef struct {
    double x;
    double y;
    char label[NAME_LEN];
} StatsPoint;

typedef struct {
    char title[STATS_TITLE_LEN];
    StatsPoint *points;       /* owned by this series after successful build */
    size_t count;
} StatsSeries;

/* Validate all fields consumed by this module. Returns STATS_INVALID_DATA for
 * inconsistent records and STATS_INVALID_ARGUMENT for a null innings pointer. */
StatsStatus stats_validate_innings(const Innings *innings);

/* Individual player calculations. */
StatsStatus stats_batting(const Player *batter, BattingStats *out);
StatsStatus stats_bowling(const Player *bowler, BowlingStats *out);

/* Cricket overs display: legal balls 20 -> "3.2". */
StatsStatus stats_format_overs(int legal_balls, char *buffer, size_t size);

/* Required run rate to reach target_runs, using legal balls remaining.
 * If the target is already reached, returns STATS_OK with 0.0. If balls are
 * exhausted while runs are still needed, returns STATS_NO_DATA with 0.0. */
StatsStatus stats_required_run_rate(int target_runs, int current_runs,
                                    int legal_balls_remaining, double *out);

/* Calculate an innings summary. Index fields refer to the source arrays. */
StatsStatus stats_innings(const Innings *innings, InningsStats *out);

/* Build/free graph-ready series. Initialize with stats_series_init before first
 * use and call stats_series_free when finished. The series owns its points.
 * On STATS_NO_DATA or an error, an existing series is left unchanged, except
 * cumulative-run overflow, which clears the newly allocated result safely. */
void stats_series_init(StatsSeries *series);
void stats_series_free(StatsSeries *series);

/* One point per recorded over. x=over number; y=runs or wickets. */
StatsStatus stats_graph_runs_per_over(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_wickets_per_over(const Innings *innings, StatsSeries *out);

/* Cumulative runs across recorded overs (respects actual over_number gaps). */
StatsStatus stats_graph_cumulative_runs(const Innings *innings, StatsSeries *out);

/* One point per batter/bowler. x=1-based player index; y=selected statistic. */
StatsStatus stats_graph_batter_runs(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_batter_strike_rates(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_bowler_wickets(const Innings *innings, StatsSeries *out);
StatsStatus stats_graph_bowler_economy(const Innings *innings, StatsSeries *out);

/* Fall-of-wickets: x=team score at fall; y=wicket number. */
StatsStatus stats_graph_fall_of_wickets(const Innings *innings, StatsSeries *out);

/* Boundary totals: points are labelled "Fours" and "Sixes". */
StatsStatus stats_graph_boundaries(const Innings *innings, StatsSeries *out);

/* Two-innings comparison: points labelled with batting team names.
 * y=total runs or wickets respectively.
 */
StatsStatus stats_graph_innings_runs_comparison(const Match *match, StatsSeries *out);
StatsStatus stats_graph_innings_wickets_comparison(const Match *match, StatsSeries *out);

/* Print a readable text report (useful for testing/debugging). */
StatsStatus stats_print_innings_report(const Innings *innings);

#ifdef __cplusplus
}
#endif
#endif


/* ================= HEADER: component3/stats_legacy_compat.h ================= */
#ifndef STATS_LEGACY_COMPAT_H
#define STATS_LEGACY_COMPAT_H
#define STATS_MIN_BALLS_STRIKER 10
#define STATS_POINTS_PER_WICKET 25
typedef struct { float strike_rate, average, boundary_pct; } BatterStats;
typedef struct { char bat1[NAME_LEN], bat2[NAME_LEN]; int runs, unbeaten; } Partnership;
typedef struct { char man_of_match[NAME_LEN]; int mom_points; char most_sixes[NAME_LEN]; int sixes; char most_wickets[NAME_LEN]; int wickets; char super_striker[NAME_LEN]; float strike_rate; } MatchAwards;
void stats_batter(const Player *, int, BatterStats *);
int stats_over_runs(const Innings *, int *, int);
int stats_cumulative_runs(const Innings *, int *, int);
int stats_over_wickets(const Innings *, int *, int);
int stats_partnerships(const Innings *, Partnership *, int);
int stats_awards(const Match *, MatchAwards *);
int stats_result(const Match *, char *, size_t);
#endif


/* ================= HEADER: component4/chart_render.h ================= */
#ifndef CHART_RENDER_H
#define CHART_RENDER_H
/* Component 4: Graph rendering engine. Public interface.
   Draws bar, line and pie charts as ASCII text, SVG files or BMP files. */

#ifndef DATAPOINT_DEFINED
#define DATAPOINT_DEFINED
typedef struct {
    const char *label;
    double value;
} DataPoint;
#endif

typedef enum { CHART_BAR = 0, CHART_LINE = 1, CHART_PIE = 2 } ChartKind;

#define CHART_OK        0
#define CHART_ERR_ARGS  (-1)   /* no data, negative or all-zero values, line chart with fewer than 2 points */
#define CHART_ERR_FILE  (-2)   /* output file could not be written */

/* Up to 1000 points. Labels must not be NULL. Data is not modified or kept. */
int chart_ascii(ChartKind kind, const DataPoint *data, int count);
int chart_svg(const char *path, ChartKind kind, const char *title, const DataPoint *data, int count);
int chart_bmp(const char *path, ChartKind kind, const DataPoint *data, int count);   /* no text labels in BMP */
const char *chart_error_message(int code);

#endif


/* ================= HEADER: component5/sg5_viz.h ================= */
#ifndef SG5_VIZ_H
#define SG5_VIZ_H
/* Subgroup 5: charts, awards and menu. Plain C99.
   Data comes from Component 2's Match model; statistics from Component 3; charts from Components 4 and 5. */
#include <stdio.h>
#define SG5_MAX_OVERS  60
#define SG5_MAX_PSHIPS 12

typedef struct { char title[2 * NAME_LEN + 8]; char venue[VENUE_LEN]; char date[DATE_LEN]; char id[MATCH_ID_LEN]; } MatchInfo;

typedef struct {
    char team[NAME_LEN];
    int  total_runs, wickets, balls, overs;
    int  runs_per_over[SG5_MAX_OVERS];
    int  cumulative_runs[SG5_MAX_OVERS];
    int  wicket_in_over[SG5_MAX_OVERS];
    int  num_partnerships;
    char pship_bat1[SG5_MAX_PSHIPS][NAME_LEN];
    char pship_bat2[SG5_MAX_PSHIPS][NAME_LEN];
    int  pship_runs[SG5_MAX_PSHIPS];
    int  pship_unbeaten[SG5_MAX_PSHIPS];
} InningsPlot;

typedef struct {
    MatchInfo   info;
    InningsPlot in[2];
    MatchAwards aw;
    char        result[96];
} Sg5Match;

/* Adapter (sg5_adapter.c): owns the MatchStore and builds chart-ready data from it. */
int  sg5_init(void);                 /* loads the three sample matches; returns 1 on success */
void sg5_shutdown(void);
int  sg5_match_count(void);
void sg5_match_title(int index, char *buf, size_t size);
int  sg5_load_match(int index, Sg5Match *m);
int  sg5_add_from_file(const char *path, char *error, size_t error_size);   /* Component 1 text scorecard */
int  sg5_max_over_runs(const Sg5Match *m);

/* Scorecard tables for the desktop GUI (read from Component 2's Match structs inside the adapter). */
#define SG5_MAX_ROWS 16
typedef struct { char name[NAME_LEN]; int runs, balls, fours, sixes, out; double sr, bnd_pct; } Sg5BatRow;
typedef struct { char name[NAME_LEN]; int runs, wickets, balls; double econ; } Sg5BowlRow;
typedef struct { int wkt, score, over, ball; char name[NAME_LEN]; } Sg5FowRow;
typedef struct { int nbat, nbowl, nfow; Sg5BatRow bat[SG5_MAX_ROWS]; Sg5BowlRow bowl[SG5_MAX_ROWS]; Sg5FowRow fow[SG5_MAX_ROWS]; } Sg5Card;
typedef struct { char name[NAME_LEN]; int runs, wickets, points; } Sg5MvpRow;
int  sg5_scorecard(int index, int innings, Sg5Card *out);          /* 0 on success */
int  sg5_mvp(int index, Sg5MvpRow *out, int max_rows);             /* rows sorted by points, returns count */

int  sg5_sample_matches(MatchStore *store);   /* sg5_sample_data.c: fictional matches built as Match structs */

void sg5_worm_show(const Sg5Match *m);
void sg5_worm_svg(FILE *f, const Sg5Match *m);
void sg5_manhattan_show(const InningsPlot *p);
void sg5_manhattan_svg(FILE *f, const InningsPlot *p, int mx);
void sg5_partnership_show(const InningsPlot *p);
void sg5_partnership_svg(FILE *f, const InningsPlot *p);
void sg5_awards_show(const Sg5Match *m);
void sg5_menu_run(void);
#endif


/* ================= HEADER: component5/desktop_shell_win32.h ================= */
#ifndef DESKTOP_SHELL_WIN32_H
#define DESKTOP_SHELL_WIN32_H
/* Windows "desktop application" helpers for CricLens, written in plain C.
 *  - the CricLens app icon is rasterised in code (no image files needed)
 *  - a multi-size .ico file is written so shortcuts can use it
 *  - Desktop and Start Menu shortcuts are created through the Windows shell COM API
 *  - DPI awareness and a title bar that follows the light/dark theme
 */
#include <windows.h>

/* Straight (non-premultiplied) top-down BGRA pixels, size x size. */
void  cl_render_icon(unsigned char *bgra, int size);
/* Composite an icon buffer over a solid colour and make it fully opaque. */
void  cl_flatten_icon(unsigned char *bgra, int size, COLORREF background);
HICON cl_make_hicon(int size);
int   cl_write_ico_file(const char *path);
/* Writes CricLens.ico next to the .exe, then creates the Desktop and Start Menu
 * shortcuts. Returns the number of shortcuts created; msg receives a summary. */
int   cl_install_shortcuts(char *msg, size_t msg_size);
void  cl_apply_titlebar(HWND hwnd, int dark);   /* light or dark caption to match the UI theme (Windows 10/11) */
void  cl_enable_dpi_awareness(void);
#endif


/* ================= SOURCE: component1/component1_input_parser.c ================= */
/*
 * Component 1: Input and Parsing - Cricket Score Graph Project
 *
 * Reads cricket scores (team/player + runs) from a file or from the keyboard,
 * validates them, and produces a Dataset whose `points` array uses the SAME
 * DataPoint layout as Component 4 (the graph rendering engine):
 *
 *     typedef struct { const char *label; double value; } DataPoint;
 *
 * Accepted line formats (one entry per line):
 *     Tigers, 78            comma separated (CSV)
 *     Eagles: 92            colon / semicolon / tab separated
 *     South Africa 245      whitespace separated (last token is the score)
 *     India, 287/6          "runs/wickets" - only the runs are kept
 *     # comment             ignored, as are blank lines
 *     Team,Runs             a non-numeric first line is treated as a header
 *
 * Build:  see README.txt. This file is a module with no main(); test_parser.c has the demo.
 *
 * Integration with Component 4:
 *     Dataset ds;  dataset_init(&ds);
 *     if (load_file("scores.csv", &ds) > 0) render_all(ds.points, ds.count);
 *     dataset_free(&ds);
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>
/* ---------------------------- Dataset helpers --------------------------- */
void dataset_init(Dataset *ds) {
    ds->points = NULL; ds->count = 0; ds->capacity = 0;
}

void dataset_free(Dataset *ds) {
    size_t i;
    for (i = 0; i < ds->count; ++i) free((void *)ds->points[i].label);
    free(ds->points);
    dataset_init(ds);
}

int dataset_add(Dataset *ds, const char *label, double value) {
    char *copy;
    if (ds->count >= MAX_POINTS) return 0;
    if (ds->count == ds->capacity) {
        size_t ncap = ds->capacity ? ds->capacity * 2 : 8;
        DataPoint *np = (DataPoint *)realloc(ds->points, ncap * sizeof(DataPoint));
        if (!np) return 0;
        ds->points = np; ds->capacity = ncap;
    }
    copy = (char *)malloc(strlen(label) + 1);
    if (!copy) return 0;
    strcpy(copy, label);
    ds->points[ds->count].label = copy;
    ds->points[ds->count].value = value;
    ds->count++;
    return 1;
}

/* ------------------------------ String utils ---------------------------- */
static char *trim(char *s) {
    char *end;
    while (isspace((unsigned char)*s)) ++s;
    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) --end;
    *end = '\0';
    return s;
}

/* Remove one pair of surrounding double quotes, e.g. "Tigers" -> Tigers */
static void strip_quotes(char *s) {
    size_t n = strlen(s);
    if (n >= 2 && s[0] == '"' && s[n - 1] == '"') {
        memmove(s, s + 1, n - 2);
        s[n - 2] = '\0';
    }
}

/* ------------------------------ Parsing --------------------------------- */
/* Parse "245", "78.5" or "245/6" (runs/wickets). Must consume whole string. */
int parse_value(const char *s, double *out) {
    char *end; double v;
    errno = 0;
    v = strtod(s, &end);
    if (end == s || errno == ERANGE) return 0;
    if (*end == '/') {                       /* runs/wickets */
        char *end2; long w = strtol(end + 1, &end2, 10);
        if (end2 == end + 1 || w < 0 || w > 10) return 0;
        end = end2;
    }
    while (isspace((unsigned char)*end)) ++end;
    if (*end != '\0') return 0;
    if (!isfinite(v) || v < 0.0) return 0;   /* scores cannot be negative */
    *out = v;
    return 1;
}

/* Find the separator between label and score. The LAST separator is used so
   labels such as "South Africa" or "Smith, J" still work. */
static char *find_separator(char *s) {
    static const char seps[] = ",:;\t";
    size_t i; char *p;
    for (i = 0; seps[i]; ++i) {
        p = strrchr(s, seps[i]);
        if (p) return p;
    }
    p = s + strlen(s);
    while (p > s && !isspace((unsigned char)p[-1])) --p;   /* last token */
    return (p > s) ? p - 1 : NULL;
}

/* Parse one line. On PARSE_OK, label_out/value_out are filled. */
ParseStatus parse_line(const char *line, char label_out[MAX_LABEL], double *value_out) {
    char buf[MAX_LINE], *s, *sep, *label, *val;

    if (strlen(line) >= MAX_LINE - 1 && line[strlen(line) - 1] != '\n') return PARSE_BAD_FORMAT;
    strcpy(buf, line);
    s = trim(buf);
    if (*s == '\0' || *s == '#') return PARSE_SKIP;

    sep = find_separator(s);
    if (!sep) return PARSE_BAD_FORMAT;
    *sep = '\0';
    label = trim(s);
    val = trim(sep + 1);
    strip_quotes(label);
    label = trim(label);
    if (*label == '\0' || *val == '\0') return PARSE_BAD_FORMAT;

    if (!parse_value(val, value_out)) return PARSE_BAD_VALUE;

    strncpy(label_out, label, MAX_LABEL - 1);
    label_out[MAX_LABEL - 1] = '\0';         /* truncate overly long labels */
    return PARSE_OK;
}

/* ------------------------------- Input ---------------------------------- */
/* Load from a file. Bad lines are reported (with line numbers) and skipped.
   Returns the number of entries added, or -1 if the file cannot be opened. */
int load_file(const char *path, Dataset *ds) {
    FILE *f = fopen(path, "r");
    char line[MAX_LINE], label[MAX_LABEL];
    int line_no = 0, added = 0, seen_data = 0;
    double value;

    if (!f) { fprintf(stderr, "Error: cannot open '%s': %s\n", path, strerror(errno)); return -1; }

    while (fgets(line, sizeof(line), f)) {
        ParseStatus st;
        ++line_no;
        st = parse_line(line, label, &value);
        if (st == PARSE_SKIP) continue;
        if (st == PARSE_BAD_VALUE && !seen_data) { seen_data = 1; continue; } /* header row */
        seen_data = 1;
        if (st == PARSE_BAD_FORMAT) {
            fprintf(stderr, "Warning: line %d skipped (expected \"name, score\")\n", line_no);
        } else if (st == PARSE_BAD_VALUE) {
            fprintf(stderr, "Warning: line %d skipped (score must be a non-negative number)\n", line_no);
        } else if (!dataset_add(ds, label, value)) {
            fprintf(stderr, "Error: out of memory or more than %d entries\n", MAX_POINTS);
            break;
        } else {
            ++added;
        }
    }
    if (ferror(f)) fprintf(stderr, "Error: problem while reading '%s'\n", path);
    fclose(f);
    return added;
}

/* Interactive entry from the keyboard. A blank line (or EOF) finishes input. */
int load_interactive(Dataset *ds) {
    char line[MAX_LINE], label[MAX_LABEL];
    int added = 0; double value;

    printf("Enter one entry per line as:  name, score   (e.g. Tigers, 78)\n");
    printf("Press Enter on an empty line to finish.\n");
    for (;;) {
        char *t; ParseStatus st;
        printf("> "); fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        t = line; while (isspace((unsigned char)*t)) ++t;
        if (*t == '\0') break;
        st = parse_line(line, label, &value);
        if (st == PARSE_SKIP) continue;
        if (st == PARSE_BAD_FORMAT) { printf("  Invalid format - use: name, score\n"); continue; }
        if (st == PARSE_BAD_VALUE)  { printf("  Score must be a non-negative number\n"); continue; }
        if (!dataset_add(ds, label, value)) { printf("  Cannot store more entries\n"); break; }
        ++added;
    }
    return added;
}



/* ================= SOURCE: component1/component1_match_loader.c ================= */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LOADER_LINE   512
#define LOADER_FIELDS 8
#define LOADER_MSG    120

static char *trim(char *s)
{
    char *end;
    while (isspace((unsigned char)*s)) ++s;
    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) --end;
    *end = '\0';
    return s;
}

static int split(char *s, char *f[], int max)
{
    int n = 0, i;
    f[n++] = s;
    for (; *s && n < max; ++s) {
        if (*s == ',') { *s = '\0'; f[n++] = s + 1; }
    }
    for (i = 0; i < n; ++i) f[i] = trim(f[i]);
    return n;
}

static int num(const char *s, int *out)
{
    char *end;
    long v;
    if (*s == '\0') return 0;
    v = strtol(s, &end, 10);
    if (*end != '\0' || v < 0 || v > 1000000L) return 0;
    *out = (int)v;
    return 1;
}

static int copy_text(char *dst, size_t size, const char *src)
{
    if (strlen(src) >= size) return 0;
    strcpy(dst, src);
    return 1;
}

static int bad(char *msg, const char *text)
{
    snprintf(msg, LOADER_MSG, "%s", text);
    return 0;
}

static int parse_record(Match *m, char *f[], int n, int *have_match, char *msg)
{
    Innings *in;
    int idx, c;

    if (strcmp(f[0], "MATCH") == 0) {
        if (n != 6) return bad(msg, "MATCH needs 5 fields: id, team1, team2, venue, date");
        if (!copy_text(m->match_id, MATCH_ID_LEN, f[1]) || !copy_text(m->team1, NAME_LEN, f[2]) ||
            !copy_text(m->team2, NAME_LEN, f[3]) || !copy_text(m->venue, VENUE_LEN, f[4]) ||
            !copy_text(m->date, DATE_LEN, f[5]))
            return bad(msg, "a MATCH field is too long");
        *have_match = 1;
        return 1;
    }
    if (!*have_match) return bad(msg, "the MATCH line must come first");
    if (n < 2 || !num(f[1], &idx) || idx < 1 || idx > 2) return bad(msg, "innings number must be 1 or 2");
    in = &m->innings[idx - 1];

    if (strcmp(f[0], "INNINGS") == 0) {
        if (n != 6) return bad(msg, "INNINGS needs 5 fields");
        if (!copy_text(in->batting_team, NAME_LEN, f[2])) return bad(msg, "batting team name too long");
        if (!num(f[3], &in->total_runs) || !num(f[4], &in->wickets) || !num(f[5], &in->legal_balls))
            return bad(msg, "runs, wickets and balls must be whole numbers");
        return 1;
    }
    if (strcmp(f[0], "BATTER") == 0 || strcmp(f[0], "BOWLER") == 0) {
        int is_bat = (f[0][1] == 'A');
        Player *np, *p;
        size_t *count = is_bat ? &in->batter_count : &in->bowler_count;
        Player **arr = is_bat ? &in->batters : &in->bowlers;
        if (n != (is_bat ? 7 : 6)) return bad(msg, is_bat ? "BATTER needs 6 fields" : "BOWLER needs 5 fields");
        np = (Player *)realloc(*arr, (*count + 1) * sizeof(Player));
        if (!np) return bad(msg, "out of memory");
        *arr = np;
        p = &np[*count];
        memset(p, 0, sizeof *p);
        (*count)++;
        if (!copy_text(p->name, NAME_LEN, f[2])) return bad(msg, "player name too long");
        if (is_bat) {
            if (!num(f[3], &p->runs) || !num(f[4], &p->balls_faced) || !num(f[5], &p->fours) || !num(f[6], &p->sixes))
                return bad(msg, "batter numbers must be whole numbers");
        } else if (!num(f[3], &p->wickets) || !num(f[4], &p->balls_bowled) || !num(f[5], &p->runs_conceded)) {
            return bad(msg, "bowler numbers must be whole numbers");
        }
        return 1;
    }
    if (strcmp(f[0], "OVER") == 0) {
        Over *np;
        if (n != 5) return bad(msg, "OVER needs 4 fields");
        np = (Over *)realloc(in->overs, (in->over_count + 1) * sizeof(Over));
        if (!np) return bad(msg, "out of memory");
        in->overs = np;
        c = (int)in->over_count++;
        if (!num(f[2], &np[c].over_number) || !num(f[3], &np[c].runs) || !num(f[4], &np[c].wickets))
            return bad(msg, "over numbers must be whole numbers");
        return 1;
    }
    if (strcmp(f[0], "FOW") == 0) {
        FallOfWicket *np, *w;
        if (n != 7) return bad(msg, "FOW needs 6 fields");
        np = (FallOfWicket *)realloc(in->fow, (in->fow_count + 1) * sizeof(FallOfWicket));
        if (!np) return bad(msg, "out of memory");
        in->fow = np;
        w = &np[in->fow_count++];
        memset(w, 0, sizeof *w);
        if (!num(f[2], &w->wicket_number) || !num(f[3], &w->team_score) || !num(f[4], &w->over_number) || !num(f[5], &w->ball_in_over))
            return bad(msg, "fall of wicket numbers must be whole numbers");
        if (!copy_text(w->player_out, NAME_LEN, f[6])) return bad(msg, "player name too long");
        return 1;
    }
    return bad(msg, "unknown record type");
}

static void set_error(char *e, size_t size, int line, const char *msg)
{
    if (!e || size == 0) return;
    if (line > 0) snprintf(e, size, "line %d: %s", line, msg); else snprintf(e, size, "%s", msg);
}

int load_match_file(const char *path, Match *match, char *error, size_t error_size)
{
    FILE *fp;
    char line[LOADER_LINE], msg[LOADER_MSG] = "", verr[160], *f[LOADER_FIELDS], *s;
    int line_no = 0, have_match = 0, ok = 1;
    Match tmp;

    if (!path || !match) { set_error(error, error_size, 0, "missing argument"); return 0; }
    fp = fopen(path, "r");
    if (!fp) { set_error(error, error_size, 0, "cannot open the file"); return 0; }
    memset(&tmp, 0, sizeof tmp);

    while (ok && fgets(line, sizeof line, fp)) {
        ++line_no;
        if (!strchr(line, '\n') && !feof(fp)) { set_error(error, error_size, line_no, "line is too long"); ok = 0; break; }
        s = trim(line);
        if (*s == '\0' || *s == '#') continue;
        if (!parse_record(&tmp, f, split(s, f, LOADER_FIELDS), &have_match, msg)) {
            set_error(error, error_size, line_no, msg);
            ok = 0;
        }
    }
    fclose(fp);
    if (ok && !have_match) { set_error(error, error_size, 0, "the file has no MATCH line"); ok = 0; }
    if (ok && !match_validate(&tmp, verr, sizeof verr)) {
        if (error && error_size) snprintf(error, error_size, "invalid match: %s", verr);
        ok = 0;
    }
    if (!ok) { match_free(&tmp); return 0; }
    *match = tmp;
    return 1;
}


/* ================= SOURCE: component2/match_store.c ================= */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define FILE_VERSION 1u
#define MAX_ITEMS 10000u

static int write_data(FILE *fp, const void *data, size_t size) {
    return fwrite(data, 1, size, fp) == size;
}

static int read_data(FILE *fp, void *data, size_t size) {
    return fread(data, 1, size, fp) == size;
}

static int write_int(FILE *fp, int value) {
    int32_t number = (int32_t)value;
    return write_data(fp, &number, sizeof(number));
}

static int read_int(FILE *fp, int *value) {
    int32_t number;
    if (!read_data(fp, &number, sizeof(number))) return 0;
    *value = (int)number;
    return 1;
}

static int write_string(FILE *fp, const char *value, size_t max_length) {
    size_t length = strlen(value);
    uint32_t saved_length;

    if (length >= max_length) return 0;
    saved_length = (uint32_t)length;

    return write_data(fp, &saved_length, sizeof(saved_length)) &&
           write_data(fp, value, length);
}

static int read_string(FILE *fp, char *value, size_t max_length) {
    uint32_t length;

    if (!read_data(fp, &length, sizeof(length))) return 0;
    if (length >= max_length) return 0;
    if (!read_data(fp, value, length)) return 0;

    value[length] = '\0';
    return 1;
}

static int write_count(FILE *fp, size_t count) {
    uint32_t saved_count;
    if (count > MAX_ITEMS) return 0;
    saved_count = (uint32_t)count;
    return write_data(fp, &saved_count, sizeof(saved_count));
}

static int read_count(FILE *fp, size_t *count) {
    uint32_t saved_count;
    if (!read_data(fp, &saved_count, sizeof(saved_count))) return 0;
    if (saved_count > MAX_ITEMS) return 0;
    *count = (size_t)saved_count;
    return 1;
}

static int write_player(FILE *fp, const Player *p) {
    return write_string(fp, p->name, NAME_LEN) &&
           write_int(fp, p->runs) &&
           write_int(fp, p->balls_faced) &&
           write_int(fp, p->fours) &&
           write_int(fp, p->sixes) &&
           write_int(fp, p->wickets) &&
           write_int(fp, p->balls_bowled) &&
           write_int(fp, p->runs_conceded);
}

static int read_player(FILE *fp, Player *p) {
    return read_string(fp, p->name, NAME_LEN) &&
           read_int(fp, &p->runs) &&
           read_int(fp, &p->balls_faced) &&
           read_int(fp, &p->fours) &&
           read_int(fp, &p->sixes) &&
           read_int(fp, &p->wickets) &&
           read_int(fp, &p->balls_bowled) &&
           read_int(fp, &p->runs_conceded);
}

static int write_innings(FILE *fp, const Innings *in) {
    size_t i;

    if (!write_string(fp, in->batting_team, NAME_LEN) ||
        !write_int(fp, in->total_runs) ||
        !write_int(fp, in->wickets) ||
        !write_int(fp, in->legal_balls) ||
        !write_count(fp, in->batter_count)) return 0;

    for (i = 0; i < in->batter_count; i++)
        if (!write_player(fp, &in->batters[i])) return 0;

    if (!write_count(fp, in->bowler_count)) return 0;
    for (i = 0; i < in->bowler_count; i++)
        if (!write_player(fp, &in->bowlers[i])) return 0;

    if (!write_count(fp, in->over_count)) return 0;
    for (i = 0; i < in->over_count; i++) {
        if (!write_int(fp, in->overs[i].over_number) ||
            !write_int(fp, in->overs[i].runs) ||
            !write_int(fp, in->overs[i].wickets)) return 0;
    }

    if (!write_count(fp, in->fow_count)) return 0;
    for (i = 0; i < in->fow_count; i++) {
        const FallOfWicket *w = &in->fow[i];
        if (!write_int(fp, w->wicket_number) ||
            !write_int(fp, w->team_score) ||
            !write_int(fp, w->over_number) ||
            !write_int(fp, w->ball_in_over) ||
            !write_string(fp, w->player_out, NAME_LEN)) return 0;
    }

    return 1;
}

static int read_innings(FILE *fp, Innings *in) {
    size_t i, count;

    if (!read_string(fp, in->batting_team, NAME_LEN) ||
        !read_int(fp, &in->total_runs) ||
        !read_int(fp, &in->wickets) ||
        !read_int(fp, &in->legal_balls) ||
        !read_count(fp, &count)) return 0;

    if (count > 0) {
        in->batters = calloc(count, sizeof(Player));
        if (!in->batters) return 0;
        in->batter_count = count;
        for (i = 0; i < count; i++)
            if (!read_player(fp, &in->batters[i])) return 0;
    }

    if (!read_count(fp, &count)) return 0;
    if (count > 0) {
        in->bowlers = calloc(count, sizeof(Player));
        if (!in->bowlers) return 0;
        in->bowler_count = count;
        for (i = 0; i < count; i++)
            if (!read_player(fp, &in->bowlers[i])) return 0;
    }

    if (!read_count(fp, &count)) return 0;
    if (count > 0) {
        in->overs = calloc(count, sizeof(Over));
        if (!in->overs) return 0;
        in->over_count = count;
        for (i = 0; i < count; i++) {
            if (!read_int(fp, &in->overs[i].over_number) ||
                !read_int(fp, &in->overs[i].runs) ||
                !read_int(fp, &in->overs[i].wickets)) return 0;
        }
    }

    if (!read_count(fp, &count)) return 0;
    if (count > 0) {
        in->fow = calloc(count, sizeof(FallOfWicket));
        if (!in->fow) return 0;
        in->fow_count = count;
        for (i = 0; i < count; i++) {
            FallOfWicket *w = &in->fow[i];
            if (!read_int(fp, &w->wicket_number) ||
                !read_int(fp, &w->team_score) ||
                !read_int(fp, &w->over_number) ||
                !read_int(fp, &w->ball_in_over) ||
                !read_string(fp, w->player_out, NAME_LEN)) return 0;
        }
    }

    return 1;
}

void match_free(Match *match) {
    int i;

    if (!match) return;

    for (i = 0; i < 2; i++) {
        free(match->innings[i].batters);
        free(match->innings[i].bowlers);
        free(match->innings[i].overs);
        free(match->innings[i].fow);
    }

    memset(match, 0, sizeof(Match));
}

void store_init(MatchStore *store) {
    if (!store) return;

    store->matches = NULL;
    store->count = 0;
    store->capacity = 0;
}

void store_free(MatchStore *store) {
    size_t i;

    if (!store) return;

    for (i = 0; i < store->count; i++)
        match_free(&store->matches[i]);

    free(store->matches);
    store_init(store);
}

static int copy_array(void **destination, const void *source,
                      size_t count, size_t item_size) {
    *destination = NULL;

    if (count == 0) return 1;
    if (!source) return 0;

    *destination = malloc(count * item_size);
    if (!*destination) return 0;

    memcpy(*destination, source, count * item_size);
    return 1;
}

static int copy_innings(Innings *destination, const Innings *source) {
    destination->total_runs = source->total_runs;
    destination->wickets = source->wickets;
    destination->legal_balls = source->legal_balls;
    strcpy(destination->batting_team, source->batting_team);

    destination->batter_count = source->batter_count;
    destination->bowler_count = source->bowler_count;
    destination->over_count = source->over_count;
    destination->fow_count = source->fow_count;

    if (!copy_array((void **)&destination->batters, source->batters,
                    source->batter_count, sizeof(Player))) return 0;
    if (!copy_array((void **)&destination->bowlers, source->bowlers,
                    source->bowler_count, sizeof(Player))) return 0;
    if (!copy_array((void **)&destination->overs, source->overs,
                    source->over_count, sizeof(Over))) return 0;
    if (!copy_array((void **)&destination->fow, source->fow,
                    source->fow_count, sizeof(FallOfWicket))) return 0;

    return 1;
}

static int copy_match(Match *destination, const Match *source) {
    int i;

    memset(destination, 0, sizeof(Match));

    strcpy(destination->match_id, source->match_id);
    strcpy(destination->team1, source->team1);
    strcpy(destination->team2, source->team2);
    strcpy(destination->venue, source->venue);
    strcpy(destination->date, source->date);

    for (i = 0; i < 2; i++) {
        if (!copy_innings(&destination->innings[i], &source->innings[i])) {
            match_free(destination);
            return 0;
        }
    }

    return 1;
}

int store_add_match(MatchStore *store, const Match *match) {
    Match copy;
    Match *new_array;
    size_t new_capacity;
    char validation_error[160];

    if (!store || !match) return 0;
    if (!match_validate(match, validation_error, sizeof(validation_error))) {
        fprintf(stderr, "Invalid match: %s\n", validation_error);
        return 0;
    }
    if (!copy_match(&copy, match)) return 0;

    if (store->count == store->capacity) {
        new_capacity = (store->capacity == 0) ? 2 : store->capacity * 2;

        new_array = realloc(store->matches, new_capacity * sizeof(Match));
        if (!new_array) {
            match_free(&copy);
            return 0;
        }

        store->matches = new_array;
        store->capacity = new_capacity;
    }

    store->matches[store->count] = copy;
    store->count++;

    return 1;
}

Match *store_get_match(MatchStore *store, size_t index) {
    if (!store || index >= store->count) return NULL;
    return &store->matches[index];
}

int store_remove_match(MatchStore *store, size_t index) {
    size_t i;

    if (!store || index >= store->count) return 0;

    match_free(&store->matches[index]);

    for (i = index; i + 1 < store->count; i++)
        store->matches[i] = store->matches[i + 1];

    store->count--;
    memset(&store->matches[store->count], 0, sizeof(Match));

    return 1;
}

void store_list_matches(const MatchStore *store) {
    size_t i;

    if (!store || store->count == 0) {
        printf("No matches stored.\n");
        return;
    }

    for (i = 0; i < store->count; i++) {
        const Match *m = &store->matches[i];

        printf("%zu. %s | %s vs %s | Venue: %s\n",
               i, m->match_id, m->team1, m->team2, m->venue);
    }
}

int match_save(const Match *match, const char *filename) {
    FILE *fp;
    uint32_t version = FILE_VERSION;
    int success;
    char validation_error[160];

    if (!match || !filename) return 0;
    if (!match_validate(match, validation_error, sizeof(validation_error))) {
        fprintf(stderr, "Invalid match: %s\n", validation_error);
        return 0;
    }

    fp = fopen(filename, "wb");
    if (!fp) return 0;

    success = write_data(fp, "CRIC", 4) &&
              write_data(fp, &version, sizeof(version)) &&
              write_string(fp, match->match_id, MATCH_ID_LEN) &&
              write_string(fp, match->team1, NAME_LEN) &&
              write_string(fp, match->team2, NAME_LEN) &&
              write_string(fp, match->venue, VENUE_LEN) &&
              write_string(fp, match->date, DATE_LEN) &&
              write_innings(fp, &match->innings[0]) &&
              write_innings(fp, &match->innings[1]);

    if (fclose(fp) != 0) success = 0;

    return success;
}

int match_load(Match *match, const char *filename) {
    FILE *fp;
    char magic[4];
    uint32_t version;
    Match temporary;
    int success;

    if (!match || !filename) return 0;

    memset(&temporary, 0, sizeof(Match));

    fp = fopen(filename, "rb");
    if (!fp) return 0;

    success = read_data(fp, magic, 4) &&
              memcmp(magic, "CRIC", 4) == 0 &&
              read_data(fp, &version, sizeof(version)) &&
              version == FILE_VERSION &&
              read_string(fp, temporary.match_id, MATCH_ID_LEN) &&
              read_string(fp, temporary.team1, NAME_LEN) &&
              read_string(fp, temporary.team2, NAME_LEN) &&
              read_string(fp, temporary.venue, VENUE_LEN) &&
              read_string(fp, temporary.date, DATE_LEN) &&
              read_innings(fp, &temporary.innings[0]) &&
              read_innings(fp, &temporary.innings[1]);

    fclose(fp);

    if (success) {
        char validation_error[160];
        if (!match_validate(&temporary, validation_error, sizeof(validation_error))) {
            fprintf(stderr, "Invalid match file: %s\n", validation_error);
            success = 0;
        }
    }

    if (!success) {
        match_free(&temporary);
        return 0;
    }

    /* Caller must provide an empty/zero-initialized Match. */
    *match = temporary;
    return 1;
}



/* ================= SOURCE: component2/match_validate.c ================= */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#define VALIDATION_MAX_ITEMS 10000u

static int fail(char *message, size_t size, const char *format, ...) {
    va_list args;
    if (message && size > 0) {
        va_start(args, format);
        (void)vsnprintf(message, size, format, args);
        va_end(args);
    }
    return 0;
}

static int has_terminator(const char *value, size_t capacity) {
    return value && memchr(value, '\0', capacity) != NULL;
}

static int nonempty(const char *value) {
    return value && value[0] != '\0';
}

static int valid_player(const Player *player, size_t index,
                        const char *kind, char *message, size_t size) {
    if (!has_terminator(player->name, sizeof(player->name)) ||
        !nonempty(player->name))
        return fail(message, size, "%s %zu has an empty or unterminated name",
                    kind, index + 1);

    if (player->runs < 0 || player->balls_faced < 0 || player->fours < 0 ||
        player->sixes < 0 || player->wickets < 0 ||
        player->balls_bowled < 0 || player->runs_conceded < 0)
        return fail(message, size, "%s '%s' has a negative statistic",
                    kind, player->name);

    return 1;
}

static int valid_array(const void *array, size_t count, const char *name,
                       char *message, size_t size) {
    if (count > VALIDATION_MAX_ITEMS)
        return fail(message, size, "%s count exceeds %u", name,
                    (unsigned)VALIDATION_MAX_ITEMS);
    if (count > 0 && !array)
        return fail(message, size, "%s count is nonzero but its array is NULL",
                    name);
    return 1;
}

static int valid_innings(const Innings *innings, size_t index,
                         char *message, size_t size) {
    size_t i;
    char prefix[32];
    int populated;

    (void)snprintf(prefix, sizeof(prefix), "innings %zu", index + 1);
    populated = innings->total_runs != 0 || innings->wickets != 0 ||
                innings->legal_balls != 0 || innings->batter_count != 0 ||
                innings->bowler_count != 0 || innings->over_count != 0 ||
                innings->fow_count != 0;

    if (!has_terminator(innings->batting_team,
                        sizeof(innings->batting_team)))
        return fail(message, size, "%s has an unterminated batting team name",
                    prefix);
    if (populated && !nonempty(innings->batting_team))
        return fail(message, size, "%s is populated but has no batting team",
                    prefix);

    if (innings->total_runs < 0 || innings->wickets < 0 ||
        innings->wickets > 10 || innings->legal_balls < 0)
        return fail(message, size, "%s has invalid total runs, wickets, or legal balls",
                    prefix);

    if (!valid_array(innings->batters, innings->batter_count, "batter", message, size) ||
        !valid_array(innings->bowlers, innings->bowler_count, "bowler", message, size) ||
        !valid_array(innings->overs, innings->over_count, "over", message, size) ||
        !valid_array(innings->fow, innings->fow_count, "fall-of-wicket", message, size))
        return 0;

    for (i = 0; i < innings->batter_count; ++i)
        if (!valid_player(&innings->batters[i], i, "batter", message, size))
            return 0;

    for (i = 0; i < innings->bowler_count; ++i)
        if (!valid_player(&innings->bowlers[i], i, "bowler", message, size))
            return 0;

    for (i = 0; i < innings->over_count; ++i) {
        const Over *over = &innings->overs[i];
        if (over->over_number < 1 || over->runs < 0 || over->wickets < 0 ||
            over->wickets > 10)
            return fail(message, size, "%s contains an invalid over record at index %zu",
                        prefix, i + 1);
        if (i > 0 && over->over_number <= innings->overs[i - 1].over_number)
            return fail(message, size, "%s over numbers must be strictly increasing",
                        prefix);
    }

    for (i = 0; i < innings->fow_count; ++i) {
        const FallOfWicket *wicket = &innings->fow[i];
        if (!has_terminator(wicket->player_out, sizeof(wicket->player_out)))
            return fail(message, size, "%s has an unterminated fall-of-wicket player name",
                        prefix);
        if (wicket->wicket_number < 1 || wicket->wicket_number > 10 ||
            wicket->team_score < 0 || wicket->over_number < 0 ||
            wicket->ball_in_over < 0 || wicket->ball_in_over > 6)
            return fail(message, size, "%s contains an invalid fall-of-wicket record at index %zu",
                        prefix, i + 1);
        if (i > 0 && wicket->wicket_number <= innings->fow[i - 1].wicket_number)
            return fail(message, size, "%s fall-of-wicket numbers must be strictly increasing",
                        prefix);
    }

    return 1;
}

int match_validate(const Match *match, char *error_message, size_t message_size) {
    int i;

    if (error_message && message_size > 0) error_message[0] = '\0';
    if (!match) return fail(error_message, message_size, "match pointer is NULL");

    if (!has_terminator(match->match_id, sizeof(match->match_id)) ||
        !nonempty(match->match_id))
        return fail(error_message, message_size,
                    "match ID is empty or not terminated");
    if (!has_terminator(match->team1, sizeof(match->team1)) ||
        !nonempty(match->team1))
        return fail(error_message, message_size,
                    "team 1 name is empty or not terminated");
    if (!has_terminator(match->team2, sizeof(match->team2)) ||
        !nonempty(match->team2))
        return fail(error_message, message_size,
                    "team 2 name is empty or not terminated");
    if (!has_terminator(match->venue, sizeof(match->venue)))
        return fail(error_message, message_size,
                    "venue is not terminated");
    if (!has_terminator(match->date, sizeof(match->date)))
        return fail(error_message, message_size,
                    "date is not terminated");

    for (i = 0; i < 2; ++i)
        if (!valid_innings(&match->innings[i], (size_t)i,
                           error_message, message_size))
            return 0;

    return 1;
}


/* ================= SOURCE: component3/stats_engine.c ================= */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

static int safe_name(const char *s, size_t cap)
{
    return s != NULL && memchr(s, '\0', cap) != NULL && s[0] != '\0';
}

static int valid_player(const Player *p)
{
    long long boundary_runs;
    if (!p || !safe_name(p->name, sizeof(p->name))) return 0;
    if (p->runs < 0 || p->balls_faced < 0 || p->fours < 0 ||
        p->sixes < 0 || p->wickets < 0 || p->balls_bowled < 0 ||
        p->runs_conceded < 0) return 0;
    boundary_runs = 4LL * p->fours + 6LL * p->sixes;
    if (boundary_runs > p->runs) return 0;
    if (p->fours > p->balls_faced || p->sixes > p->balls_faced ||
        p->fours + (long long)p->sixes > p->balls_faced) return 0;
    return 1;
}

StatsStatus stats_validate_innings(const Innings *in)
{
    size_t i;
    if (!in) return STATS_INVALID_ARGUMENT;
    if (!safe_name(in->batting_team, sizeof(in->batting_team)))
        return STATS_INVALID_DATA;
    if (in->total_runs < 0 || in->wickets < 0 || in->wickets > 10 ||
        in->legal_balls < 0) return STATS_INVALID_DATA;
    if (in->batter_count > (size_t)INT_MAX ||
        in->bowler_count > (size_t)INT_MAX ||
        in->fow_count > (size_t)INT_MAX) return STATS_INVALID_DATA;
    if ((in->batter_count && !in->batters) ||
        (in->bowler_count && !in->bowlers) ||
        (in->over_count && !in->overs) ||
        (in->fow_count && !in->fow)) return STATS_INVALID_DATA;

    for (i = 0; i < in->batter_count; ++i)
        if (!valid_player(&in->batters[i])) return STATS_INVALID_DATA;
    for (i = 0; i < in->bowler_count; ++i)
        if (!valid_player(&in->bowlers[i])) return STATS_INVALID_DATA;

    for (i = 0; i < in->over_count; ++i) {
        const Over *o = &in->overs[i];
        if (o->over_number < 1 || o->runs < 0 || o->wickets < 0 ||
            o->wickets > 10) return STATS_INVALID_DATA;
        if (i && o->over_number <= in->overs[i - 1].over_number)
            return STATS_INVALID_DATA;
    }
    if (in->fow_count > (size_t)in->wickets) return STATS_INVALID_DATA;
    for (i = 0; i < in->fow_count; ++i) {
        const FallOfWicket *w = &in->fow[i];
        if (w->wicket_number < 1 || w->wicket_number > in->wickets ||
            w->team_score < 0 || w->team_score > in->total_runs ||
            w->over_number < 0 || w->ball_in_over < 0 ||
            w->ball_in_over > 6 ||
            !safe_name(w->player_out, sizeof(w->player_out)))
            return STATS_INVALID_DATA;
        if (i && w->wicket_number <= in->fow[i - 1].wicket_number)
            return STATS_INVALID_DATA;
    }
    return STATS_OK;
}

StatsStatus stats_format_overs(int legal_balls, char *buffer, size_t size)
{
    int n;
    if (!buffer || size == 0 || legal_balls < 0)
        return STATS_INVALID_ARGUMENT;
    n = snprintf(buffer, size, "%d.%d", legal_balls / 6, legal_balls % 6);
    if (n < 0 || (size_t)n >= size) return STATS_BUFFER_TOO_SMALL;
    return STATS_OK;
}

StatsStatus stats_batting(const Player *p, BattingStats *out)
{
    long long br;
    if (!p || !out) return STATS_INVALID_ARGUMENT;
    memset(out, 0, sizeof(*out));
    if (!valid_player(p)) return STATS_INVALID_DATA;
    br = 4LL * p->fours + 6LL * p->sixes;
    out->strike_rate = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
    out->boundary_runs = (int)br;
    out->boundary_count = p->fours + p->sixes;
    return p->balls_faced ? STATS_OK : STATS_NO_DATA;
}

StatsStatus stats_bowling(const Player *p, BowlingStats *out)
{
    int n;
    if (!p || !out) return STATS_INVALID_ARGUMENT;
    memset(out, 0, sizeof(*out));
    if (!valid_player(p)) return STATS_INVALID_DATA;
    n = snprintf(out->overs, sizeof(out->overs), "%d.%d",
                 p->balls_bowled / 6, p->balls_bowled % 6);
    if (n < 0 || (size_t)n >= sizeof(out->overs)) return STATS_BUFFER_TOO_SMALL;
    out->economy = p->balls_bowled
        ? 6.0 * p->runs_conceded / p->balls_bowled : 0.0;
    out->bowling_average = p->wickets
        ? (double)p->runs_conceded / p->wickets : 0.0;
    out->bowling_strike_rate = p->wickets
        ? (double)p->balls_bowled / p->wickets : 0.0;
    if (p->balls_bowled == 0 && p->wickets == 0) return STATS_NO_DATA;
    return STATS_OK;
}

StatsStatus stats_required_run_rate(int target, int current, int balls, double *out)
{
    int needed;
    if (!out) return STATS_INVALID_ARGUMENT;
    *out = 0.0;
    if (target < 0 || current < 0 || balls < 0)
        return STATS_INVALID_ARGUMENT;
    needed = target - current;
    if (needed <= 0) { *out = 0.0; return STATS_OK; }
    if (balls == 0) { *out = 0.0; return STATS_NO_DATA; }
    *out = 6.0 * needed / balls;
    return STATS_OK;
}

StatsStatus stats_innings(const Innings *in, InningsStats *out)
{
    size_t i;
    StatsStatus st;
    long long fours = 0, sixes = 0;
    int top = -1, best = -1, highest_runs = -1, highest_over = -1;
    if (!out) return STATS_INVALID_ARGUMENT;
    st = stats_validate_innings(in);
    if (st != STATS_OK) return st;
    memset(out, 0, sizeof(*out));
    out->top_scorer_index = -1;
    out->best_bowler_index = -1;
    out->last_wicket_index = -1;
    out->total_runs = in->total_runs;
    out->wickets = in->wickets;
    out->legal_balls = in->legal_balls;
    (void)stats_format_overs(in->legal_balls, out->overs, sizeof(out->overs));
    out->run_rate = in->legal_balls
        ? 6.0 * in->total_runs / in->legal_balls : 0.0;

    for (i = 0; i < in->batter_count; ++i) {
        const Player *p = &in->batters[i];
        if (fours > LLONG_MAX - p->fours ||
            sixes > LLONG_MAX - p->sixes) return STATS_INVALID_DATA;
        fours += p->fours;
        sixes += p->sixes;
        if (top < 0 || p->runs > in->batters[top].runs) top = (int)i;
    }
    if (fours > INT_MAX || sixes > INT_MAX) return STATS_INVALID_DATA;
    out->total_fours = (int)fours;
    out->total_sixes = (int)sixes;
    if (4LL * fours + 6LL * sixes > INT_MAX) return STATS_INVALID_DATA;
    out->boundary_runs = (int)(4LL * fours + 6LL * sixes);
    if (fours + sixes > INT_MAX) return STATS_INVALID_DATA;
    out->boundary_count = (int)(fours + sixes);
    out->top_scorer_index = top;

    for (i = 0; i < in->bowler_count; ++i) {
        const Player *p = &in->bowlers[i];
        if (p->wickets > 0 &&
            (best < 0 || p->wickets > in->bowlers[best].wickets ||
             (p->wickets == in->bowlers[best].wickets &&
              p->runs_conceded < in->bowlers[best].runs_conceded)))
            best = (int)i;
    }
    out->best_bowler_index = best;

    for (i = 0; i < in->over_count; ++i) {
        if (in->overs[i].runs > highest_runs) {
            highest_runs = in->overs[i].runs;
            highest_over = in->overs[i].over_number;
        }
    }
    out->highest_over_runs = highest_runs < 0 ? 0 : highest_runs;
    out->highest_over_number = highest_over;
    if (in->fow_count) out->last_wicket_index = (int)(in->fow_count - 1);
    return STATS_OK;
}

void stats_series_init(StatsSeries *s)
{
    if (!s) return;
    s->title[0] = '\0';
    s->points = NULL;
    s->count = 0;
}

void stats_series_free(StatsSeries *s)
{
    if (!s) return;
    free(s->points);
    stats_series_init(s);
}

static StatsStatus series_allocate(StatsSeries *out, const char *title, size_t count)
{
    StatsPoint *p = NULL;
    if (!out || !title) return STATS_INVALID_ARGUMENT;
    if (count) {
        if (count > (size_t)-1 / sizeof(*p)) return STATS_NO_MEMORY;
        p = (StatsPoint *)calloc(count, sizeof(*p));
        if (!p) return STATS_NO_MEMORY;
    }
    free(out->points);
    out->points = p;
    out->count = count;
    (void)snprintf(out->title, sizeof(out->title), "%s", title);
    return STATS_OK;
}

static StatsStatus validate_for_graph(const Innings *in, StatsSeries *out)
{
    if (!out) return STATS_INVALID_ARGUMENT;
    return stats_validate_innings(in);
}

StatsStatus stats_graph_runs_per_over(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Runs per over", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = in->overs[i].runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "Over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_wickets_per_over(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Wickets per over", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = in->overs[i].wickets;
        (void)snprintf(out->points[i].label, NAME_LEN, "Over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_cumulative_runs(const Innings *in, StatsSeries *out)
{
    size_t i;
    long long total = 0;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->over_count) return STATS_NO_DATA;
    st = series_allocate(out, "Cumulative runs", in->over_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->over_count; ++i) {
        if (total > LLONG_MAX - (long long)in->overs[i].runs) {
            stats_series_free(out);
            return STATS_INVALID_DATA;
        }
        total += in->overs[i].runs;
        out->points[i].x = in->overs[i].over_number;
        out->points[i].y = (double)total;
        (void)snprintf(out->points[i].label, NAME_LEN, "After over %d", in->overs[i].over_number);
    }
    return STATS_OK;
}

StatsStatus stats_graph_batter_runs(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    st = series_allocate(out, "Batter runs", in->batter_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->batter_count; ++i) {
        out->points[i].x = (double)(i + 1);
        out->points[i].y = in->batters[i].runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->batters[i].name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_batter_strike_rates(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    st = series_allocate(out, "Batter strike rates", in->batter_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->batter_count; ++i) {
        const Player *p = &in->batters[i];
        out->points[i].x = (double)(i + 1);
        out->points[i].y = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", p->name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_bowler_wickets(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->bowler_count) return STATS_NO_DATA;
    st = series_allocate(out, "Bowler wickets", in->bowler_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->bowler_count; ++i) {
        out->points[i].x = (double)(i + 1);
        out->points[i].y = in->bowlers[i].wickets;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->bowlers[i].name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_bowler_economy(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->bowler_count) return STATS_NO_DATA;
    st = series_allocate(out, "Bowler economy", in->bowler_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->bowler_count; ++i) {
        const Player *p = &in->bowlers[i];
        out->points[i].x = (double)(i + 1);
        out->points[i].y = p->balls_bowled
            ? 6.0 * p->runs_conceded / p->balls_bowled : 0.0;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", p->name);
    }
    return STATS_OK;
}

StatsStatus stats_graph_fall_of_wickets(const Innings *in, StatsSeries *out)
{
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->fow_count) return STATS_NO_DATA;
    st = series_allocate(out, "Fall of wickets", in->fow_count);
    if (st != STATS_OK) return st;
    for (i = 0; i < in->fow_count; ++i) {
        out->points[i].x = in->fow[i].team_score;
        out->points[i].y = in->fow[i].wicket_number;
        (void)snprintf(out->points[i].label, NAME_LEN, "%s", in->fow[i].player_out);
    }
    return STATS_OK;
}

StatsStatus stats_graph_boundaries(const Innings *in, StatsSeries *out)
{
    long long fours = 0, sixes = 0;
    size_t i;
    StatsStatus st = validate_for_graph(in, out);
    if (st != STATS_OK) return st;
    if (!in->batter_count) return STATS_NO_DATA;
    for (i = 0; i < in->batter_count; ++i) {
        if (fours > LLONG_MAX - in->batters[i].fours ||
            sixes > LLONG_MAX - in->batters[i].sixes) return STATS_INVALID_DATA;
        fours += in->batters[i].fours;
        sixes += in->batters[i].sixes;
    }
    st = series_allocate(out, "Fours and sixes", 2);
    if (st != STATS_OK) return st;
    out->points[0].x = 1; out->points[0].y = (double)fours;
    (void)snprintf(out->points[0].label, NAME_LEN, "Fours");
    out->points[1].x = 2; out->points[1].y = (double)sixes;
    (void)snprintf(out->points[1].label, NAME_LEN, "Sixes");
    return STATS_OK;
}

static StatsStatus innings_comparison(const Match *m, StatsSeries *out, int wickets)
{
    int i;
    StatsStatus st;
    if (!m || !out) return STATS_INVALID_ARGUMENT;
    for (i = 0; i < 2; ++i) {
        st = stats_validate_innings(&m->innings[i]);
        if (st != STATS_OK) return st;
    }
    st = series_allocate(out, wickets ? "Innings wickets comparison" :
                         "Innings runs comparison", 2);
    if (st != STATS_OK) return st;
    for (i = 0; i < 2; ++i) {
        const Innings *in = &m->innings[i];
        out->points[i].x = i + 1;
        out->points[i].y = wickets ? in->wickets : in->total_runs;
        (void)snprintf(out->points[i].label, NAME_LEN, "%.49s", in->batting_team);
    }
    return STATS_OK;
}

StatsStatus stats_graph_innings_runs_comparison(const Match *m, StatsSeries *out)
{
    return innings_comparison(m, out, 0);
}

StatsStatus stats_graph_innings_wickets_comparison(const Match *m, StatsSeries *out)
{
    return innings_comparison(m, out, 1);
}

StatsStatus stats_print_innings_report(const Innings *in)
{
    InningsStats s;
    StatsStatus st = stats_innings(in, &s);
    size_t i;
    if (st != STATS_OK) return st;

    printf("\n========== %s: INNINGS REPORT ==========\n", in->batting_team);
    printf("Score             : %d/%d\n", s.total_runs, s.wickets);
    printf("Overs             : %s\n", s.overs);
    printf("Run rate          : %.2f\n", s.run_rate);
    printf("Fours / Sixes     : %d / %d\n", s.total_fours, s.total_sixes);
    printf("Boundary runs     : %d (%d boundaries)\n",
           s.boundary_runs, s.boundary_count);
    if (s.top_scorer_index >= 0) {
        const Player *p = &in->batters[s.top_scorer_index];
        BattingStats bs;
        StatsStatus bst = stats_batting(p, &bs);
        printf("Top scorer        : %s - %d (%d balls)",
               p->name, p->runs, p->balls_faced);
        if (bst == STATS_OK) printf(", SR %.2f", bs.strike_rate);
        printf("\n");
    } else printf("Top scorer        : unavailable\n");

    if (s.best_bowler_index >= 0) {
        const Player *p = &in->bowlers[s.best_bowler_index];
        BowlingStats bw;
        StatsStatus bws = stats_bowling(p, &bw);
        printf("Best bowler       : %s - %d wicket(s)",
               p->name, p->wickets);
        if (bws == STATS_OK) printf(", economy %.2f", bw.economy);
        printf("\n");
    } else printf("Best bowler       : unavailable\n");

    if (s.highest_over_number >= 0)
        printf("Highest-scoring over: Over %d (%d runs)\n",
               s.highest_over_number, s.highest_over_runs);
    if (s.last_wicket_index >= 0) {
        const FallOfWicket *w = &in->fow[s.last_wicket_index];
        printf("Last wicket       : %s, %d/%d at %d.%d\n",
               w->player_out, w->wicket_number, w->team_score,
               w->over_number, w->ball_in_over);
    } else printf("Last wicket       : unavailable\n");

    if (in->batter_count) {
        printf("\nBATTING\n");
        printf("%-20s %6s %6s %6s %6s %8s\n",
               "Player", "Runs", "Balls", "4s", "6s", "SR");
        for (i = 0; i < in->batter_count; ++i) {
            const Player *p = &in->batters[i];
            double sr = p->balls_faced ? 100.0 * p->runs / p->balls_faced : 0.0;
            printf("%-20.20s %6d %6d %6d %6d %8.2f\n",
                   p->name, p->runs, p->balls_faced,
                   p->fours, p->sixes, sr);
        }
    }
    if (in->bowler_count) {
        printf("\nBOWLING\n");
        printf("%-20s %7s %7s %7s %8s %8s\n",
               "Player", "Overs", "Runs", "Wkts", "Econ", "Avg");
        for (i = 0; i < in->bowler_count; ++i) {
            const Player *p = &in->bowlers[i];
            BowlingStats bw;
            (void)stats_bowling(p, &bw);
            printf("%-20.20s %7s %7d %7d %8.2f %8.2f\n",
                   p->name, bw.overs, p->runs_conceded, p->wickets,
                   bw.economy, bw.bowling_average);
        }
    }
    printf("========================================\n");
    return STATS_OK;
}


/* ================= SOURCE: component3/stats_legacy_compat.c ================= */
#include <stdio.h>
#include <string.h>
/*
 * Compatibility layer for the original Component 5 interface.
 * The calculations for batting and over-by-over graph data now delegate to
 * the improved Component 3 API. Awards, result text and partnerships retain
 * their original public interface so existing Component 5 code keeps working.
 */
void stats_batter(const Player *p, int dismissals, BatterStats *out)
{
    BattingStats calculated;
    StatsStatus status;
    if (!p || !out) return;
    memset(out, 0, sizeof(*out));
    status = stats_batting(p, &calculated);
    if (status != STATS_OK && status != STATS_NO_DATA) return;
    out->strike_rate = (float)calculated.strike_rate;
    out->average = dismissals > 0 ? (float)p->runs / dismissals : (float)p->runs;
    out->boundary_pct = p->runs > 0
        ? (float)calculated.boundary_runs * 100.0f / (float)p->runs : 0.0f;
}

static int copy_series_y(const Innings *in, int *out, int max,
                         StatsStatus (*builder)(const Innings *, StatsSeries *))
{
    StatsSeries series;
    StatsStatus status;
    size_t i, count;
    if (!in || !out || max <= 0) return 0;
    stats_series_init(&series);
    status = builder(in, &series);
    if (status != STATS_OK) {
        stats_series_free(&series);
        return 0;
    }
    count = series.count < (size_t)max ? series.count : (size_t)max;
    for (i = 0; i < count; ++i) out[i] = (int)series.points[i].y;
    stats_series_free(&series);
    return (int)count;
}

int stats_over_runs(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_runs_per_over);
}

int stats_cumulative_runs(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_cumulative_runs);
}

int stats_over_wickets(const Innings *in, int *out, int max)
{
    return copy_series_y(in, out, max, stats_graph_wickets_per_over);
}

/* ---- Partnerships, worked out from the fall of wickets ---- */
static void batter_name(const Innings *in, size_t idx, char *dst)
{
    if (idx < in->batter_count) snprintf(dst, NAME_LEN, "%s", in->batters[idx].name);
    else snprintf(dst, NAME_LEN, "Batter %zu", idx + 1);
}

int stats_partnerships(const Innings *in, Partnership *out, int max)
{
    size_t k;
    int n = 0, prev = 0;
    if (!in || !out || max <= 0) return 0;
    for (k = 0; k < in->fow_count && n < max; ++k) {
        out[n].runs = in->fow[k].team_score - prev;
        out[n].unbeaten = 0;
        prev = in->fow[k].team_score;
        batter_name(in, k, out[n].bat1);
        batter_name(in, k + 1, out[n].bat2);
        ++n;
    }
    if (in->wickets < 10 && in->total_runs > prev && n < max) {
        out[n].runs = in->total_runs - prev;
        out[n].unbeaten = 1;
        batter_name(in, k, out[n].bat1);
        batter_name(in, k + 1, out[n].bat2);
        ++n;
    }
    return n;
}

/* ---- Awards and result ---- */
typedef struct { char name[NAME_LEN]; int pts, six, wk; } Tally;

static Tally *tally_for(Tally *t, int *n, int cap, const char *name)
{
    int i;
    for (i = 0; i < *n; ++i) if (strcmp(t[i].name, name) == 0) return &t[i];
    if (*n >= cap) return NULL;
    snprintf(t[*n].name, NAME_LEN, "%s", name);
    t[*n].pts = t[*n].six = t[*n].wk = 0;
    return &t[(*n)++];
}

int stats_awards(const Match *m, MatchAwards *out)
{
    Tally t[128], *x;
    int n = 0, i, best = 0;
    size_t k;
    double best_sr = -1.0;

    if (!m || !out) return 0;
    memset(out, 0, sizeof *out);
    snprintf(out->man_of_match, NAME_LEN, "-"); snprintf(out->most_sixes, NAME_LEN, "-");
    snprintf(out->most_wickets, NAME_LEN, "-"); snprintf(out->super_striker, NAME_LEN, "-");

    for (i = 0; i < 2; ++i) {
        const Innings *in = &m->innings[i];
        for (k = 0; k < in->batter_count; ++k) {
            const Player *p = &in->batters[k];
            x = tally_for(t, &n, 128, p->name);
            if (!x) continue;
            x->pts += p->runs; x->six += p->sixes;
            if (p->balls_faced >= STATS_MIN_BALLS_STRIKER && (double)p->runs * 100.0 / p->balls_faced > best_sr) {
                best_sr = (double)p->runs * 100.0 / p->balls_faced;
                snprintf(out->super_striker, NAME_LEN, "%s", p->name);
                out->strike_rate = (float)best_sr;
            }
        }
        for (k = 0; k < in->bowler_count; ++k) {
            const Player *p = &in->bowlers[k];
            x = tally_for(t, &n, 128, p->name);
            if (!x) continue;
            x->wk += p->wickets; x->pts += STATS_POINTS_PER_WICKET * p->wickets;
        }
    }
    for (i = 1; i < n; ++i) if (t[i].pts > t[best].pts) best = i;
    if (n > 0) { snprintf(out->man_of_match, NAME_LEN, "%.49s", t[best].name); out->mom_points = t[best].pts; best = 0; }
    for (i = 1; i < n; ++i) if (t[i].six > t[best].six) best = i;
    if (n > 0 && t[best].six > 0) { snprintf(out->most_sixes, NAME_LEN, "%.49s", t[best].name); out->sixes = t[best].six; }
    best = 0;
    for (i = 1; i < n; ++i) if (t[i].wk > t[best].wk) best = i;
    if (n > 0 && t[best].wk > 0) { snprintf(out->most_wickets, NAME_LEN, "%s", t[best].name); out->wickets = t[best].wk; }
    return 1;
}

int stats_result(const Match *m, char *buf, size_t size)
{
    const Innings *a, *b;
    if (!m || !buf || size == 0) return 0;
    a = &m->innings[0]; b = &m->innings[1];
    if (b->total_runs > a->total_runs) snprintf(buf, size, "%s won by %d wickets", b->batting_team, 10 - b->wickets);
    else if (a->total_runs > b->total_runs) snprintf(buf, size, "%s won by %d runs", a->batting_team, a->total_runs - b->total_runs);
    else snprintf(buf, size, "Match tied");
    return 1;
}


/* ================= SOURCE: component4/chart_render.c ================= */
/*
 * Component 4: Graph Rendering Engine (module; test_render.c has the demo)
 *
 * Features:
 *   - Bar, line, and pie charts
 *   - ASCII terminal rendering
 *   - SVG vector output
 *   - 24-bit uncompressed BMP output
 *   - Static mock data; no external libraries
 *
 * Build: see README.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#define MAX_CHART_POINTS 1000
#define PALETTE_N 5
#define CANVAS_W 800
#define CANVAS_H 500
#define LEFT 70
#define RIGHT 40
#define TOP 55
#define BOTTOM 70
#define PI 3.14159265358979323846
typedef struct { unsigned char r, g, b; } Color;
typedef struct { int w, h; Color *pixels; } Canvas;

static const DataPoint *g_data;   /* set by the public functions below */
static int g_n;
static const Color PALETTE[PALETTE_N] = {
    {52, 120, 200}, {230, 126, 34}, {46, 160, 67},
    {155, 89, 182}, {220, 65, 80}
};

static double max_value(void) {
    double m = 0.0; int i;
    for (i = 0; i < g_n; ++i) if (g_data[i].value > m) m = g_data[i].value;
    return m;
}
static double total_value(void) {
    double s = 0.0; int i;
    for (i = 0; i < g_n; ++i) s += g_data[i].value;
    return s;
}
static void color_hex(Color c, char out[8]) {
    (void)snprintf(out, 8, "#%02X%02X%02X", c.r, c.g, c.b);
}

/* ----------------------------- ASCII ----------------------------------- */
static void ascii_bar(void) {
    int i, n; printf("\n=== BAR CHART (ASCII) ===\n");
    for (i = 0; i < g_n; ++i) {
        n = (int)(g_data[i].value / max_value() * 40.0 + 0.5);
        printf("%-16.16s | ", g_data[i].label);
        while (n-- > 0) putchar('#');
        printf(" %.0f\n", g_data[i].value);
    }
}
static void ascii_line(void) {
    int row, col, i; const int width = 50, height = 12;
    char grid[13][51];
    memset(grid, ' ', sizeof(grid));
    for (row = 0; row < height; ++row) grid[row][width] = '\0';
    for (i = 0; i < g_n; ++i) {
        int x = i * (width - 1) / (g_n - 1);
        int y = height - 1 - (int)(g_data[i].value / max_value() * (height - 1));
        grid[y][x] = '*';
        if (i > 0) {
            int px = (i - 1) * (width - 1) / (g_n - 1);
            int py = height - 1 - (int)(g_data[i - 1].value / max_value() * (height - 1));
            int dx = x - px, dy = y - py, steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy), k;
            for (k = 1; k < steps; ++k) {
                int xx = px + (int)lround((double)dx * k / steps);
                int yy = py + (int)lround((double)dy * k / steps);
                if (xx >= 0 && xx < width && yy >= 0 && yy < height && grid[yy][xx] == ' ') grid[yy][xx] = '.';
            }
        }
    }
    printf("\n=== LINE CHART (ASCII) ===\n");
    for (row = 0; row < height; ++row) printf("%3d | %s\n", (height - 1 - row) * (int)(max_value() / (height - 1)), grid[row]);
    printf("    +--------------------------------------------------\n     ");
    { char axis[64]; int last = -1, len, pos, j; memset(axis, ' ', sizeof(axis)); axis[62] = '\0';
      for (i = 0; i < g_n; ++i) { pos = i * (width - 1) / (g_n - 1); len = (int)strlen(g_data[i].label);
        if (pos > last && pos + len <= 62) { for (j = 0; j < len; ++j) axis[pos + j] = g_data[i].label[j]; last = pos + len; } }
      printf("%s", axis); }
    putchar('\n');
    (void)col;
}
static void ascii_pie(void) {
    int i; double total = total_value();
    printf("\n=== PIE CHART (ASCII SHARE BARS) ===\n");
    for (i = 0; i < g_n; ++i) {
        int n = (int)(g_data[i].value / total * 40.0 + 0.5);
        printf("%-16.16s | ", g_data[i].label);
        while (n-- > 0) putchar('#');
        printf(" %5.1f%%\n", g_data[i].value / total * 100.0);
    }
    printf("(ASCII uses proportional share bars; SVG/BMP render a true pie.)\n");
}

/* ------------------------ Minimal raster drawing ----------------------- */
static Canvas canvas_create(int w, int h, Color bg) {
    Canvas c; size_t i, count = (size_t)w * (size_t)h;
    c.w = w; c.h = h; c.pixels = (Color *)malloc(count * sizeof(Color));
    if (!c.pixels) { fprintf(stderr, "Out of memory creating canvas\n"); exit(EXIT_FAILURE); }
    for (i = 0; i < count; ++i) c.pixels[i] = bg;
    return c;
}
static void pixel(Canvas *c, int x, int y, Color color) {
    if (x >= 0 && x < c->w && y >= 0 && y < c->h) c->pixels[(size_t)y * c->w + x] = color;
}
static void line(Canvas *c, int x0, int y0, int x1, int y1, Color color) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) { int e2; pixel(c, x0, y0, color); if (x0 == x1 && y0 == y1) break;
        e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
static void rect_fill(Canvas *c, int x0, int y0, int x1, int y1, Color color) {
    int x, y; if (x0 > x1) { int t=x0; x0=x1; x1=t; } if (y0 > y1) { int t=y0; y0=y1; y1=t; }
    for (y = y0; y <= y1; ++y) for (x = x0; x <= x1; ++x) pixel(c, x, y, color);
}
static void circle_wedge(Canvas *c, int cx, int cy, int r, double a0, double a1, Color color) {
    int x, y;
    for (y = cy-r; y <= cy+r; ++y) for (x = cx-r; x <= cx+r; ++x) {
        double dx=x-cx, dy=cy-y, a, rr=dx*dx+dy*dy;
        if (rr > (double)r*r) continue;
        a = atan2(dy, dx); if (a < 0) a += 2*PI;
        if (a0 <= a1 ? (a >= a0 && a <= a1) : (a >= a0 || a <= a1)) pixel(c,x,y,color);
    }
}
static void bmp_u16(FILE *f, uint16_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); }
static void bmp_u32(FILE *f, uint32_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); fputc((v >> 16) & 255, f); fputc((v >> 24) & 255, f); }
static int write_bmp(const char *path, const Canvas *c) {
    FILE *f = fopen(path, "wb"); int x, y; uint32_t row_size = ((uint32_t)c->w * 3u + 3u) & ~3u;
    uint32_t image_size = row_size * (uint32_t)c->h;
    if (!f) { perror(path); return 0; }
    fputc('B', f); fputc('M', f); bmp_u32(f, 54u + image_size); bmp_u16(f,0); bmp_u16(f,0); bmp_u32(f,54);
    bmp_u32(f,40); bmp_u32(f,(uint32_t)c->w); bmp_u32(f,(uint32_t)c->h); bmp_u16(f,1); bmp_u16(f,24);
    bmp_u32(f,0); bmp_u32(f,image_size); bmp_u32(f,2835); bmp_u32(f,2835); bmp_u32(f,0); bmp_u32(f,0);
    for (y = c->h - 1; y >= 0; --y) {
        for (x = 0; x < c->w; ++x) { Color p = c->pixels[(size_t)y*c->w+x]; fputc(p.b,f); fputc(p.g,f); fputc(p.r,f); }
        for (x = c->w * 3; x < (int)row_size; ++x) fputc(0,f);
    }
    if (fclose(f) != 0) { perror("closing BMP"); return 0; } return 1;
}
static void canvas_free(Canvas *c) { free(c->pixels); c->pixels = NULL; }

/* Simple bitmap-style labels are intentionally omitted from BMP: the test
   focuses on chart geometry, color regions, axes, and output file validity. */
static Canvas raster_chart(int kind) {
    Color white={255,255,255}, black={35,35,35}, grey={220,220,220};
    Canvas c=canvas_create(CANVAS_W,CANVAS_H,white); int i;
    int plot_h=CANVAS_H-TOP-BOTTOM, plot_w=CANVAS_W-LEFT-RIGHT;
    if (kind == 2) {
        double a=0.0, total=total_value();
        for (i=0;i<g_n;++i) { double next=a+2*PI*g_data[i].value/total; circle_wedge(&c, CANVAS_W/2, CANVAS_H/2, 170, a, next, PALETTE[i % PALETTE_N]); a=next; }
        return c;
    }
    line(&c,LEFT,TOP,LEFT,CANVAS_H-BOTTOM,black); line(&c,LEFT,CANVAS_H-BOTTOM,CANVAS_W-RIGHT,CANVAS_H-BOTTOM,black);
    for (i=1;i<=5;++i) { int y=CANVAS_H-BOTTOM-(plot_h*i/5); line(&c,LEFT,y,CANVAS_W-RIGHT,y,grey); }
    if (kind == 0) {
        int slot=plot_w/g_n, bar_w=slot*55/100;
        for (i=0;i<g_n;++i) { int h=(int)(g_data[i].value/max_value()*(plot_h-10)); int x=LEFT+i*slot+(slot-bar_w)/2; rect_fill(&c,x,CANVAS_H-BOTTOM-h,x+bar_w,CANVAS_H-BOTTOM-1,PALETTE[i % PALETTE_N]); }
    } else {
        int px[g_n], py[g_n];
        for (i=0;i<g_n;++i) { px[i]=LEFT+i*plot_w/(g_n-1); py[i]=CANVAS_H-BOTTOM-(int)(g_data[i].value/max_value()*(plot_h-10)); }
        for (i=0;i<g_n-1;++i) line(&c,px[i],py[i],px[i+1],py[i+1],PALETTE[0]);
        for (i=0;i<g_n;++i) rect_fill(&c,px[i]-5,py[i]-5,px[i]+5,py[i]+5,PALETTE[i % PALETTE_N]);
    }
    return c;
}

/* ------------------------------ SVG ------------------------------------ */
static int svg_bar(FILE *f) {
    int i, slot=600/g_n, bw=slot*55/100; double max=max_value();
    fprintf(f,"<line x1='70' y1='420' x2='760' y2='420' stroke='#222'/><line x1='70' y1='55' x2='70' y2='420' stroke='#222'/>\n");
    for (i=0;i<g_n;++i) { int h=(int)(g_data[i].value/max*330); int x=70+i*slot+(slot-bw)/2; char hex[8]; color_hex(PALETTE[i % PALETTE_N],hex);
        fprintf(f,"<rect x='%d' y='%d' width='%d' height='%d' fill='%s'/><text x='%d' y='445' text-anchor='middle' font-size='14'>%s</text><text x='%d' y='%d' text-anchor='middle' font-size='13'>%.0f</text>\n",x,420-h,bw,h,hex,x+bw/2,g_data[i].label,x+bw/2,415-h,g_data[i].value);
    } return 1;
}
static int svg_line(FILE *f) {
    int i, x[g_n],y[g_n]; double max=max_value();
    fprintf(f,"<line x1='70' y1='420' x2='760' y2='420' stroke='#222'/><line x1='70' y1='55' x2='70' y2='420' stroke='#222'/>\n");
    for(i=0;i<g_n;++i){x[i]=70+i*690/(g_n-1);y[i]=420-(int)(g_data[i].value/max*330);}
    for(i=0;i<g_n-1;++i) fprintf(f,"<line x1='%d' y1='%d' x2='%d' y2='%d' stroke='#3478C8' stroke-width='3'/>\n",x[i],y[i],x[i+1],y[i+1]);
    for(i=0;i<g_n;++i) fprintf(f,"<circle cx='%d' cy='%d' r='6' fill='%s'/><text x='%d' y='445' text-anchor='middle' font-size='14'>%s</text><text x='%d' y='%d' text-anchor='middle' font-size='13'>%.0f</text>\n",x[i],y[i],"#3478C8",x[i],g_data[i].label,x[i],y[i]-12,g_data[i].value);
    return 1;
}
static int svg_pie(FILE *f) {
    double a= -PI/2, total=total_value(); int i; const double cx=400,cy=250,r=170;
    for(i=0;i<g_n;++i){ double next=a+2*PI*g_data[i].value/total; double x1=cx+r*cos(a),y1=cy+r*sin(a),x2=cx+r*cos(next),y2=cy+r*sin(next); char hex[8]; color_hex(PALETTE[i % PALETTE_N],hex);
        fprintf(f,"<path d='M %.2f %.2f L %.2f %.2f A %.2f %.2f 0 %d 1 %.2f %.2f Z' fill='%s' stroke='white' stroke-width='2'/>\n",cx,cy,x1,y1,r,r,(next-a)>PI?1:0,x2,y2,hex); a=next;
    }
    for(i=0;i<g_n;++i){char hex[8];color_hex(PALETTE[i % PALETTE_N],hex);fprintf(f,"<rect x='620' y='%d' width='14' height='14' fill='%s'/><text x='642' y='%d' font-size='14'>%s (%.1f%%)</text>\n",130+i*30,hex,142+i*30,g_data[i].label,g_data[i].value/total*100.0);}
    return 1;
}
static int write_svg(const char *path, int kind, const char *title) {
    FILE *f=fopen(path,"w"); if(!f){perror(path);return 0;}
    fprintf(f,"<?xml version='1.0' encoding='UTF-8'?>\n<svg xmlns='http://www.w3.org/2000/svg' width='800' height='500' viewBox='0 0 800 500'>\n<rect width='100%%' height='100%%' fill='white'/><text x='400' y='30' text-anchor='middle' font-size='22' font-family='sans-serif'>%s</text>\n",title);
    if(kind==0) svg_bar(f); else if(kind==1) svg_line(f); else svg_pie(f);
    fprintf(f,"</svg>\n"); if(fclose(f)!=0){perror("closing SVG");return 0;} return 1;
}


/* ------------------------- Public interface --------------------------- */
static int set_data(ChartKind kind, const DataPoint *d, int n) {
    int i;
    if (!d || n < 1 || n > MAX_CHART_POINTS || (int)kind < 0 || (int)kind > 2 || (kind == CHART_LINE && n < 2))
        return CHART_ERR_ARGS;
    for (i = 0; i < n; ++i)
        if (!d[i].label || d[i].value < 0.0) return CHART_ERR_ARGS;
    g_data = d; g_n = n;
    return max_value() > 0.0 ? CHART_OK : CHART_ERR_ARGS;
}

int chart_ascii(ChartKind kind, const DataPoint *data, int count) {
    int rc = set_data(kind, data, count);
    if (rc != CHART_OK) return rc;
    if (kind == CHART_BAR) ascii_bar(); else if (kind == CHART_LINE) ascii_line(); else ascii_pie();
    return CHART_OK;
}

int chart_svg(const char *path, ChartKind kind, const char *title, const DataPoint *data, int count) {
    int rc = set_data(kind, data, count);
    if (rc != CHART_OK || !path) return CHART_ERR_ARGS;
    return write_svg(path, (int)kind, title ? title : "Chart") ? CHART_OK : CHART_ERR_FILE;
}

int chart_bmp(const char *path, ChartKind kind, const DataPoint *data, int count) {
    Canvas c; int ok, rc = set_data(kind, data, count);
    if (rc != CHART_OK || !path) return CHART_ERR_ARGS;
    c = raster_chart((int)kind);
    ok = write_bmp(path, &c);
    canvas_free(&c);
    return ok ? CHART_OK : CHART_ERR_FILE;
}

const char *chart_error_message(int code) {
    switch (code) {
    case CHART_OK:       return "OK";
    case CHART_ERR_ARGS: return "Invalid chart data (empty, negative, all zero, or too few points).";
    case CHART_ERR_FILE: return "Could not write the chart file.";
    default:             return "Unknown chart error.";
    }
}


/* ================= SOURCE: component5/sg5_adapter.c ================= */
/* Adapter: the only subgroup 5 file that reads Component 2's Match structs directly. */
#include <string.h>
static MatchStore g_store;

int sg5_init(void)
{
    store_init(&g_store);
    if (!sg5_sample_matches(&g_store)) {
        store_free(&g_store);
        return 0;
    }
    return 1;
}

void sg5_shutdown(void)
{
    store_free(&g_store);
}

int sg5_match_count(void)
{
    return (int)g_store.count;
}

void sg5_match_title(int index, char *buf, size_t size)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    if (m) snprintf(buf, size, "%s v %s", m->team1, m->team2);
    else snprintf(buf, size, "(no match)");
}

static void fill_innings(const Innings *in, InningsPlot *p)
{
    Partnership ps[SG5_MAX_PSHIPS];
    int i, n;

    memset(p, 0, sizeof *p);
    snprintf(p->team, NAME_LEN, "%s", in->batting_team);
    p->total_runs = in->total_runs;
    p->wickets = in->wickets;
    p->balls = in->legal_balls;
    p->overs = stats_over_runs(in, p->runs_per_over, SG5_MAX_OVERS);
    stats_cumulative_runs(in, p->cumulative_runs, SG5_MAX_OVERS);
    stats_over_wickets(in, p->wicket_in_over, SG5_MAX_OVERS);
    n = stats_partnerships(in, ps, SG5_MAX_PSHIPS);
    for (i = 0; i < n; i++) {
        snprintf(p->pship_bat1[i], NAME_LEN, "%.49s", ps[i].bat1);
        snprintf(p->pship_bat2[i], NAME_LEN, "%.49s", ps[i].bat2);
        p->pship_runs[i] = ps[i].runs;
        p->pship_unbeaten[i] = ps[i].unbeaten;
    }
    p->num_partnerships = n;
}

int sg5_load_match(int index, Sg5Match *out)
{
    const Match *m = store_get_match(&g_store, (size_t)index);

    if (!m || !out) return -1;
    memset(out, 0, sizeof *out);
    snprintf(out->info.title, sizeof out->info.title, "%s v %s", m->team1, m->team2);
    snprintf(out->info.venue, VENUE_LEN, "%s", m->venue);
    snprintf(out->info.date, DATE_LEN, "%s", m->date);
    snprintf(out->info.id, MATCH_ID_LEN, "%s", m->match_id);
    fill_innings(&m->innings[0], &out->in[0]);
    fill_innings(&m->innings[1], &out->in[1]);
    if (!stats_awards(m, &out->aw) || !stats_result(m, out->result, sizeof out->result)) return -1;
    return 0;
}

int sg5_add_from_file(const char *path, char *error, size_t error_size)
{
    Match m;
    int ok;

    memset(&m, 0, sizeof m);
    if (!load_match_file(path, &m, error, error_size)) return 0;
    ok = store_add_match(&g_store, &m);
    match_free(&m);
    if (!ok && error && error_size) snprintf(error, error_size, "the match could not be stored");
    return ok;
}

int sg5_max_over_runs(const Sg5Match *m)
{
    int i, k, mx = 10;

    for (i = 0; i < 2; i++)
        for (k = 0; k < m->in[i].overs; k++)
            if (m->in[i].runs_per_over[k] > mx) mx = m->in[i].runs_per_over[k];
    return mx;
}

int sg5_scorecard(int index, int innings, Sg5Card *out)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    const Innings *in;
    size_t k, j;

    if (!m || !out || innings < 0 || innings > 1) return -1;
    memset(out, 0, sizeof *out);
    in = &m->innings[innings];
    for (k = 0; k < in->batter_count && out->nbat < SG5_MAX_ROWS; k++) {
        const Player *p = &in->batters[k];
        Sg5BatRow *r = &out->bat[out->nbat];
        int dismissed = 0;
        for (j = 0; j < in->fow_count; j++)
            if (strcmp(in->fow[j].player_out, p->name) == 0) dismissed = 1;
        if (p->balls_faced <= 0 && !dismissed) continue;          /* did not bat */
        snprintf(r->name, NAME_LEN, "%.49s", p->name);
        r->runs = p->runs; r->balls = p->balls_faced; r->fours = p->fours; r->sixes = p->sixes; r->out = dismissed;
        r->sr = p->balls_faced > 0 ? 100.0 * p->runs / p->balls_faced : 0.0;
        r->bnd_pct = p->runs > 0 ? 100.0 * (4 * p->fours + 6 * p->sixes) / p->runs : 0.0;
        out->nbat++;
    }
    for (k = 0; k < in->bowler_count && out->nbowl < SG5_MAX_ROWS; k++) {
        const Player *p = &in->bowlers[k];
        Sg5BowlRow *r = &out->bowl[out->nbowl];
        if (p->balls_bowled <= 0) continue;
        snprintf(r->name, NAME_LEN, "%.49s", p->name);
        r->runs = p->runs_conceded; r->wickets = p->wickets; r->balls = p->balls_bowled;
        r->econ = 6.0 * p->runs_conceded / p->balls_bowled;
        out->nbowl++;
    }
    for (k = 0; k < in->fow_count && out->nfow < SG5_MAX_ROWS; k++) {
        const FallOfWicket *f = &in->fow[k];
        Sg5FowRow *r = &out->fow[out->nfow++];
        r->wkt = f->wicket_number; r->score = f->team_score; r->over = f->over_number; r->ball = f->ball_in_over;
        snprintf(r->name, NAME_LEN, "%.49s", f->player_out);
    }
    return 0;
}

int sg5_mvp(int index, Sg5MvpRow *out, int max_rows)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    Sg5MvpRow t[64];
    int n = 0, i, j, a;
    size_t k;

    if (!m || !out || max_rows < 1) return 0;
    for (a = 0; a < 2; a++) {
        const Innings *in = &m->innings[a];
        for (k = 0; k < in->batter_count + in->bowler_count; k++) {
            int bat = k < in->batter_count;
            const Player *p = bat ? &in->batters[k] : &in->bowlers[k - in->batter_count];
            int add_runs = bat ? p->runs : 0, add_wk = bat ? 0 : p->wickets;
            for (i = 0; i < n; i++) if (strcmp(t[i].name, p->name) == 0) break;
            if (i == n) {
                if (n >= 64) continue;
                memset(&t[n], 0, sizeof t[n]);
                snprintf(t[n].name, NAME_LEN, "%.49s", p->name);
                n++;
            }
            t[i].runs += add_runs; t[i].wickets += add_wk;
            t[i].points += add_runs + STATS_POINTS_PER_WICKET * add_wk;     /* same formula as the Man of the Match */
        }
    }
    for (i = 1; i < n; i++) {                                              /* insertion sort, highest points first */
        Sg5MvpRow x = t[i];
        for (j = i - 1; j >= 0 && t[j].points < x.points; j--) t[j + 1] = t[j];
        t[j + 1] = x;
    }
    if (n > max_rows) n = max_rows;
    memcpy(out, t, (size_t)n * sizeof t[0]);
    return n;
}


/* ================= SOURCE: component5/sg5_awards.c ================= */
/* Match awards: man of the match, most sixes, most wickets, super striker. */
void sg5_awards_show(const Sg5Match *m)
{
    printf("\nMatch awards\n");
    printf("  Man of the match: %s (%d points)\n", m->aw.man_of_match, m->aw.mom_points);
    printf("  Most sixes:       %s (%d)\n", m->aw.most_sixes, m->aw.sixes);
    printf("  Most wickets:     %s (%d)\n", m->aw.most_wickets, m->aw.wickets);
    printf("  Super striker:    %s (strike rate %.1f)\n", m->aw.super_striker, m->aw.strike_rate);
}



/* ================= SOURCE: component5/sg5_manhattan.c ================= */
/* Manhattan chart: runs per over as bars, wicket overs marked W. */
void sg5_manhattan_show(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_OVERS];
    char lab[SG5_MAX_OVERS][16];
    int i, rc;

    for (i = 0; i < p->overs; i++) {
        snprintf(lab[i], sizeof lab[i], "Over %d%s", i + 1, p->wicket_in_over[i] ? " W" : "");
        pts[i].label = lab[i];
        pts[i].value = p->runs_per_over[i];
    }
    printf("\nManhattan chart: %s\n", p->team);
    rc = chart_ascii(CHART_BAR, pts, p->overs);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_manhattan_svg(FILE *f, const InningsPlot *p, int mx)
{
    int o, maxo = p->overs > 20 ? p->overs : 20;
    double step = 450.0 / maxo, bw = step * 0.8;

    fputs("<svg class=sv viewBox='0 0 500 232' role=img aria-label='Manhattan chart of runs per over'>"
          "<line class=ax x1=40 y1=200 x2=490 y2=200 /><line class=ax x1=40 y1=20 x2=40 y2=200 />", f);
    fprintf(f, "<text x=36 y=24 text-anchor=end>%d</text>", mx);
    for (o = 0; o < p->overs; o++) {
        double h = p->runs_per_over[o] * 170.0 / mx, x = 40 + o * step;
        const char *c = p->runs_per_over[o] >= 12 ? "#2dd4bf" : p->runs_per_over[o] >= 8 ? "#a78bfa" : "#60a5fa";
        fprintf(f, "<rect x=%g y=%g width=%g height=%g rx=3 fill='%s'/>", x + step * 0.1, 200 - h, bw, h, c);
        if (p->wicket_in_over[o])
            fprintf(f, "<circle cx=%g cy=%g r=7 fill='#ff5d73'/><text class=wk x=%g y=%g>W</text>", x + step / 2, 190 - h, x + step / 2, 193 - h);
        if (o % 5 == 4) fprintf(f, "<text x=%g y=216 text-anchor=middle>%d</text>", x + step / 2, o + 1);
    }
    fputs("<text x=265 y=230 text-anchor=middle>Overs</text></svg>", f);
}


/* ================= SOURCE: component5/sg5_partnership.c ================= */
/* Partnership chart: runs added by each partnership (worked out by the statistics engine). */
void sg5_partnership_show(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_PSHIPS];
    char lab[SG5_MAX_PSHIPS][40];
    int i, rc;

    for (i = 0; i < p->num_partnerships; i++) {
        snprintf(lab[i], sizeof lab[i], "%.14s-%.14s%s", p->pship_bat1[i], p->pship_bat2[i], p->pship_unbeaten[i] ? "*" : "");
        pts[i].label = lab[i];
        pts[i].value = p->pship_runs[i];
    }
    printf("\nPartnerships: %s (* = not out)\n", p->team);
    rc = chart_ascii(CHART_BAR, pts, p->num_partnerships);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_partnership_svg(FILE *f, const InningsPlot *p)
{
    static const char *pal[5] = {"#2dd4bf", "#a78bfa", "#60a5fa", "#fb923c", "#f4d58d"};
    int i, mp = 1;

    for (i = 0; i < p->num_partnerships; i++) if (p->pship_runs[i] > mp) mp = p->pship_runs[i];
    fprintf(f, "<svg class=sv viewBox='0 0 500 %d' role=img aria-label='Partnership runs'>", p->num_partnerships * 24 + 12);
    for (i = 0; i < p->num_partnerships; i++) {
        double w = p->pship_runs[i] * 300.0 / mp;
        fprintf(f, "<text x=0 y=%d>%.12s-%.12s</text><rect x=130 y=%d width=%g height=16 rx=4 fill='%s'/><text x=%g y=%d>%d runs%s</text>",
                22 + i * 24, p->pship_bat1[i], p->pship_bat2[i], 10 + i * 24, w, pal[i % 5], 136 + w, 22 + i * 24,
                p->pship_runs[i], p->pship_unbeaten[i] ? " (not out)" : "");
    }
    fputs("</svg>", f);
}


/* ================= SOURCE: component5/sg5_sample_data.c ================= */
/* Three fictional T20 matches built directly as Component 2 Match structs.
   Used until real scorecard files are loaded. Totals, wickets, overs and fall of wickets all agree. */
#include <stdlib.h>
#include <string.h>
typedef struct {
    int overs, balls;
    int runs[20];      /* runs in each over */
    int wk_over[10];   /* 0-based over of each wicket */
    int n_wk;
    int np;            /* partnerships: wickets, plus one if not out */
    int pr[11];        /* partnership runs (they add up to the total) */
    int pb[11];        /* partnership balls (they add up to the balls bowled) */
} Raw;

static const char *TEAMS[3][2] = {
    {"Sydney Skylarks", "Melbourne Meteors"}, {"Perth Pelicans", "Adelaide Admirals"}, {"Hobart Harriers", "Darwin Dingoes"}};
static const char *ORDER[3][2][11] = {
    {{"Jack", "Oliver", "Lachlan", "Mitchell", "Cooper", "Ryan", "Nathan", "Harry", "Callum", "Riley", "Blake"},
     {"Liam", "Hamish", "Angus", "Bailey", "Tom", "Jordan", "Dylan", "Flynn", "Archie", "Ethan", "Max"}},
    {{"Cameron", "Jake", "Hudson", "Kyle", "Josh", "Zac", "Finn", "Connor", "Ben", "Declan", "Toby"},
     {"Sam", "Aidan", "Brodie", "Chase", "Darcy", "Elliot", "Fraser", "Grant", "Heath", "Isaac", "Jarrod"}},
    {{"Xavier", "Wyatt", "Spencer", "Noah", "Marcus", "Lewis", "Owen", "Patrick", "Quinn", "Reid", "Scott"},
     {"Trent", "Wade", "Alex", "Billy", "Craig", "Damon", "Evan", "Gus", "Hugo", "Ian", "Kane"}}};
static const char *VENUES[3] = {"Harbourside Oval", "Swan River Park", "Derwent Ground"};
static const char *DATES[3] = {"2026-09-05", "2026-09-12", "2026-09-19"};
static const char *IDS[3] = {"SKY-MEL-01", "PER-ADE-02", "HOB-DAR-03"};

static const Raw RAW[3][2] = {
    {{20, 120, {6, 9, 4, 12, 8, 7, 10, 5, 11, 14, 6, 9, 8, 15, 7, 10, 12, 9, 16, 13}, {2, 6, 9, 12, 14, 17}, 6, 7,
      {24, 31, 18, 42, 20, 35, 21}, {14, 20, 11, 25, 15, 20, 15}},
     {20, 120, {5, 8, 11, 6, 9, 12, 7, 10, 4, 13, 8, 6, 9, 11, 5, 8, 12, 6, 9, 7}, {1, 4, 5, 8, 10, 13, 15, 16, 18}, 9, 10,
      {12, 18, 9, 20, 8, 16, 24, 13, 22, 24}, {9, 15, 8, 14, 10, 12, 16, 10, 14, 12}}},
    {{20, 120, {8, 11, 6, 9, 15, 10, 7, 12, 9, 6, 13, 8, 10, 14, 7, 9, 11, 16, 8, 12}, {3, 7, 11, 15, 18}, 5, 6,
      {38, 27, 45, 30, 33, 28}, {24, 18, 26, 16, 20, 16}},
     {17, 102, {9, 12, 8, 14, 10, 17, 6, 11, 13, 9, 15, 12, 8, 16, 10, 14, 18}, {5, 10, 14}, 3, 4,
      {52, 60, 48, 42}, {30, 28, 24, 20}}},
    {{20, 120, {4, 7, 5, 9, 6, 8, 3, 10, 7, 5, 9, 6, 8, 11, 4, 7, 9, 6, 10, 8}, {2, 4, 7, 9, 11, 13, 14, 16, 18, 19}, 10, 10,
      {12, 15, 8, 20, 10, 14, 11, 17, 13, 22}, {12, 14, 10, 16, 12, 14, 10, 12, 10, 10}},
     {20, 120, {6, 9, 7, 5, 10, 8, 6, 11, 7, 9, 5, 8, 10, 6, 9, 7, 8, 4, 3, 0}, {3, 6, 9, 12, 15, 17, 18, 19}, 8, 9,
      {15, 12, 18, 10, 20, 13, 16, 14, 20}, {13, 12, 16, 10, 18, 12, 14, 13, 12}}}};

static int build_innings(Innings *in, int m, int i)
{
    const Raw *r = &RAW[m][i];
    int k, j, w, total = 0, run = 0;

    memset(in, 0, sizeof *in);
    snprintf(in->batting_team, NAME_LEN, "%s", TEAMS[m][i]);
    in->wickets = r->n_wk;
    in->legal_balls = r->balls;
    in->batter_count = (size_t)r->np + 1;
    in->bowler_count = 5;
    in->over_count = (size_t)r->overs;
    in->fow_count = (size_t)r->n_wk;
    in->batters = (Player *)calloc(in->batter_count, sizeof(Player));
    in->bowlers = (Player *)calloc(in->bowler_count, sizeof(Player));
    in->overs = (Over *)calloc(in->over_count, sizeof(Over));
    in->fow = (FallOfWicket *)calloc(in->fow_count > 0 ? in->fow_count : 1, sizeof(FallOfWicket));
    if (!in->batters || !in->bowlers || !in->overs || !in->fow) return 0;

    for (k = 0; k <= r->np; k++) snprintf(in->batters[k].name, NAME_LEN, "%s", ORDER[m][i][k]);
    for (k = 0; k < r->np; k++) {   /* each partnership is shared between its two batters */
        int a = (r->pr[k] + 1) / 2, ab = (r->pb[k] + 1) / 2;
        in->batters[k].runs += a;               in->batters[k + 1].runs += r->pr[k] - a;
        in->batters[k].balls_faced += ab;       in->batters[k + 1].balls_faced += r->pb[k] - ab;
    }
    for (k = 0; k <= r->np; k++) {
        in->batters[k].fours = in->batters[k].runs / 8;
        in->batters[k].sixes = in->batters[k].runs / 20;
    }
    for (j = 0; j < 5; j++) snprintf(in->bowlers[j].name, NAME_LEN, "%s", ORDER[m][1 - i][6 + j]);
    for (k = 0; k < r->overs; k++) {
        w = 0;
        for (j = 0; j < r->n_wk; j++) if (r->wk_over[j] == k) w++;
        in->overs[k].over_number = k + 1;
        in->overs[k].runs = r->runs[k];
        in->overs[k].wickets = w;
        total += r->runs[k];
        in->bowlers[k % 5].balls_bowled += 6;
        in->bowlers[k % 5].runs_conceded += r->runs[k];
        in->bowlers[k % 5].wickets += w;
    }
    in->total_runs = total;
    for (k = 0; k < r->n_wk; k++) {
        run += r->pr[k];
        in->fow[k].wicket_number = k + 1;
        in->fow[k].team_score = run;
        in->fow[k].over_number = r->wk_over[k] + 1;
        in->fow[k].ball_in_over = 3;
        snprintf(in->fow[k].player_out, NAME_LEN, "%s", ORDER[m][i][k]);
    }
    return 1;
}

int sg5_sample_matches(MatchStore *store)
{
    int m, i, ok;
    Match mt;

    for (m = 0; m < 3; m++) {
        memset(&mt, 0, sizeof mt);
        snprintf(mt.match_id, MATCH_ID_LEN, "%s", IDS[m]);
        snprintf(mt.team1, NAME_LEN, "%s", TEAMS[m][0]);
        snprintf(mt.team2, NAME_LEN, "%s", TEAMS[m][1]);
        snprintf(mt.venue, VENUE_LEN, "%s", VENUES[m]);
        snprintf(mt.date, DATE_LEN, "%s", DATES[m]);
        ok = 1;
        for (i = 0; i < 2 && ok; i++) ok = build_innings(&mt.innings[i], m, i);
        ok = ok && store_add_match(store, &mt);
        match_free(&mt);
        if (!ok) return 0;
    }
    return 1;
}


/* ================= SOURCE: component5/sg5_worm.c ================= */
/* Worm chart: cumulative runs after each over, both innings. */
static void series(const InningsPlot *p)
{
    DataPoint pts[SG5_MAX_OVERS];
    char lab[SG5_MAX_OVERS][12];
    int i, rc;

    for (i = 0; i < p->overs; i++) {
        snprintf(lab[i], sizeof lab[i], "%d", i + 1);
        pts[i].label = lab[i];
        pts[i].value = p->cumulative_runs[i];
    }
    printf("\nWorm chart: %s (runs after each over)\n", p->team);
    rc = chart_ascii(CHART_LINE, pts, p->overs);
    if (rc != CHART_OK) printf("%s\n", chart_error_message(rc));
}

void sg5_worm_show(const Sg5Match *m)
{
    series(&m->in[0]);
    series(&m->in[1]);
}

void sg5_worm_svg(FILE *f, const Sg5Match *m)
{
    static const char *col[2] = {"#ff5d73", "#2dd4bf"};
    int i, o, mx = 1, maxo = 20;
    double step;

    for (i = 0; i < 2; i++) {
        if (m->in[i].total_runs > mx) mx = m->in[i].total_runs;
        if (m->in[i].overs > maxo) maxo = m->in[i].overs;
    }
    step = 450.0 / maxo;
    fputs("<svg class=sv viewBox='0 0 500 240' role=img aria-label='Worm chart of cumulative runs per over'>"
          "<line class=ax x1=40 y1=200 x2=490 y2=200 /><line class=ax x1=40 y1=20 x2=40 y2=200 />", f);
    for (o = 0; o <= maxo; o += 5) fprintf(f, "<text x=%g y=216 text-anchor=middle>%d</text>", 40 + o * step, o);
    fprintf(f, "<text x=265 y=233 text-anchor=middle>Overs</text><text x=36 y=24 text-anchor=end>%d</text>", mx);
    for (i = 0; i < 2; i++) {
        const InningsPlot *p = &m->in[i];
        fprintf(f, "<polygon fill='%s' fill-opacity=.12 points='40,200", col[i]);
        for (o = 0; o < p->overs; o++) fprintf(f, " %g,%g", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx);
        fprintf(f, " %g,200'/><polyline fill=none stroke='%s' stroke-width=3 stroke-linejoin=round points='40,200", 40 + p->overs * step, col[i]);
        for (o = 0; o < p->overs; o++) fprintf(f, " %g,%g", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx);
        fputs("'/>", f);
        for (o = 0; o < p->overs; o++)
            if (p->wicket_in_over[o])
                fprintf(f, "<circle cx=%g cy=%g r=4.5 fill='#fff' stroke='%s' stroke-width=2/>", 40 + (o + 1) * step, 200 - p->cumulative_runs[o] * 180.0 / mx, col[i]);
    }
    fprintf(f, "<text x=50 y=12 style='fill:%s'>%s</text><text x=270 y=12 style='fill:%s'>%s</text></svg>", col[0], m->in[0].team, col[1], m->in[1].team);
}


/* ================= SOURCE: component5/sg5_menu.c ================= */
/* Terminal menu with safe input (fgets + strtol). */
#include <stdlib.h>
#include <string.h>
static int read_int(const char *prompt, int lo, int hi)
{
    char buf[64], *end;
    long v;

    for (;;) {
        printf("%s", prompt);
        if (fgets(buf, sizeof buf, stdin) == NULL) return lo;
        v = strtol(buf, &end, 10);
        if (end != buf && (*end == '\n' || *end == '\0') && v >= lo && v <= hi) return (int)v;
        printf("Please enter a number from %d to %d.\n", lo, hi);
    }
}

void sg5_menu_run(void)
{
    Sg5Match m;
    char path[200], err[200], title[140];
    int sel = 0, c, i;

    if (sg5_load_match(sel, &m) != 0) {
        printf("No match data available.\n");
        return;
    }
    for (;;) {
        printf("\n=== CricLens ===  Current: %s\n", m.info.title);
        printf("1 Choose match   2 Worm chart   3 Manhattan (1st)   4 Manhattan (2nd)\n");
        printf("5 Partnerships (1st)   6 Partnerships (2nd)   7 Awards   8 Load a scorecard file   0 Exit\n");
        c = read_int("Choice: ", 0, 8);
        switch (c) {
        case 1:
            for (i = 0; i < sg5_match_count(); i++) {
                sg5_match_title(i, title, sizeof title);
                printf("  %d. %s\n", i + 1, title);
            }
            sel = read_int("Match number: ", 1, sg5_match_count()) - 1;
            if (sg5_load_match(sel, &m) != 0) printf("Could not load that match.\n");
            else printf("%s\n", m.result);
            break;
        case 2: sg5_worm_show(&m); break;
        case 3: sg5_manhattan_show(&m.in[0]); break;
        case 4: sg5_manhattan_show(&m.in[1]); break;
        case 5: sg5_partnership_show(&m.in[0]); break;
        case 6: sg5_partnership_show(&m.in[1]); break;
        case 7: sg5_awards_show(&m); break;
        case 8:
            printf("Scorecard file path: ");
            if (fgets(path, sizeof path, stdin) != NULL) {
                path[strcspn(path, "\r\n")] = '\0';
                if (sg5_add_from_file(path, err, sizeof err)) {
                    sel = sg5_match_count() - 1;
                    if (sg5_load_match(sel, &m) == 0) printf("Loaded. %s\n", m.result);
                } else {
                    printf("Could not load the file: %s\n", err);
                }
            }
            break;
        default: return;
        }
    }
}


/* ================= SOURCE: component5/desktop_shell_win32.c ================= */
/* CricLens desktop shell helpers -- plain C using the Win32 / COM shell APIs. */
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef _WIN32_IE
#define _WIN32_IE 0x0700
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/* ---------------------------------------------------------------- icon art */

typedef struct { double r, g, b, a; } Px;

static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double mixd(double a, double b, double t) { return a + (b - a) * t; }

/* One sample of the icon artwork at (u,v) in [0,1]^2:
 * a navy rounded tile with a gold border, a glowing gold ring and a red cricket ball with seam stitching. */
static Px icon_sample(double u, double v)
{
    Px o = {0, 0, 0, 0};
    const double corner = 0.20, R = 0.255;
    double px = fabs(u - 0.5) - (0.5 - corner), py = fabs(v - 0.5) - (0.5 - corner);
    double ox = px > 0 ? px : 0, oy = py > 0 ? py : 0;
    double inner = px > py ? px : py;
    double d, r, g, b, dx, dy, rr, glow;

    if (inner > 0) inner = 0;
    d = sqrt(ox * ox + oy * oy) + inner - corner;
    if (d > 0) return o;                                   /* outside the rounded tile */

    r = mixd(10, 30, v); g = mixd(18, 36, v); b = mixd(52, 88, v);
    dx = u - 0.5; dy = v - 0.5; rr = sqrt(dx * dx + dy * dy);
    glow = exp(-pow((rr - 0.28) / 0.09, 2.0)) * 0.22;
    r = mixd(r, 246, glow); g = mixd(g, 196, glow); b = mixd(b, 83, glow);

    if (d > -0.038) {                                      /* gold border */
        r = mixd(255, 196, v); g = mixd(214, 142, v); b = mixd(110, 40, v);
    } else if (rr < R) {                                   /* the ball */
        double hx = dx + 0.35 * R, hy = dy + 0.40 * R;
        double h = clampd(sqrt(hx * hx + hy * hy) / (1.6 * R), 0, 1);
        double shade = 1.0 - 0.30 * pow(rr / R, 3.0);
        double ca = cos(0.61), sa = sin(0.61);
        double u2 = dx * ca + dy * sa, v2 = -dx * sa + dy * ca;
        double minor = 0.46 * R;
        double f = sqrt((u2 / R) * (u2 / R) + (v2 / minor) * (v2 / minor));
        double sd = (f - 1.0) * minor;
        double th = atan2(v2 / 0.46, u2);
        r = mixd(255, 196, h) * shade; g = mixd(120, 22, h) * shade; b = mixd(140, 52, h) * shade;
        if (fabs(sd) < 0.007) { r = 140; g = 12; b = 38; }                         /* raised seam */
        else if ((fabs(sd - 0.021) < 0.0055 || fabs(sd + 0.021) < 0.0055) && sin(th * 30.0) > 0.0) {
            r = 246; g = 236; b = 214;                                             /* stitches */
        }
    } else if (rr > R + 0.016 && rr < R + 0.032) {          /* gold ring */
        r = mixd(r, 246, 0.9); g = mixd(g, 196, 0.9); b = mixd(b, 83, 0.9);
    }
    o.r = clampd(r, 0, 255); o.g = clampd(g, 0, 255); o.b = clampd(b, 0, 255); o.a = 1.0;
    return o;
}

void cl_render_icon(unsigned char *bgra, int size)
{
    const int N = 3;
    int x, y, sx, sy;
    for (y = 0; y < size; y++) {
        for (x = 0; x < size; x++) {
            double ar = 0, ag = 0, ab = 0, aa = 0;
            unsigned char *o = bgra + ((size_t)y * (size_t)size + (size_t)x) * 4;
            for (sy = 0; sy < N; sy++) {
                for (sx = 0; sx < N; sx++) {
                    Px p = icon_sample((x + (sx + 0.5) / N) / size, (y + (sy + 0.5) / N) / size);
                    ar += p.r * p.a; ag += p.g * p.a; ab += p.b * p.a; aa += p.a;
                }
            }
            if (aa <= 0) { o[0] = o[1] = o[2] = o[3] = 0; }
            else {
                o[0] = (unsigned char)(ab / aa + 0.5);
                o[1] = (unsigned char)(ag / aa + 0.5);
                o[2] = (unsigned char)(ar / aa + 0.5);
                o[3] = (unsigned char)(255.0 * aa / (N * N) + 0.5);
            }
        }
    }
}

void cl_flatten_icon(unsigned char *p, int size, COLORREF bg)
{
    int i, n = size * size, br = GetRValue(bg), bgc = GetGValue(bg), bb = GetBValue(bg);
    for (i = 0; i < n; i++, p += 4) {
        int a = p[3];
        p[0] = (unsigned char)((p[0] * a + bb * (255 - a)) / 255);
        p[1] = (unsigned char)((p[1] * a + bgc * (255 - a)) / 255);
        p[2] = (unsigned char)((p[2] * a + br * (255 - a)) / 255);
        p[3] = 255;
    }
}

HICON cl_make_hicon(int size)
{
    BITMAPINFO bi;
    void *bits = NULL;
    HDC dc;
    HBITMAP color, mask;
    ICONINFO ii;
    HICON icon;
    size_t stride = (size_t)((size + 15) / 16) * 2;
    unsigned char *mbits;

    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = size;
    bi.bmiHeader.biHeight = -size;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    dc = GetDC(NULL);
    color = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, NULL, 0);
    ReleaseDC(NULL, dc);
    if (!color || !bits) { if (color) DeleteObject(color); return NULL; }
    cl_render_icon((unsigned char *)bits, size);
    mbits = (unsigned char *)calloc(stride * (size_t)size, 1);
    mask = CreateBitmap(size, size, 1, 1, mbits);
    free(mbits);
    ii.fIcon = TRUE; ii.xHotspot = 0; ii.yHotspot = 0; ii.hbmMask = mask; ii.hbmColor = color;
    icon = CreateIconIndirect(&ii);
    DeleteObject(color);
    DeleteObject(mask);
    return icon;
}

/* ------------------------------------------------------------- .ico writer */

static void put16(unsigned char *p, unsigned v) { p[0] = (unsigned char)(v & 255); p[1] = (unsigned char)((v >> 8) & 255); }
static void put32(unsigned char *p, unsigned long v)
{
    p[0] = (unsigned char)(v & 255); p[1] = (unsigned char)((v >> 8) & 255);
    p[2] = (unsigned char)((v >> 16) & 255); p[3] = (unsigned char)((v >> 24) & 255);
}

int cl_write_ico_file(const char *path)
{
    static const int sizes[7] = {16, 24, 32, 48, 64, 128, 256};
    const int n = 7;
    size_t img[7], total = 6 + 16 * (size_t)n, off, i;
    unsigned char *buf, *tmp;
    FILE *f;
    int ok;

    for (i = 0; i < (size_t)n; i++) {
        size_t s = (size_t)sizes[i], and_stride = ((s + 31) / 32) * 4;
        img[i] = 40 + s * s * 4 + and_stride * s;
        total += img[i];
    }
    buf = (unsigned char *)calloc(total, 1);
    if (!buf) return 0;
    put16(buf, 0); put16(buf + 2, 1); put16(buf + 4, (unsigned)n);
    off = 6 + 16 * (size_t)n;
    for (i = 0; i < (size_t)n; i++) {
        int s = sizes[i], y;
        size_t and_stride = (((size_t)s + 31) / 32) * 4;
        unsigned char *e = buf + 6 + 16 * i, *im = buf + off;
        e[0] = (unsigned char)(s >= 256 ? 0 : s); e[1] = e[0]; e[2] = 0; e[3] = 0;
        put16(e + 4, 1); put16(e + 6, 32); put32(e + 8, (unsigned long)img[i]); put32(e + 12, (unsigned long)off);
        put32(im, 40); put32(im + 4, (unsigned long)s); put32(im + 8, (unsigned long)s * 2);
        put16(im + 12, 1); put16(im + 14, 32); put32(im + 16, 0);
        put32(im + 20, (unsigned long)((size_t)s * (size_t)s * 4 + and_stride * (size_t)s));
        tmp = (unsigned char *)malloc((size_t)s * (size_t)s * 4);
        if (!tmp) { free(buf); return 0; }
        cl_render_icon(tmp, s);
        for (y = 0; y < s; y++)                          /* ICO pixel rows are stored bottom-up */
            memcpy(im + 40 + (size_t)(s - 1 - y) * (size_t)s * 4, tmp + (size_t)y * (size_t)s * 4, (size_t)s * 4);
        free(tmp);
        off += img[i];
    }
    f = fopen(path, "wb");
    ok = f && fwrite(buf, 1, total, f) == total;
    if (f) fclose(f);
    free(buf);
    return ok;
}

/* --------------------------------------------------------------- shortcuts */

static int make_link(const char *lnk, const char *exe, const char *dir, const char *icon)
{
    IShellLinkA *sl = NULL;
    IPersistFile *pf = NULL;
    WCHAR wide[MAX_PATH];
    int ok = 0;

    if (FAILED(CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLinkA, (void **)&sl)) || !sl)
        return 0;
    sl->lpVtbl->SetPath(sl, exe);
    sl->lpVtbl->SetWorkingDirectory(sl, dir);
    sl->lpVtbl->SetDescription(sl, "CricLens - Cricket Analytics Desktop");
    sl->lpVtbl->SetIconLocation(sl, icon, 0);
    if (SUCCEEDED(sl->lpVtbl->QueryInterface(sl, &IID_IPersistFile, (void **)&pf)) && pf) {
        MultiByteToWideChar(CP_ACP, 0, lnk, -1, wide, MAX_PATH);
        ok = SUCCEEDED(pf->lpVtbl->Save(pf, wide, TRUE));
        pf->lpVtbl->Release(pf);
    }
    sl->lpVtbl->Release(sl);
    return ok;
}

int cl_install_shortcuts(char *msg, size_t msg_size)
{
    char exe[MAX_PATH], dir[MAX_PATH], ico[MAX_PATH + 16], folder[MAX_PATH], lnk[MAX_PATH + 16];
    char *slash;
    int made = 0, have_ico, desktop_ok = 0, start_ok = 0;
    HRESULT hr;

    GetModuleFileNameA(NULL, exe, MAX_PATH);
    strncpy(dir, exe, MAX_PATH - 1); dir[MAX_PATH - 1] = 0;
    slash = strrchr(dir, '\\');
    if (slash) *slash = 0;
    snprintf(ico, sizeof ico, "%s\\CricLens.ico", dir);
    have_ico = cl_write_ico_file(ico);

    hr = CoInitialize(NULL);
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_DESKTOPDIRECTORY, NULL, 0, folder))) {
        snprintf(lnk, sizeof lnk, "%s\\CricLens.lnk", folder);
        desktop_ok = make_link(lnk, exe, dir, have_ico ? ico : exe);
    }
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_PROGRAMS, NULL, 0, folder))) {
        snprintf(lnk, sizeof lnk, "%s\\CricLens.lnk", folder);
        start_ok = make_link(lnk, exe, dir, have_ico ? ico : exe);
    }
    if (SUCCEEDED(hr)) CoUninitialize();
    made = desktop_ok + start_ok;

    if (msg && msg_size) {
        if (made == 2) snprintf(msg, msg_size, "CricLens shortcuts created on your Desktop and in the Start Menu.");
        else if (desktop_ok) snprintf(msg, msg_size, "CricLens shortcut created on your Desktop.");
        else if (start_ok) snprintf(msg, msg_size, "CricLens shortcut created in the Start Menu.");
        else snprintf(msg, msg_size, "Could not create the shortcuts. You can create one manually from CricLens.exe.");
    }
    return made;
}

/* ------------------------------------------------------- window appearance */

void cl_apply_titlebar(HWND hwnd, int dark)
{
    typedef HRESULT (WINAPI *DwmSetFn)(HWND, DWORD, LPCVOID, DWORD);
    HMODULE dwm = LoadLibraryA("dwmapi.dll");
    DwmSetFn fn;
    if (!dwm) return;
    fn = (DwmSetFn)(void *)GetProcAddress(dwm, "DwmSetWindowAttribute");
    if (fn) {
        BOOL d = dark ? TRUE : FALSE;
        COLORREF caption = dark ? RGB(18, 26, 46) : RGB(255, 255, 255);
        COLORREF text = dark ? RGB(232, 236, 246) : RGB(15, 23, 42);
        fn(hwnd, 20, &d, sizeof d);                /* DWMWA_USE_IMMERSIVE_DARK_MODE */
        fn(hwnd, 35, &caption, sizeof caption);    /* DWMWA_CAPTION_COLOR (Windows 11) */
        fn(hwnd, 36, &text, sizeof text);          /* DWMWA_TEXT_COLOR (Windows 11) */
    }
    FreeLibrary(dwm);
}

void cl_enable_dpi_awareness(void)
{
    typedef BOOL (WINAPI *DpiFn)(void);
    HMODULE u = GetModuleHandleA("user32.dll");
    DpiFn fn = u ? (DpiFn)(void *)GetProcAddress(u, "SetProcessDPIAware") : NULL;
    if (fn) fn();
}


/* ================= SOURCE: component5/desktop_gui_win32.c ================= */
/* CricLens native Windows desktop GUI -- plain C, Win32 API + GDI only.
 *
 * A light "analytics dashboard" interface with a dark-mode toggle:
 *   - top bar with match selector, engine badge, dark/light switch and scorecard upload dialog
 *   - match summary card (animated scores, run rates, result banner, Man of the Match)
 *   - chart card: worm, Manhattan x2, partnerships x2 and run-rate charts with hover tooltips,
 *     SVG export (Component 5 renderers) and 24-bit BMP export
 *   - "Scorecard & Metrics" card: batting and bowling tables, fall of wickets, awards, MVP ranking
 *   - smooth animations everywhere (tab pills, count-ups, chart reveals, row fades, modal, toasts)
 *   - double-buffered, DPI-aware, resizable, scrollable; runtime-generated icon and shortcuts
 * Data comes from Components 1-5 through the Component 5 adapter (sg5_*).
 */
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define PI 3.14159265358979323846
#define SSC 2                 /* supersampling factor for chart plots */
#define SPLASH_MS 2000
#define ANIM_MS 1100
#define NCTAB 6
#define NRTAB 3
#define MAX_TITLES 12
#define WM_CL_LOAD  (WM_APP + 1)
#define WM_CL_CLOSE (WM_APP + 2)

/* ------------------------------------------------------------------- theme */
enum { K_BG, K_CARD, K_CARD2, K_BORDER, K_TEXT, K_MUTED, K_FAINT, K_ACCENT, K_ACCENT_H, K_ONACC, K_T1, K_T2,
       K_BANNER, K_THEAD, K_GRID, K_HOVER, K_GREEN, K_GREENBG, K_GREENFG, K_RED, K_REDBG, K_SCRIM, K_TIP, K_GOLD, K_COUNT };
static const COLORREF TH_LIGHT[K_COUNT] = {
    RGB(244, 246, 250), RGB(255, 255, 255), RGB(249, 250, 252), RGB(226, 231, 240), RGB(15, 23, 42), RGB(100, 116, 139),
    RGB(148, 163, 184), RGB(30, 58, 95), RGB(44, 78, 124), RGB(255, 255, 255), RGB(36, 84, 166), RGB(185, 28, 38),
    RGB(234, 242, 255), RGB(241, 245, 249), RGB(226, 231, 240), RGB(244, 247, 252), RGB(34, 197, 94), RGB(220, 252, 231),
    RGB(21, 128, 61), RGB(185, 28, 28), RGB(254, 226, 226), RGB(15, 23, 42), RGB(15, 23, 42), RGB(217, 154, 20)};
static const COLORREF TH_DARK[K_COUNT] = {
    RGB(10, 15, 30), RGB(18, 26, 46), RGB(22, 31, 54), RGB(40, 52, 84), RGB(232, 236, 246), RGB(140, 152, 180),
    RGB(96, 108, 140), RGB(59, 110, 200), RGB(80, 130, 222), RGB(255, 255, 255), RGB(96, 165, 250), RGB(248, 113, 113),
    RGB(22, 35, 68), RGB(26, 36, 62), RGB(38, 50, 82), RGB(28, 39, 70), RGB(52, 211, 120), RGB(20, 60, 40),
    RGB(110, 231, 160), RGB(252, 165, 165), RGB(70, 28, 34), RGB(0, 0, 0), RGB(40, 52, 92), RGB(246, 196, 83)};
static COLORREF TC[K_COUNT];
#define C(k) TC[k]

/* --------------------------------------------------------- ids and targets */
typedef enum { VIEW_WORM, VIEW_MAN1, VIEW_MAN2, VIEW_PS1, VIEW_PS2, VIEW_RR, VIEW_COUNT } View;
enum { ID_NONE = 0, ID_DARK, ID_UPLOAD, ID_MATCHSEL, ID_ERRCLOSE, ID_DL_SVG, ID_DL_BMP, ID_ABOUT,
       ID_CTAB = 10, ID_RTAB = 20, ID_MITEM = 24, ID_M_BACK = 40, ID_M_PANEL, ID_M_CLOSE, ID_M_CHOOSE, ID_M_CANCEL, ID_M_LOAD, ID_MAX };
typedef struct { RECT r; int id; } Target;
static Target g_tg[160];
static int g_ntg, g_oy, g_clip_on;
static RECT g_clipwin;
static int g_hot_id, g_down_id;
static double g_hv[ID_MAX];

typedef struct { int pad, top_h, stat_h, view_h, cw, mc_y, mc_h, pn_y, pn_h, lw, rx, rw, total; } Lay;
typedef struct { int bx0, by0, bx1, by1, px0, py0, px1, py1, n, ymax, ystep; } Geo;
typedef struct { int n; char text[4][170]; COLORREF col[4]; } Tip;

/* ------------------------------------------------------------------- state */
static HWND g_hwnd, g_edit;
static WNDPROC g_edit_old;
static HBRUSH g_edit_brush;
static COLORREF g_edit_brush_col = 0xFFFFFFFF;
static HDC g_mem;
static HBITMAP g_membmp;
static HGDIOBJ g_memold;
static int g_w, g_h, g_full;
static double g_s = 1.0, g_dt = 0.016;
static WINDOWPLACEMENT g_wp;

static HFONT f_cap, f_capb, f_body, f_semi, f_bold, f_h1, f_h2, f_h3, f_score, f_mid, f_mono, f_rot;
static HICON g_icon_big, g_icon_small;
static unsigned char *g_logo_splash;

static Sg5Match g_match;
static Sg5Card g_card[2];
static Sg5MvpRow g_mvp[8];
static int g_nmvp, g_match_index, g_match_gen;
static View g_view = VIEW_WORM;
static int g_rtab;                         /* 0 = 1st innings, 1 = 2nd innings, 2 = awards */
static DWORD g_t_start, g_t_match, g_t_chart, g_t_rtab, g_t_enter, g_t_last;
static int g_splash = 1, g_tracking, g_busy, g_idle;
static int g_mx = -1, g_my = -1, g_cmx, g_cmy, g_hover_content;

static double g_theme_t, g_theme_goal;
static double g_scroll, g_scroll_goal, g_scroll_max;
static double g_rs, g_rs_goal, g_rs_max;
static RECT g_rs_rect;
static int g_rs_content;
static double g_ct_l, g_ct_r, g_rt_l, g_rt_r;
static int g_ct_init, g_rt_init;

static HBITMAP g_plot;
static int g_plot_w, g_plot_h, g_plot_valid, g_plot_key;
static RECT g_chart_win;

static Tip g_tip;
static char g_err[260], g_toast[200], g_pick[MAX_PATH];
static DWORD g_err_t, g_toast_t;
static int g_modal, g_dd_open, g_ntitles;
static double g_mod_a, g_dd_a;
static char g_titles[MAX_TITLES][130];

static HDC g_pxdc;
static HBITMAP g_pxbmp;
static HGDIOBJ g_pxold;

/* ----------------------------------------------------------------- helpers */
static int U(double v) { return (int)(v * g_s + 0.5); }
static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double ease_out(double t) { t = 1.0 - clampd(t, 0, 1); return 1.0 - t * t * t; }
static double ease_io(double t) { t = clampd(t, 0, 1); return t * t * (3.0 - 2.0 * t); }
static double ease_back(double t)
{
    const double c1 = 1.70158, c3 = c1 + 1.0;
    t = clampd(t, 0, 1) - 1.0;
    return 1.0 + c3 * t * t * t + c1 * t * t;
}
static COLORREF lerp_col(COLORREF a, COLORREF b, double t)
{
    t = clampd(t, 0, 1);
    return RGB((int)(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t + 0.5),
               (int)(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t + 0.5),
               (int)(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t + 0.5));
}
static COLORREF lighten(COLORREF c, double t) { return lerp_col(c, RGB(255, 255, 255), t); }
static COLORREF fade(COLORREF c, double t) { return lerp_col(C(K_CARD), c, t); }
static double since(DWORD t0) { return (double)(GetTickCount() - t0); }
static double prog_of(DWORD t0, double ms, double delay)
{
    double t = (since(t0) - delay) / ms;
    if (t < 1.0) g_busy = 1;
    return ease_out(t);
}
static void slide(double *cur, double tgt)
{
    double d = tgt - *cur;
    if (fabs(d) < 0.5) { *cur = tgt; return; }
    *cur += d * (1.0 - exp(-g_dt * 22.0));
    g_busy = 1;
}
static void theme_update(void)
{
    int k;
    double e = ease_io(g_theme_t);
    for (k = 0; k < K_COUNT; k++) TC[k] = lerp_col(TH_LIGHT[k], TH_DARK[k], e);
}
static void toast(const char *s) { snprintf(g_toast, sizeof g_toast, "%s", s); g_toast_t = GetTickCount(); }
static void set_error(const char *s) { snprintf(g_err, sizeof g_err, "%s", s); g_err_t = GetTickCount(); }

static HFONT mkfont(int px, int weight, const char *face, int rot)
{
    return CreateFontA(-px, 0, rot, rot, weight, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                       OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
}
static void kill_font(HFONT *f) { if (*f) { DeleteObject(*f); *f = NULL; } }
static void kill_all_fonts(void)
{
    kill_font(&f_cap); kill_font(&f_capb); kill_font(&f_body); kill_font(&f_semi); kill_font(&f_bold); kill_font(&f_h1);
    kill_font(&f_h2); kill_font(&f_h3); kill_font(&f_score); kill_font(&f_mid); kill_font(&f_mono); kill_font(&f_rot);
}
static void make_fonts(void)
{
    kill_all_fonts();
    f_cap = mkfont(U(12), FW_NORMAL, "Segoe UI", 0);
    f_capb = mkfont(U(11), FW_BOLD, "Segoe UI", 0);
    f_body = mkfont(U(14), FW_NORMAL, "Segoe UI", 0);
    f_semi = mkfont(U(14), FW_SEMIBOLD, "Segoe UI", 0);
    f_bold = mkfont(U(14), FW_BOLD, "Segoe UI", 0);
    f_h1 = mkfont(U(21), FW_BOLD, "Segoe UI", 0);
    f_h2 = mkfont(U(18), FW_BOLD, "Segoe UI", 0);
    f_h3 = mkfont(U(17), FW_BOLD, "Segoe UI", 0);
    f_score = mkfont(U(46), FW_BOLD, "Segoe UI", 0);
    f_mid = mkfont(U(24), FW_BOLD, "Segoe UI", 0);
    f_mono = mkfont(U(13), FW_NORMAL, "Consolas", 0);
    f_rot = mkfont(U(12), FW_NORMAL, "Segoe UI", 900);
}

/* ------------------------------------------------------ drawing primitives */
static void fill(HDC dc, int l, int t, int r, int b, COLORREF c)
{
    RECT rc;
    rc.left = l; rc.top = t; rc.right = r; rc.bottom = b;
    SetBkColor(dc, c);
    ExtTextOutA(dc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
}
static void vgrad(HDC dc, int l, int t, int r, int b, COLORREF c1, COLORREF c2)
{
    int i, h = b - t;
    if (h <= 0) return;
    for (i = 0; i < h; i++) fill(dc, l, t + i, r, t + i + 1, lerp_col(c1, c2, h > 1 ? (double)i / (h - 1) : 0.0));
}
static void alpha_rect(HDC dc, int l, int t, int r, int b, COLORREF c, int a)
{
    BLENDFUNCTION bf;
    if (r <= l || b <= t || a <= 0) return;
    if (!g_pxdc) {
        HDC s = GetDC(NULL);
        g_pxdc = CreateCompatibleDC(s);
        g_pxbmp = CreateCompatibleBitmap(s, 1, 1);
        g_pxold = SelectObject(g_pxdc, g_pxbmp);
        ReleaseDC(NULL, s);
    }
    SetPixelV(g_pxdc, 0, 0, c);
    bf.BlendOp = AC_SRC_OVER; bf.BlendFlags = 0; bf.SourceConstantAlpha = (BYTE)(a > 255 ? 255 : a); bf.AlphaFormat = 0;
    AlphaBlend(dc, l, t, r - l, b - t, g_pxdc, 0, 0, 1, 1, bf);
}
static void line_(HDC dc, int x1, int y1, int x2, int y2, COLORREF c, int w, int style)
{
    HPEN p = CreatePen(style, w, c), old = (HPEN)SelectObject(dc, p);
    SetBkMode(dc, TRANSPARENT);
    MoveToEx(dc, x1, y1, NULL); LineTo(dc, x2, y2);
    SelectObject(dc, old); DeleteObject(p);
}
static void rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void outline_rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF edge, int ew, int style)
{
    HPEN pen;
    HGDIOBJ ob, op;
    pen = CreatePen(style, ew, edge);
    SetBkMode(dc, TRANSPARENT);
    ob = SelectObject(dc, GetStockObject(NULL_BRUSH)); op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
static void circle(HDC dc, int cx, int cy, int r, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void ring(HDC dc, int cx, int cy, int r, COLORREF edge, int ew)
{
    HPEN pen = CreatePen(PS_SOLID, ew, edge);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH)), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
static void poly(HDC dc, const POINT *pts, int n, COLORREF fillc, COLORREF edge)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = CreatePen(PS_SOLID, 1, edge);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Polygon(dc, pts, n);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(br); DeleteObject(pen);
}
/* Rounded clip that works with the content viewport offset (clip regions use device coordinates). */
static void clip_rrect(HDC dc, int l, int t, int r, int b, int rad)
{
    HRGN rg = CreateRoundRectRgn(l, t + g_oy, r + 2, b + 2 + g_oy, rad, rad);
    ExtSelectClipRgn(dc, rg, RGN_AND);
    DeleteObject(rg);
}
static void shadow(HDC dc, int l, int t, int r, int b, int rad, int a)
{
    int i;
    for (i = 3; i >= 1; i--) {
        int e = U(i * 2), sv = SaveDC(dc);
        clip_rrect(dc, l - e, t - e + U(3), r + e, b + e + U(3), rad + e * 2);
        alpha_rect(dc, l - e, t - e + U(3), r + e + 1, b + e + U(4), C(K_SCRIM), a);
        RestoreDC(dc, sv);
    }
}
static void card(HDC dc, int l, int t, int r, int b, int rad)
{
    shadow(dc, l, t, r, b, rad, 5);
    rrect(dc, l, t, r, b, rad, C(K_CARD), C(K_BORDER), 1);
}
/* Text anchored at x, vertically centred on yc. align: 0 left, 1 centre, 2 right. */
static void txtc(HDC dc, int x, int yc, const char *s, COLORREF c, HFONT f, int align)
{
    RECT r;
    UINT fm = DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP;
    r.top = yc - U(40); r.bottom = yc + U(40);
    if (align == 1) { r.left = x - 4000; r.right = x + 4000; fm |= DT_CENTER; }
    else if (align == 2) { r.left = x - 8000; r.right = x; fm |= DT_RIGHT; }
    else { r.left = x; r.right = x + 8000; fm |= DT_LEFT; }
    SelectObject(dc, f); SetBkMode(dc, TRANSPARENT); SetTextColor(dc, c);
    DrawTextA(dc, s, -1, &r, fm);
}
static int tw(HDC dc, HFONT f, const char *s)
{
    SIZE z;
    SelectObject(dc, f);
    GetTextExtentPoint32A(dc, s, (int)strlen(s), &z);
    return z.cx;
}
static void fit(HDC dc, HFONT f, const char *s, int maxw, char *out, size_t n)
{
    size_t len;
    char t[200];
    snprintf(out, n, "%s", s);
    if (tw(dc, f, out) <= maxw) return;
    len = strlen(out);
    while (len > 1) {
        out[--len] = 0;
        snprintf(t, sizeof t, "%s...", out);
        if (tw(dc, f, t) <= maxw) { snprintf(out, n, "%s", t); return; }
    }
}
static void blit_rgba(HDC dc, const unsigned char *buf, int src, int x, int y, int dim)
{
    BITMAPINFO bi;
    if (!buf || dim < 1) return;
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = src; bi.bmiHeader.biHeight = -src;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    SetStretchBltMode(dc, HALFTONE);
    SetBrushOrgEx(dc, 0, 0, NULL);
    StretchDIBits(dc, x, y, dim, dim, 0, 0, src, src, buf, &bi, DIB_RGB_COLORS, SRCCOPY);
}

/* --------------------------------------------------- targets and widgets */
static void reg(int id, int l, int t, int r, int b)
{
    RECT rc;
    if (g_ntg >= (int)(sizeof g_tg / sizeof g_tg[0])) return;
    rc.left = l; rc.top = t + g_oy; rc.right = r; rc.bottom = b + g_oy;
    if (g_clip_on) {
        if (rc.left < g_clipwin.left) rc.left = g_clipwin.left;
        if (rc.right > g_clipwin.right) rc.right = g_clipwin.right;
        if (rc.top < g_clipwin.top) rc.top = g_clipwin.top;
        if (rc.bottom > g_clipwin.bottom) rc.bottom = g_clipwin.bottom;
    }
    if (rc.right <= rc.left || rc.bottom <= rc.top) return;
    g_tg[g_ntg].r = rc; g_tg[g_ntg].id = id; g_ntg++;
}
static int hit_id(int x, int y)
{
    int i;
    POINT p;
    p.x = x; p.y = y;
    for (i = g_ntg - 1; i >= 0; i--) {
        int id = g_tg[i].id;
        if (!PtInRect(&g_tg[i].r, p)) continue;
        if (g_modal && id < ID_M_BACK) continue;
        if (g_dd_open && id != ID_MATCHSEL && !(id >= ID_MITEM && id < ID_MITEM + MAX_TITLES)) continue;
        return id;
    }
    return ID_NONE;
}
enum { BS_OUTLINE, BS_PRIMARY };
enum { IC_NONE, IC_MOON, IC_SUN, IC_PLUS, IC_DL };

static void draw_icon(HDC dc, int icon, int cx, int cy, COLORREF fg, COLORREF bg)
{
    int i;
    if (icon == IC_MOON) {
        circle(dc, cx, cy, U(7), fg, fg, 0);
        circle(dc, cx + U(4), cy - U(3), U(6), bg, bg, 0);
    } else if (icon == IC_SUN) {
        circle(dc, cx, cy, U(4), fg, fg, 0);
        for (i = 0; i < 8; i++) {
            double a = i * PI / 4;
            line_(dc, cx + (int)(cos(a) * U(6.5)), cy + (int)(sin(a) * U(6.5)), cx + (int)(cos(a) * U(9)), cy + (int)(sin(a) * U(9)), fg, 2, PS_SOLID);
        }
    } else if (icon == IC_PLUS) {
        line_(dc, cx - U(6), cy, cx + U(6), cy, fg, 2, PS_SOLID);
        line_(dc, cx, cy - U(6), cx, cy + U(6), fg, 2, PS_SOLID);
    } else if (icon == IC_DL) {
        line_(dc, cx, cy - U(6), cx, cy + U(3), fg, 2, PS_SOLID);
        line_(dc, cx - U(4), cy - U(1), cx, cy + U(4), fg, 2, PS_SOLID);
        line_(dc, cx + U(4), cy - U(1), cx, cy + U(4), fg, 2, PS_SOLID);
        line_(dc, cx - U(6), cy + U(7), cx + U(6), cy + U(7), fg, 2, PS_SOLID);
    }
}
static void button(HDC dc, int id, int l, int t, int r, int b, const char *label, int style, int icon, HFONT f)
{
    double hv = g_hv[id];
    int down = (g_down_id == id && g_hot_id == id), off = down ? 1 : 0, tx = (l + r) / 2, icw = icon ? U(24) : 0;
    COLORREF bg, fg, bd;
    if (style == BS_PRIMARY) { bg = lerp_col(C(K_ACCENT), C(K_ACCENT_H), hv); fg = C(K_ONACC); bd = bg; }
    else { bg = lerp_col(C(K_CARD), C(K_HOVER), hv); fg = C(K_TEXT); bd = lerp_col(C(K_BORDER), C(K_ACCENT), hv * 0.8); }
    if (hv > 0.04 && !down) shadow(dc, l, t, r, b, U(9), (int)(7 * hv));
    rrect(dc, l, t + off, r, b + off, U(9), bg, bd, 1);
    if (label && label[0]) {
        int w = tw(dc, f, label);
        if (icon) tx = (l + r) / 2 + icw / 2;
        txtc(dc, tx, (t + b) / 2 + off, label, fg, f, 1);
        if (icon) draw_icon(dc, icon, tx - w / 2 - U(14), (t + b) / 2 + off, fg, bg);
    } else if (icon) draw_icon(dc, icon, (l + r) / 2, (t + b) / 2 + off, fg, bg);
    reg(id, l, t, r, b);
}
static int chip(HDC dc, int x, int yc, const char *s, HFONT f, COLORREF bg, COLORREF fg, COLORREF bd)
{
    int w = tw(dc, f, s) + U(20), h = U(24);
    rrect(dc, x, yc - h / 2, x + w, yc + h / 2, U(8), bg, bd, 1);
    txtc(dc, x + w / 2, yc, s, fg, f, 1);
    return w;
}
/* Sliding-pill tab strip. Chooses shorter labels automatically when the space is tight. */
static int tab_strip(HDC dc, int x, int y, int hgt, int maxw, const char *const *labs[3], int n, int sel, int idbase,
                     double *pl, double *pr, int *init, int enabled)
{
    int pass, i, wd[8], tot = 0, tl[8], tr[8], cur;
    const char *const *lab = labs[0];
    for (pass = 0; pass < 3; pass++) {
        lab = labs[pass];
        tot = U(8);
        for (i = 0; i < n; i++) { wd[i] = tw(dc, f_semi, lab[i]) + U(pass == 2 ? 16 : 22); tot += wd[i]; }
        if (tot <= maxw) break;
    }
    rrect(dc, x, y, x + tot, y + hgt, U(10), C(K_THEAD), C(K_BORDER), 1);
    cur = x + U(4);
    for (i = 0; i < n; i++) { tl[i] = cur; tr[i] = cur + wd[i]; cur += wd[i]; }
    if (!*init) { *pl = tl[sel]; *pr = tr[sel]; *init = 1; }
    slide(pl, tl[sel]); slide(pr, tr[sel]);
    shadow(dc, (int)*pl, y + U(4), (int)*pr, y + hgt - U(4), U(8), 4);
    rrect(dc, (int)*pl, y + U(4), (int)*pr, y + hgt - U(4), U(8), C(K_CARD), C(K_BORDER), 1);
    for (i = 0; i < n; i++) {
        double hv = g_hv[idbase + i];
        COLORREF c = (i == sel) ? C(K_TEXT) : lerp_col(C(K_MUTED), C(K_TEXT), hv);
        txtc(dc, (tl[i] + tr[i]) / 2, y + hgt / 2, lab[i], c, f_semi, 1);
        if (enabled) reg(idbase + i, tl[i], y, tr[i], y + hgt);
    }
    return tot;
}

/* -------------------------------------------------------------- match data */
static void fmt_overs(int balls, char *out, size_t n) { snprintf(out, n, "%d.%d", balls / 6, balls % 6); }
static double rr_of(const InningsPlot *p) { return p->balls ? 6.0 * p->total_runs / p->balls : 0.0; }
static void refresh_titles(void)
{
    int i, n = sg5_match_count();
    static Sg5Match tmp;
    g_ntitles = n > MAX_TITLES ? MAX_TITLES : n;
    for (i = 0; i < g_ntitles; i++) {
        if (sg5_load_match(i, &tmp) == 0) snprintf(g_titles[i], sizeof g_titles[i], "%s vs %s", tmp.in[0].team, tmp.in[1].team);
        else snprintf(g_titles[i], sizeof g_titles[i], "(match %d)", i + 1);
    }
}
static void load_current(void)
{
    int k;
    if (sg5_load_match(g_match_index, &g_match) != 0) memset(&g_match, 0, sizeof g_match);
    for (k = 0; k < 2; k++) if (sg5_scorecard(g_match_index, k, &g_card[k]) != 0) memset(&g_card[k], 0, sizeof g_card[k]);
    g_nmvp = sg5_mvp(g_match_index, g_mvp, 8);
    g_t_match = g_t_chart = g_t_rtab = GetTickCount();
    g_rs = g_rs_goal = 0;
    g_match_gen++;
    g_plot_valid = 0;
    refresh_titles();
}
static int is_winner(const InningsPlot *p)
{
    size_t n = strlen(p->team);
    return n > 0 && strncmp(g_match.result, p->team, n) == 0;
}
static void nice_scale(int raw, int *ymax, int *step)
{
    static const int st[] = {5, 10, 20, 25, 50, 100, 200, 250, 500};
    int i;
    if (raw < 1) raw = 1;
    for (i = 0; i < 9; i++) {
        if ((raw + st[i] - 1) / st[i] <= 8) {
            *step = st[i];
            *ymax = ((raw + st[i] - 1) / st[i]) * st[i];
            if (*ymax < st[i]) *ymax = st[i];
            return;
        }
    }
    *step = 1000; *ymax = ((raw + 999) / 1000) * 1000;
}
static int runs_at(const InningsPlot *p, int v)
{
    if (v <= 0 || p->overs < 1) return 0;
    if (v > p->overs) return p->total_runs;
    return p->cumulative_runs[v - 1 < SG5_MAX_OVERS ? v - 1 : SG5_MAX_OVERS - 1];
}
static int wkts_at(const InningsPlot *p, int v)
{
    int i, s = 0;
    if (v > p->overs) v = p->overs;
    for (i = 0; i < v && i < SG5_MAX_OVERS; i++) s += p->wicket_in_over[i];
    return s;
}

/* ------------------------------------------------------------------ layout */
static Lay lay(void)
{
    Lay L;
    L.pad = U(24); L.top_h = U(76); L.stat_h = U(28);
    L.view_h = g_h - L.top_h - L.stat_h;
    L.cw = g_w - 2 * L.pad;
    L.mc_y = U(18); L.mc_h = U(250);
    L.pn_y = L.mc_y + L.mc_h + U(18);
    L.pn_h = L.view_h - L.pn_y - U(18);
    if (L.pn_h < U(440)) L.pn_h = U(440);
    L.rw = (int)((L.cw - U(18)) * 0.415);
    if (L.rw < U(450)) L.rw = U(450);
    L.lw = L.cw - U(18) - L.rw;
    L.rx = L.pad + L.lw + U(18);
    L.total = L.pn_y + L.pn_h + U(18);
    return L;
}

/* ----------------------------------------------------------- small shapes */
static void star(HDC dc, int cx, int cy, int r, COLORREF col)
{
    POINT p[10];
    int j;
    for (j = 0; j < 10; j++) {
        double ang = -PI / 2 + j * PI / 5, rad = (j % 2 ? 0.42 : 1.0) * r;
        p[j].x = cx + (int)(cos(ang) * rad); p[j].y = cy + (int)(sin(ang) * rad);
    }
    poly(dc, p, 10, col, col);
}
static void pulse_dot(HDC dc, int cx, int cy, int r, COLORREF col, COLORREF bg)
{
    double ph = fmod((double)GetTickCount() / 1500.0, 1.0);
    g_idle = 1;
    ring(dc, cx, cy, r + (int)(ph * U(7)), lerp_col(col, bg, ph), 1);
    circle(dc, cx, cy, r, col, col, 0);
}
static void brand_glyph(HDC dc, int x, int y, int s)
{
    int w = s / 5, i;
    rrect(dc, x, y, x + s, y + s, U(11), C(K_ACCENT), C(K_ACCENT), 0);
    for (i = 0; i < 3; i++) {
        int h = s * (i + 2) / 7;
        fill(dc, x + s / 5 + i * (w + U(3)), y + s - s / 5 - h, x + s / 5 + i * (w + U(3)) + w, y + s - s / 5, C(K_ONACC));
    }
}

/* ------------------------------------------------------------- match card */
static void team_block(HDC dc, int x, int y, int k, double cnt)
{
    const InningsPlot *p = &g_match.in[k];
    COLORREF tc = k ? C(K_T2) : C(K_T1);
    char buf[96], ov[24], fin[48];
    int runs = (int)(p->total_runs * cnt + 0.5), wk = (int)(p->wickets * cnt + 0.5), fw, ow;

    circle(dc, x + U(5), y, U(5), tc, tc, 0);
    txtc(dc, x + U(20), y, p->team, C(K_TEXT), f_h2, 0);
    if (is_winner(p)) star(dc, x + U(20) + tw(dc, f_h2, p->team) + U(16), y, U(8), C(K_GOLD));
    snprintf(fin, sizeof fin, "%d/%d", p->total_runs, p->wickets);
    fw = tw(dc, f_score, fin);
    snprintf(buf, sizeof buf, "%d/%d", runs, wk);
    txtc(dc, x, y + U(44), buf, C(K_TEXT), f_score, 0);
    fmt_overs(p->balls, ov, sizeof ov);
    snprintf(buf, sizeof buf, "(%s ov)", ov);
    txtc(dc, x + fw + U(16), y + U(52), buf, C(K_MUTED), f_body, 0);
    ow = tw(dc, f_body, buf);
    snprintf(buf, sizeof buf, "CRR: %.2f", rr_of(p) * cnt);
    chip(dc, x + fw + U(16) + ow + U(12), y + U(52), buf, f_cap, C(K_THEAD), C(K_MUTED), C(K_BORDER));
}

static void draw_match_card(HDC dc, int x, int y, int w, int h)
{
    double cnt = ease_out(since(g_t_match) / 1200.0);
    char title[170], sub[170], buf[160];
    int rx = x + w - U(24), pw, bx = x + U(24), bw = w - U(48), by = y + U(190), bh = U(42), half = x + w / 2;
    if (since(g_t_match) < 1300) g_busy = 1;
    card(dc, x, y, x + w, y + h, U(14));
    snprintf(title, sizeof title, "%s vs %s", g_match.in[0].team, g_match.in[1].team);
    txtc(dc, x + U(24), y + U(32), title, C(K_TEXT), f_h1, 0);
    snprintf(sub, sizeof sub, "%s \xB7 %s", g_match.info.venue, g_match.info.date);
    txtc(dc, x + U(24), y + U(58), sub, C(K_MUTED), f_body, 0);

    pw = tw(dc, f_capb, "Completed") + U(40);
    rrect(dc, rx - pw, y + U(20), rx, y + U(46), U(13), C(K_GREENBG), lerp_col(C(K_GREENBG), C(K_GREEN), 0.35), 1);
    pulse_dot(dc, rx - pw + U(15), y + U(33), U(4), C(K_GREEN), C(K_GREENBG));
    txtc(dc, rx - pw + U(27), y + U(33), "Completed", C(K_GREENFG), f_capb, 0);
    if (g_match.info.id[0]) {
        int cw2 = tw(dc, f_capb, g_match.info.id) + U(22);
        rrect(dc, rx - pw - U(10) - cw2, y + U(20), rx - pw - U(10), y + U(46), U(8), C(K_THEAD), C(K_BORDER), 1);
        txtc(dc, rx - pw - U(10) - cw2 / 2, y + U(33), g_match.info.id, C(K_MUTED), f_capb, 1);
    }
    line_(dc, x + 1, y + U(80), x + w - 1, y + U(80), C(K_BORDER), 1, PS_SOLID);

    team_block(dc, x + U(24), y + U(106), 0, cnt);
    txtc(dc, half - U(10), y + U(152), "vs", C(K_FAINT), f_semi, 1);
    team_block(dc, half + U(26), y + U(106), 1, cnt);

    rrect(dc, bx, by, bx + bw, by + bh, U(8), C(K_BANNER), C(K_BANNER), 0);
    fill(dc, bx, by + U(2), bx + U(4), by + bh - U(2), C(K_ACCENT));
    snprintf(buf, sizeof buf, "%s", g_match.result);
    txtc(dc, bx + U(18), by + bh / 2, buf, C(K_TEXT), f_bold, 0);
    if (g_match.aw.man_of_match[0] && strcmp(g_match.aw.man_of_match, "-") != 0) {
        char mom[100];
        int cwid;
        snprintf(mom, sizeof mom, "Man of Match: %s", g_match.aw.man_of_match);
        cwid = tw(dc, f_cap, mom) + U(24);
        if (bw - U(40) - tw(dc, f_bold, buf) > cwid) {
            rrect(dc, bx + bw - U(12) - cwid, by + U(8), bx + bw - U(12), by + bh - U(8), U(7), C(K_CARD), C(K_BORDER), 1);
            txtc(dc, bx + bw - U(12) - cwid / 2, by + bh / 2, mom, C(K_MUTED), f_cap, 1);
        }
    }
}

/* ------------------------------------------------------------ chart plots */
static double gx(const Geo *g, double v) { return g->px0 + (g->px1 - g->px0) * v / g->n; }
static double gy(const Geo *g, double v) { return g->py1 - (g->py1 - g->py0) * v / g->ymax; }
#define BX(g, v) ((int)((gx(g, (v)) - (g)->bx0) * SSC + 0.5))
#define BY(g, v) ((int)((gy(g, (v)) - (g)->by0) * SSC + 0.5))

static int x_step(const Geo *g)
{
    static const int s[4] = {1, 2, 5, 10};
    double px = (double)(g->px1 - g->px0) / g->n;
    int i;
    for (i = 0; i < 4; i++) if (px * s[i] >= U(48)) return s[i];
    return 20;
}
static double rr_val(const InningsPlot *p, int i) { return (double)p->cumulative_runs[i - 1] / i; }
static void make_geo(Geo *g, int view, int px0, int py0, int px1, int py1)
{
    int k, i, raw = 10, n1 = g_match.in[0].overs, n2 = g_match.in[1].overs;
    g->px0 = px0; g->py0 = py0; g->px1 = px1; g->py1 = py1;
    if (view == VIEW_MAN1 || view == VIEW_MAN2) {
        int mx = sg5_max_over_runs(&g_match);
        g->n = view == VIEW_MAN2 ? n2 : n1;
        raw = mx + mx / 8 + 1;
    } else {
        g->n = n1 > n2 ? n1 : n2;
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            if (view == VIEW_RR) {
                for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++) if ((int)ceil(rr_val(p, i)) + 1 > raw) raw = (int)ceil(rr_val(p, i)) + 1;
            } else {
                if (p->total_runs > raw) raw = p->total_runs;
                for (i = 0; i < p->overs && i < SG5_MAX_OVERS; i++) if (p->cumulative_runs[i] > raw) raw = p->cumulative_runs[i];
            }
        }
        if (view == VIEW_RR && raw < 8) raw = 8;
    }
    if (g->n < 1) g->n = 1;
    if (g->n > SG5_MAX_OVERS) g->n = SG5_MAX_OVERS;
    nice_scale(raw, &g->ymax, &g->ystep);
    g->bx0 = g->px0 - U(14); g->by0 = g->py0 - U(14);
    g->bx1 = g->px1 + U(14); g->by1 = g->py1 + U(10);
}
static int series_pts(const InningsPlot *p, int rr, double xv, double *xs, double *ys)
{
    int ns = p->overs, i, n = 0;
    if (ns > SG5_MAX_OVERS) ns = SG5_MAX_OVERS;
    if (ns < 1) return 0;
    if (!rr) { xs[n] = 0; ys[n] = 0; n++; }
    for (i = 1; i <= ns; i++) {
        double v = rr ? rr_val(p, i) : (double)p->cumulative_runs[i - 1];
        if (i <= xv) { xs[n] = i; ys[n] = v; n++; }
        else {
            if (n > 0) {
                double t = (xv - xs[n - 1]) / (i - xs[n - 1]);
                if (t > 0) { xs[n] = xv; ys[n] = ys[n - 1] + (v - ys[n - 1]) * t; n++; }
            }
            break;
        }
    }
    return n;
}
static void plot_grid(HDC d, const Geo *g, int vertical)
{
    int t, i, st = x_step(g);
    HPEN gp = CreatePen(PS_DASH, 1, C(K_GRID)), old = (HPEN)SelectObject(d, gp);
    SetBkMode(d, TRANSPARENT);
    for (t = 0; t <= g->ymax; t += g->ystep) { MoveToEx(d, BX(g, 0), BY(g, t), NULL); LineTo(d, BX(g, g->n), BY(g, t)); }
    if (vertical) for (i = 0; i <= g->n; i += st) { MoveToEx(d, BX(g, i), BY(g, g->ymax), NULL); LineTo(d, BX(g, i), BY(g, 0)); }
    SelectObject(d, old); DeleteObject(gp);
    gp = CreatePen(PS_SOLID, SSC, C(K_FAINT)); old = (HPEN)SelectObject(d, gp);
    MoveToEx(d, BX(g, 0), BY(g, g->ymax), NULL); LineTo(d, BX(g, 0), BY(g, 0)); LineTo(d, BX(g, g->n), BY(g, 0));
    SelectObject(d, old); DeleteObject(gp);
}
static void plot_lines(HDC d, const Geo *g, int rr, double prog)
{
    int k, i, np;
    double xv = prog * g->n, xs[SG5_MAX_OVERS + 3], ys[SG5_MAX_OVERS + 3];
    POINT pts[SG5_MAX_OVERS + 6];
    plot_grid(d, g, 1);
    if (!rr) {                                   /* soft areas first, so they never hide a line */
        for (k = 1; k >= 0; k--) {
            const InningsPlot *p = &g_match.in[k];
            COLORREF col = k ? C(K_T2) : C(K_T1);
            HBRUSH br;
            HGDIOBJ ob, op;
            np = series_pts(p, 0, xv, xs, ys);
            if (np < 2) continue;
            for (i = 0; i < np; i++) { pts[i].x = BX(g, xs[i]); pts[i].y = BY(g, ys[i]); }
            pts[np].x = pts[np - 1].x; pts[np].y = BY(g, 0);
            pts[np + 1].x = pts[0].x; pts[np + 1].y = BY(g, 0);
            br = CreateSolidBrush(lerp_col(C(K_CARD), col, k ? 0.06 : 0.09));
            ob = SelectObject(d, br); op = SelectObject(d, GetStockObject(NULL_PEN));
            Polygon(d, pts, np + 2);
            SelectObject(d, ob); SelectObject(d, op); DeleteObject(br);
        }
    }
    for (k = 1; k >= 0; k--) {                   /* second innings first so the first stays on top */
        const InningsPlot *p = &g_match.in[k];
        COLORREF col = k ? C(K_T2) : C(K_T1);
        HPEN pn, ringp;
        HBRUSH br;
        HGDIOBJ ob, op;
        int lw = (int)(2.5 * g_s * SSC + 0.5), mr = (int)(4.5 * g_s * SSC + 0.5);
        np = series_pts(p, rr, xv, xs, ys);
        if (np < 2) continue;
        pn = CreatePen(PS_SOLID, lw, col);
        op = SelectObject(d, pn);
        MoveToEx(d, BX(g, xs[0]), BY(g, ys[0]), NULL);
        for (i = 1; i < np; i++) LineTo(d, BX(g, xs[i]), BY(g, ys[i]));
        SelectObject(d, op); DeleteObject(pn);
        br = CreateSolidBrush(C(K_CARD)); ringp = CreatePen(PS_SOLID, SSC * 2, col);
        ob = SelectObject(d, br); op = SelectObject(d, ringp);
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS && i <= xv; i++) {      /* wickets */
            if (p->wicket_in_over[i - 1] > 0) {
                int cx = BX(g, i), cy = BY(g, rr ? rr_val(p, i) : (double)p->cumulative_runs[i - 1]);
                Ellipse(d, cx - mr, cy - mr, cx + mr + 1, cy + mr + 1);
            }
        }
        SelectObject(d, ob); SelectObject(d, op); DeleteObject(br); DeleteObject(ringp);
    }
}
static void plot_bars(HDC d, const Geo *g, int k, double prog)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->overs, i, maxv = 0, bands = 5;
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    double slot, barw;
    plot_grid(d, g, 0);
    if (n < 1) return;
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    for (i = 0; i < n; i++) if (p->runs_per_over[i] > maxv) maxv = p->runs_per_over[i];
    slot = (double)(g->px1 - g->px0) / n;
    barw = slot * 0.62;
    for (i = 0; i < n; i++) {
        double st = (double)i / n * 0.45, e = ease_out((prog - st) / 0.55);
        double v = p->runs_per_over[i] * e;
        double x0 = (g->px0 - g->bx0) + slot * i + (slot - barw) / 2.0, x1 = x0 + barw;
        double y1 = gy(g, 0) - g->by0, y0 = gy(g, v) - g->by0;
        COLORREF col = (p->runs_per_over[i] == maxv) ? lerp_col(acc, C(K_GOLD), 0.92) : acc;
        int b;
        if (y1 - y0 < 1.0) continue;
        for (b = 0; b < bands; b++) {
            double ya = y0 + (y1 - y0) * b / bands, yb = y0 + (y1 - y0) * (b + 1) / bands;
            COLORREF c = lerp_col(lighten(col, 0.22), col, (double)b / (bands - 1));
            fill(d, (int)(x0 * SSC), (int)(ya * SSC), (int)(x1 * SSC), (int)(yb * SSC) + 1, c);
        }
    }
}
/* Renders the plot at 2x into a memory bitmap and shrinks it with HALFTONE: smooth, anti-aliased lines. */
static void render_plot(const Geo *g, int view, double prog)
{
    int bw = g->bx1 - g->bx0, bh = g->by1 - g->by0, W = bw * SSC, H = bh * SSC;
    HDC sdc = GetDC(NULL), big = CreateCompatibleDC(sdc), small_;
    HBITMAP bb = CreateCompatibleBitmap(sdc, W, H);
    HGDIOBJ ob = SelectObject(big, bb), os;

    fill(big, 0, 0, W, H, C(K_CARD));
    if (view == VIEW_WORM || view == VIEW_RR) plot_lines(big, g, view == VIEW_RR, prog);
    else plot_bars(big, g, view == VIEW_MAN2 ? 1 : 0, prog);
    if (!g_plot || g_plot_w != bw || g_plot_h != bh) {
        if (g_plot) DeleteObject(g_plot);
        g_plot = CreateCompatibleBitmap(sdc, bw, bh);
        g_plot_w = bw; g_plot_h = bh;
    }
    small_ = CreateCompatibleDC(sdc);
    os = SelectObject(small_, g_plot);
    SetStretchBltMode(small_, HALFTONE);
    SetBrushOrgEx(small_, 0, 0, NULL);
    StretchBlt(small_, 0, 0, bw, bh, big, 0, 0, W, H, SRCCOPY);
    SelectObject(small_, os); DeleteDC(small_);
    SelectObject(big, ob); DeleteObject(bb); DeleteDC(big);
    ReleaseDC(NULL, sdc);
}
static void show_plot(HDC dc, const Geo *g, int view, double prog)
{
    int key = view * 100000 + g_match_gen * 100 + ((g_w ^ (g_h << 3)) & 63);
    HDC t;
    if (!g_plot_valid || g_plot_key != key || prog < 1.0) {
        render_plot(g, view, prog);
        g_plot_key = key;
        g_plot_valid = (prog >= 1.0);
    }
    t = CreateCompatibleDC(dc);
    SelectObject(t, g_plot);
    BitBlt(dc, g->bx0, g->by0, g->bx1 - g->bx0, g->by1 - g->by0, t, 0, 0, SRCCOPY);
    DeleteDC(t);
}

/* ------------------------------------------------------------ chart views */
static void y_labels(HDC dc, const Geo *g, int dec)
{
    int t;
    char b[16];
    (void)dec;
    for (t = 0; t <= g->ymax; t += g->ystep) {
        snprintf(b, sizeof b, "%d", t);
        txtc(dc, g->px0 - U(10), (int)(gy(g, t) + 0.5), b, C(K_MUTED), f_cap, 2);
    }
}
static void tip_start(const char *head, COLORREF hc)
{
    g_tip.n = 1;
    snprintf(g_tip.text[0], sizeof g_tip.text[0], "%s", head);
    g_tip.col[0] = hc;
}
static void tip_add(COLORREF c, const char *fmt, ...)
{
    va_list ap;
    if (g_tip.n >= 4) return;
    va_start(ap, fmt);
    vsnprintf(g_tip.text[g_tip.n], sizeof g_tip.text[0], fmt, ap);
    va_end(ap);
    g_tip.col[g_tip.n++] = c;
}
static void legend_item(HDC dc, int *rx, int yc, COLORREF col, const char *label)
{
    int w = tw(dc, f_cap, label);
    *rx -= w;
    txtc(dc, *rx, yc, label, C(K_MUTED), f_cap, 0);
    *rx -= U(34);
    line_(dc, *rx, yc, *rx + U(22), yc, col, 3, PS_SOLID);
    circle(dc, *rx + U(11), yc, U(4), C(K_CARD), col, 2);
    *rx -= U(14);
}

static void view_lines(HDC dc, int fx, int fy, int fw, int fh, int rr)
{
    Geo g;
    double prog = prog_of(g_t_chart, 1200, 0);
    int i, st, k;
    char b[96];
    make_geo(&g, rr ? VIEW_RR : VIEW_WORM, fx + U(52), fy + U(66), fx + fw - U(26), fy + fh - U(40));
    show_plot(dc, &g, rr ? VIEW_RR : VIEW_WORM, prog);
    y_labels(dc, &g, rr);
    st = x_step(&g);
    for (i = 0; i <= g.n; i += st) {
        snprintf(b, sizeof b, "Ov %d", i);
        txtc(dc, (int)(gx(&g, i) + 0.5), g.py1 + U(16), b, C(K_MUTED), f_cap, 1);
    }
    if (g_hover_content && g_cmx >= g.px0 - U(4) && g_cmx <= g.px1 + U(4) && g_cmy >= g.py0 - U(4) && g_cmy <= g.py1 + U(4)) {
        int v = (int)(((g_cmx - g.px0) * (double)g.n) / (g.px1 - g.px0) + 0.5), hx;
        if (v < 0) v = 0;
        if (v > g.n) v = g.n;
        hx = (int)(gx(&g, v) + 0.5);
        line_(dc, hx, g.py0, hx, g.py1, C(K_FAINT), 1, PS_DOT);
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            double val;
            if (p->overs < 1 || (rr && v < 1)) continue;
            val = rr ? (v > p->overs ? rr_of(p) : rr_val(p, v)) : (double)runs_at(p, v);
            circle(dc, hx, (int)(gy(&g, val) + 0.5), U(5), C(K_CARD), k ? C(K_T2) : C(K_T1), 2);
        }
        snprintf(b, sizeof b, "After over %d", v);
        tip_start(b, C(K_ONACC));
        if (rr) {
            for (k = 0; k < 2; k++) {
                const InningsPlot *p = &g_match.in[k];
                double val = (v < 1) ? 0.0 : (v > p->overs ? rr_of(p) : rr_val(p, v));
                tip_add(k ? lighten(C(K_T2), 0.45) : lighten(C(K_T1), 0.5), "%s   RR %.2f", p->team, val);
            }
        } else {
            int r0 = runs_at(&g_match.in[0], v), r1 = runs_at(&g_match.in[1], v);
            tip_add(lighten(C(K_T1), 0.5), "%s   %d/%d", g_match.in[0].team, r0, wkts_at(&g_match.in[0], v));
            tip_add(lighten(C(K_T2), 0.45), "%s   %d/%d", g_match.in[1].team, r1, wkts_at(&g_match.in[1], v));
            if (r0 == r1) tip_add(C(K_GREEN), "Scores level");
            else tip_add(C(K_GREEN), "%s lead by %d", r0 > r1 ? g_match.in[0].team : g_match.in[1].team, abs(r0 - r1));
        }
    }
}

static void view_bars(HDC dc, int fx, int fy, int fw, int fh, int k)
{
    const InningsPlot *p = &g_match.in[k];
    Geo g;
    double prog = prog_of(g_t_chart, 1200, 0), slot;
    int n = p->overs, i, st = 1, hover = -1;
    char b[96];
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    make_geo(&g, k ? VIEW_MAN2 : VIEW_MAN1, fx + U(52), fy + U(70), fx + fw - U(24), fy + fh - U(40));
    if (n < 1) { txtc(dc, fx + fw / 2, fy + fh / 2, "No chart data available", C(K_MUTED), f_body, 1); return; }
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    show_plot(dc, &g, k ? VIEW_MAN2 : VIEW_MAN1, prog);
    y_labels(dc, &g, 0);
    slot = (double)(g.px1 - g.px0) / n;
    if (slot < U(26)) st = 2;
    if (slot < U(13)) st = 5;
    for (i = 0; i < n; i++) {
        if (i % st == 0) {
            snprintf(b, sizeof b, "%d", i + 1);
            txtc(dc, (int)(g.px0 + slot * i + slot / 2), g.py1 + U(16), b, C(K_MUTED), f_cap, 1);
        }
    }
    txtc(dc, (g.px0 + g.px1) / 2, g.py1 + U(34), "Overs", C(K_MUTED), f_capb, 1);
    {
        char lab[48];
        int lx2 = fx + fw - U(16);
        snprintf(lab, sizeof lab, "Average %.2f runs / over", rr_of(p));
        lx2 -= tw(dc, f_cap, lab);
        txtc(dc, lx2, fy + U(22), lab, C(K_MUTED), f_cap, 0);
        line_(dc, lx2 - U(30), fy + U(22), lx2 - U(8), fy + U(22), C(K_MUTED), 1, PS_DASH);
    }
    if (prog >= 0.95) {
        double avg = rr_of(p);
        int ay = (int)(gy(&g, avg) + 0.5);
        for (i = 0; i < n; i++) {
            int cx = (int)(g.px0 + slot * i + slot / 2), top = (int)(gy(&g, p->runs_per_over[i]) + 0.5);
            if (n <= 24 && p->runs_per_over[i] > 0) {
                snprintf(b, sizeof b, "%d", p->runs_per_over[i]);
                txtc(dc, cx, top - U(10), b, C(K_TEXT), f_capb, 1);
            }
            if (p->wicket_in_over[i] > 0) {
                circle(dc, cx, top - U(30), U(9), C(K_RED), C(K_RED), 0);
                txtc(dc, cx, top - U(30), "W", RGB(255, 255, 255), f_capb, 1);
            }
        }
        line_(dc, g.px0, ay, g.px1, ay, C(K_MUTED), 1, PS_DASH);
    }
    if (g_hover_content && g_cmx >= g.px0 && g_cmx <= g.px1 && g_cmy >= g.py0 - U(30) && g_cmy <= g.py1) {
        hover = (int)((g_cmx - g.px0) / slot);
        if (hover >= n) hover = n - 1;
        if (hover >= 0) {
            int x0 = (int)(g.px0 + slot * hover + slot * 0.16), x1 = (int)(g.px0 + slot * hover + slot * 0.84);
            int top = (int)(gy(&g, p->runs_per_over[hover]) + 0.5), wk = p->wicket_in_over[hover];
            outline_rrect(dc, x0 - 2, top - 2, x1 + 2, g.py1, U(3), C(K_TEXT), 2, PS_SOLID);
            snprintf(b, sizeof b, "Over %d", hover + 1);
            tip_start(b, C(K_ONACC));
            tip_add(C(K_ONACC), "%d runs  (cumulative %d)", p->runs_per_over[hover], runs_at(p, hover + 1));
            if (wk > 0) tip_add(lighten(C(K_RED), 0.5), "%d wicket%s fell", wk, wk == 1 ? "" : "s");
            else tip_add(C(K_FAINT), "No wicket");
            (void)acc;
        }
    }
}

static void view_partner(HDC dc, int fx, int fy, int fw, int fh, int k)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->num_partnerships, i, mx = 1, rh, top, namew = U(190), bx0, bx1, hover = -1;
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    double el = since(g_t_chart);
    if (n > SG5_MAX_PSHIPS) n = SG5_MAX_PSHIPS;
    if (n < 1) { txtc(dc, fx + fw / 2, fy + fh / 2, "No partnership data available", C(K_MUTED), f_body, 1); return; }
    for (i = 0; i < n; i++) if (p->pship_runs[i] > mx) mx = p->pship_runs[i];
    top = fy + U(74);
    rh = (fy + fh - U(10) - top) / n;
    if (rh > U(40)) rh = U(40);
    if (fw < U(520)) namew = U(130);
    bx0 = fx + U(60) + namew; bx1 = fx + fw - U(92);
    for (i = 0; i < n; i++) {
        int ry = top + i * rh, cy = ry + rh / 2, bh = rh - U(12), bwid, over;
        double e = ease_out((el - i * 80.0) / 600.0);
        char b[160], nm[160], fnm[160];
        if (e < 1.0) g_busy = 1;
        if (bh > U(22)) bh = U(22);
        bwid = (int)((bx1 - bx0) * ((double)p->pship_runs[i] / mx) * e);
        over = g_hover_content && g_cmx >= fx && g_cmx <= fx + fw && g_cmy >= ry && g_cmy < ry + rh;
        if (over) { hover = i; rrect(dc, fx + U(8), ry + 1, fx + fw - U(8), ry + rh - 1, U(8), C(K_HOVER), C(K_HOVER), 0); }
        circle(dc, fx + U(30), cy, U(12), C(K_THEAD), C(K_BORDER), 1);
        snprintf(b, sizeof b, "W%d", i + 1);
        txtc(dc, fx + U(30), cy, b, C(K_MUTED), f_capb, 1);
        if (p->pship_bat2[i][0]) snprintf(nm, sizeof nm, "%s & %s%s", p->pship_bat1[i], p->pship_bat2[i], p->pship_unbeaten[i] ? "*" : "");
        else snprintf(nm, sizeof nm, "%s%s", p->pship_bat1[i], p->pship_unbeaten[i] ? "*" : "");
        fit(dc, f_body, nm, namew, fnm, sizeof fnm);
        txtc(dc, fx + U(52), cy, fnm, C(K_TEXT), f_body, 0);
        rrect(dc, bx0, cy - bh / 2, bx1, cy + bh / 2, U(7), C(K_THEAD), C(K_THEAD), 0);
        if (bwid > U(4)) rrect(dc, bx0, cy - bh / 2, bx0 + bwid, cy + bh / 2, U(7), p->pship_unbeaten[i] ? C(K_GOLD) : acc, acc, 0);
        snprintf(b, sizeof b, "%d", (int)(p->pship_runs[i] * e + 0.5));
        txtc(dc, bx1 + U(12), cy, b, C(K_TEXT), f_bold, 0);
        snprintf(b, sizeof b, "%d%%", p->total_runs ? p->pship_runs[i] * 100 / p->total_runs : 0);
        txtc(dc, fx + fw - U(16), cy, b, C(K_MUTED), f_cap, 2);
    }
    if (hover >= 0) {
        char b[48];
        snprintf(b, sizeof b, "Wicket %d partnership", hover + 1);
        tip_start(b, C(K_ONACC));
        tip_add(C(K_ONACC), "%s%s%s", p->pship_bat1[hover], p->pship_bat2[hover][0] ? " & " : "", p->pship_bat2[hover]);
        tip_add(C(K_GOLD), "%d runs%s", p->pship_runs[hover], p->pship_unbeaten[hover] ? "  (unbeaten)" : "");
    }
}

static const char *const CT_FULL[NCTAB] = {"Worm Chart", "Manhattan (Inn 1)", "Manhattan (Inn 2)", "Partnerships (Inn 1)", "Partnerships (Inn 2)", "Run Rate"};
static const char *const CT_SHORT[NCTAB] = {"Worm", "Manhattan 1", "Manhattan 2", "Partnerships 1", "Partnerships 2", "Run Rate"};
static const char *const CT_TINY[NCTAB] = {"Worm", "Man 1", "Man 2", "Part 1", "Part 2", "RR"};
static const char *const RT_FULL[NRTAB] = {"1st Innings", "2nd Innings", "Awards"};
static const char *const RT_SHORT[NRTAB] = {"1st Inn", "2nd Inn", "Awards"};

static void draw_chart_card(HDC dc, int x, int y, int w, int h)
{
    const char *const *labs[3];
    int fx = x + U(16), fy = y + U(80), fw = w - U(32), fh = h - U(80) - U(64), lx;
    char title[200], sub[100];
    labs[0] = CT_FULL; labs[1] = CT_SHORT; labs[2] = CT_TINY;
    card(dc, x, y, x + w, y + h, U(14));
    tab_strip(dc, x + U(16), y + U(14), U(40), w - U(32), labs, NCTAB, (int)g_view, ID_CTAB, &g_ct_l, &g_ct_r, &g_ct_init, 1);
    line_(dc, x + 1, y + U(68), x + w - 1, y + U(68), C(K_BORDER), 1, PS_SOLID);
    rrect(dc, fx, fy, fx + fw, fy + fh, U(12), C(K_CARD), C(K_BORDER), 1);

    switch (g_view) {
    case VIEW_WORM: snprintf(title, sizeof title, "WORM CHART: %s vs %s", g_match.in[0].team, g_match.in[1].team); snprintf(sub, sizeof sub, "Cumulative Runs Progression & Wickets"); break;
    case VIEW_RR: snprintf(title, sizeof title, "RUN RATE: %s vs %s", g_match.in[0].team, g_match.in[1].team); snprintf(sub, sizeof sub, "Run rate after each over (rings mark wickets)"); break;
    case VIEW_MAN1: case VIEW_MAN2: snprintf(title, sizeof title, "MANHATTAN: %s", g_match.in[g_view == VIEW_MAN2].team); snprintf(sub, sizeof sub, "Runs per over \xB7 W marks a wicket \xB7 gold = best over"); break;
    default: snprintf(title, sizeof title, "PARTNERSHIPS: %s", g_match.in[g_view == VIEW_PS2].team); snprintf(sub, sizeof sub, "Runs added by each batting pair"); break;
    }
    {
        char ft[200], l1[130], l2[130];
        int legw = 0;
        if (g_view == VIEW_WORM || g_view == VIEW_RR) {
            snprintf(l1, sizeof l1, "%s (%d/%d)", g_match.in[0].team, g_match.in[0].total_runs, g_match.in[0].wickets);
            snprintf(l2, sizeof l2, "%s (%d/%d)", g_match.in[1].team, g_match.in[1].total_runs, g_match.in[1].wickets);
            legw = tw(dc, f_cap, l1) > tw(dc, f_cap, l2) ? tw(dc, f_cap, l1) : tw(dc, f_cap, l2);
            legw += U(48);
        }
        fit(dc, f_bold, title, fw - U(32) - legw - U(16), ft, sizeof ft);
        txtc(dc, fx + U(16), fy + U(22), ft, C(K_TEXT), f_bold, 0);
        txtc(dc, fx + U(16), fy + U(42), sub, C(K_MUTED), f_cap, 0);
        if (legw) {
            lx = fx + fw - U(16);
            legend_item(dc, &lx, fy + U(22), C(K_T1), l1);
            lx = fx + fw - U(16);
            legend_item(dc, &lx, fy + U(42), C(K_T2), l2);
        }
    }
    switch (g_view) {
    case VIEW_WORM: view_lines(dc, fx, fy, fw, fh, 0); break;
    case VIEW_RR: view_lines(dc, fx, fy, fw, fh, 1); break;
    case VIEW_MAN1: view_bars(dc, fx, fy, fw, fh, 0); break;
    case VIEW_MAN2: view_bars(dc, fx, fy, fw, fh, 1); break;
    case VIEW_PS1: view_partner(dc, fx, fy, fw, fh, 0); break;
    default: view_partner(dc, fx, fy, fw, fh, 1); break;
    }
    line_(dc, x + 1, y + h - U(54), x + w - 1, y + h - U(54), C(K_BORDER), 1, PS_SOLID);
    button(dc, ID_DL_SVG, x + U(16), y + h - U(44), x + U(16) + tw(dc, f_semi, "Download SVG Vector") + U(46), y + h - U(14), "Download SVG Vector", BS_OUTLINE, IC_DL, f_semi);
    {
        int b1 = x + U(16) + tw(dc, f_semi, "Download SVG Vector") + U(46) + U(10);
        int b2 = b1 + tw(dc, f_semi, "Download Pure C BMP (24bpp)") + U(46);
        button(dc, ID_DL_BMP, b1, y + h - U(44), b2, y + h - U(14), "Download Pure C BMP (24bpp)", BS_OUTLINE, IC_DL, f_semi);
        if (x + w - U(16) - tw(dc, f_cap, "Engine: Components 1-5 \xB7 Pure C99 \xB7 Win32/GDI") > b2 + U(16))
            txtc(dc, x + w - U(16), y + h - U(29), "Engine: Components 1-5 \xB7 Pure C99 \xB7 Win32/GDI", C(K_MUTED), f_cap, 2);
    }
    g_chart_win.left = x; g_chart_win.top = y + g_oy; g_chart_win.right = x + w; g_chart_win.bottom = y + h + g_oy;
}

/* ----------------------------------------------------------- scorecard card */
static RECT g_inner;                         /* inner scroll rectangle, content coordinates */
static int row_hot(int x, int y, int w, int h)
{
    return g_hover_content && g_cmx >= x && g_cmx < x + w && g_cmy >= y && g_cmy < y + h &&
           g_cmy >= g_inner.top && g_cmy < g_inner.bottom;
}
static void thead(HDC dc, int x, int y, int w, const char *first, const char *const *cols, const int *right, int n)
{
    int i;
    rrect(dc, x, y, x + w, y + U(28), U(7), C(K_THEAD), C(K_THEAD), 0);
    SetTextCharacterExtra(dc, U(1));
    txtc(dc, x + U(14), y + U(14), first, C(K_MUTED), f_capb, 0);
    for (i = 0; i < n; i++) txtc(dc, right[i], y + U(14), cols[i], C(K_MUTED), f_capb, 2);
    SetTextCharacterExtra(dc, 0);
}
static void sect_title(HDC dc, int x, int y, int w, const char *left, const char *right)
{
    txtc(dc, x + U(4), y, left, C(K_ACCENT), f_bold, 0);
    if (right && right[0]) txtc(dc, x + w - U(4), y, right, C(K_MUTED), f_semi, 2);
}
static int draw_bat(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    const InningsPlot *p = &g_match.in[k];
    double el = since(g_t_rtab);
    char buf[160], ov[16], nm[160];
    static const char *const cols[6] = {"R", "B", "4S", "6S", "SR", "BND%"};
    static const int cw[6] = {38, 34, 32, 32, 54, 60};
    int right[6], i, e, fours = 0, sixes = 0, nmw;

    snprintf(buf, sizeof buf, "%s Batting", p->team);
    fmt_overs(p->balls, ov, sizeof ov);
    {
        char rt[60];
        snprintf(rt, sizeof rt, "%d/%d (%s ov)", p->total_runs, p->wickets, ov);
        sect_title(dc, x, y + U(12), w, buf, rt);
    }
    e = x + w - U(8);
    for (i = 5; i >= 0; i--) { right[i] = e; e -= U(cw[i]); }
    nmw = right[0] - U(cw[0]) - x - U(28);
    thead(dc, x, y + U(32), w, "BATTER", cols, right, 6);
    for (i = 0; i < c->nbat; i++) {
        const Sg5BatRow *r = &c->bat[i];
        int ry = y + U(66) + i * U(34), rh = U(34), cy = ry + rh / 2;
        double re = ease_out((el - i * 45.0) / 360.0);
        int off = (int)((1.0 - re) * U(18));
        COLORREF tc = fade(C(K_TEXT), re), mc = fade(C(K_MUTED), re);
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh)) rrect(dc, x, ry + 1, x + w, ry + rh - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        snprintf(nm, sizeof nm, "%s%s", r->name, r->out ? "" : "*");
        fit(dc, f_semi, nm, nmw, buf, sizeof buf);
        txtc(dc, x + U(14) + off, cy, buf, tc, f_semi, 0);
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, right[0] + off, cy, buf, tc, f_bold, 2);
        snprintf(buf, sizeof buf, "%d", r->balls); txtc(dc, right[1] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->fours); txtc(dc, right[2] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->sixes); txtc(dc, right[3] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%.1f", r->sr); txtc(dc, right[4] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d%%", (int)(r->bnd_pct + 0.5)); txtc(dc, right[5] + off, cy, buf, mc, f_body, 2);
        line_(dc, x, ry + rh - 1, x + w, ry + rh - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
        fours += r->fours; sixes += r->sixes;
    }
    y += U(66) + c->nbat * U(34) + U(8);
    snprintf(buf, sizeof buf, "Total: %d/%d (%s ov) \xB7 Run rate %.2f \xB7 4s: %d \xB7 6s: %d   (* not out)", p->total_runs, p->wickets, ov, rr_of(p), fours, sixes);
    txtc(dc, x + U(4), y + U(10), buf, C(K_MUTED), f_cap, 0);
    return y + U(26);
}
static int draw_fow(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    int i, lx = x + U(4), ly = y + U(12);
    char tok[120];
    if (c->nfow < 1) return y;
    txtc(dc, x + U(4), ly, "FALL OF WICKETS", C(K_MUTED), f_capb, 0);
    ly += U(22);
    for (i = 0; i < c->nfow; i++) {
        const Sg5FowRow *f = &c->fow[i];
        int tww;
        snprintf(tok, sizeof tok, "%d-%d (%s, %d.%d)", f->wkt, f->score, f->name, f->over > 0 ? f->over - 1 : 0, f->ball);
        tww = tw(dc, f_cap, tok) + U(14);
        if (lx + tww > x + w - U(4)) { lx = x + U(4); ly += U(20); }
        txtc(dc, lx, ly, tok, C(K_MUTED), f_cap, 0);
        lx += tww;
    }
    return ly + U(22);
}
static int draw_bowl(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    const char *team = g_match.in[1 - k].team;
    double el = since(g_t_rtab);
    char buf[160], fn[160];
    static const char *const cols[4] = {"O", "R", "W", "ECON"};
    static const int cw[4] = {46, 46, 40, 62};
    int right[4], i, e, nmw;

    snprintf(buf, sizeof buf, "%s Bowling", team);
    sect_title(dc, x, y + U(12), w, buf, NULL);
    e = x + w - U(8);
    for (i = 3; i >= 0; i--) { right[i] = e; e -= U(cw[i]); }
    nmw = right[0] - U(cw[0]) - x - U(28);
    thead(dc, x, y + U(32), w, "BOWLER", cols, right, 4);
    for (i = 0; i < c->nbowl; i++) {
        const Sg5BowlRow *r = &c->bowl[i];
        int ry = y + U(66) + i * U(34), rh = U(34), cy = ry + rh / 2;
        double re = ease_out((el - 250.0 - i * 45.0) / 360.0);
        int off = (int)((1.0 - re) * U(18));
        COLORREF tc = fade(C(K_TEXT), re), mc = fade(C(K_MUTED), re);
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh)) rrect(dc, x, ry + 1, x + w, ry + rh - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        fit(dc, f_semi, r->name, nmw, fn, sizeof fn);
        txtc(dc, x + U(14) + off, cy, fn, tc, f_semi, 0);
        snprintf(buf, sizeof buf, "%d.%d", r->balls / 6, r->balls % 6); txtc(dc, right[0] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, right[1] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->wickets); txtc(dc, right[2] + off, cy, buf, tc, f_bold, 2);
        snprintf(buf, sizeof buf, "%.2f", r->econ); txtc(dc, right[3] + off, cy, buf, mc, f_body, 2);
        line_(dc, x, ry + rh - 1, x + w, ry + rh - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
    }
    return y + U(66) + c->nbowl * U(34) + U(4);
}
static void award_glyph(HDC dc, int i, int cx, int cy, int s, COLORREF bg)
{
    int j;
    circle(dc, cx, cy, s / 2, bg, bg, 0);
    if (i == 0) star(dc, cx, cy + U(1), (int)(s * 0.30), C(K_GOLD));
    else if (i == 1) {
        circle(dc, cx, cy, (int)(s * 0.27), C(K_T2), C(K_T2), 0);
        txtc(dc, cx, cy, "6", RGB(255, 255, 255), f_capb, 1);
    } else if (i == 2) {
        for (j = 0; j < 3; j++) fill(dc, cx - U(7) + j * U(7), cy - U(7), cx - U(5) + j * U(7), cy + U(8), C(K_ACCENT));
        fill(dc, cx - U(8), cy - U(9), cx + U(9), cy - U(8), C(K_ACCENT));
    } else {
        POINT bp[6];
        static const double bx[6] = {0.58, 0.28, 0.48, 0.40, 0.74, 0.54}, by[6] = {0.10, 0.54, 0.54, 0.92, 0.42, 0.42};
        for (j = 0; j < 6; j++) { bp[j].x = cx - s / 2 + (int)(bx[j] * s); bp[j].y = cy - s / 2 + (int)(by[j] * s); }
        poly(dc, bp, 6, C(K_GOLD), C(K_GOLD));
    }
}
static int draw_awards(HDC dc, int x, int y, int w)
{
    static const char *const heads[4] = {"PLAYER OF THE MATCH", "MOST SIXES", "MOST WICKETS", "SUPER STRIKER"};
    const char *names[4];
    char vals[4][48], buf[120];
    double el = since(g_t_rtab);
    int i, rh = U(56), maxp = 1;
    names[0] = g_match.aw.man_of_match; names[1] = g_match.aw.most_sixes;
    names[2] = g_match.aw.most_wickets; names[3] = g_match.aw.super_striker;
    snprintf(vals[0], sizeof vals[0], "%d points", g_match.aw.mom_points);
    snprintf(vals[1], sizeof vals[1], "%d six%s", g_match.aw.sixes, g_match.aw.sixes == 1 ? "" : "es");
    snprintf(vals[2], sizeof vals[2], "%d wicket%s", g_match.aw.wickets, g_match.aw.wickets == 1 ? "" : "s");
    snprintf(vals[3], sizeof vals[3], "SR %.1f", g_match.aw.strike_rate);
    for (i = 0; i < 4; i++) {
        int ry = y + U(6) + i * (rh + U(8)), cy = ry + rh / 2, vw, avail;
        double re = ease_out((el - i * 90.0) / 420.0);
        int off = (int)((1.0 - re) * U(24));
        if (re < 1.0) g_busy = 1;
        rrect(dc, x + off, ry, x + w + off, ry + rh, U(10), fade(C(K_CARD2), re), fade(C(K_BORDER), re), 1);
        award_glyph(dc, i, x + U(32) + off, cy, U(38), fade(C(K_THEAD), re));
        txtc(dc, x + U(60) + off, cy - U(12), heads[i], fade(C(K_MUTED), re), f_capb, 0);
        vw = tw(dc, f_cap, vals[i]) + U(20);
        avail = w - U(60) - vw - U(24);
        fit(dc, f_bold, names[i][0] ? names[i] : "Not available", avail, buf, sizeof buf);
        txtc(dc, x + U(60) + off, cy + U(9), buf, fade(C(K_TEXT), re), f_bold, 0);
        rrect(dc, x + w - U(12) - vw + off, cy - U(12), x + w - U(12) + off, cy + U(12), U(8), fade(C(K_BANNER), re), fade(C(K_BORDER), re), 1);
        txtc(dc, x + w - U(12) - vw / 2 + off, cy, vals[i], fade(C(K_ACCENT), re), f_cap, 1);
    }
    y += U(6) + 4 * (rh + U(8)) + U(10);
    sect_title(dc, x, y + U(10), w, "MVP Rankings", "runs + 25 per wicket");
    for (i = 0; i < g_nmvp; i++) if (g_mvp[i].points > maxp) maxp = g_mvp[i].points;
    {
        static const char *const cols[3] = {"R", "W", "PTS"};
        int right[3], e = x + w - U(8), j;
        static const int cw[3] = {40, 36, 56};
        for (j = 2; j >= 0; j--) { right[j] = e; e -= U(cw[j]); }
        thead(dc, x, y + U(28), w, "   PLAYER", cols, right, 3);
    }
    for (i = 0; i < g_nmvp; i++) {
        const Sg5MvpRow *r = &g_mvp[i];
        int ry = y + U(62) + i * U(34), rh2 = U(34), cy = ry + rh2 / 2, barw, bx0 = x + U(150), bx1 = x + w - U(170);
        double re = ease_out((el - 380.0 - i * 45.0) / 380.0);
        int off = (int)((1.0 - re) * U(16));
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh2)) rrect(dc, x, ry + 1, x + w, ry + rh2 - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        snprintf(buf, sizeof buf, "%d", i + 1);
        txtc(dc, x + U(22) + off, cy, buf, fade(i == 0 ? C(K_GOLD) : C(K_FAINT), re), f_bold, 2);
        {
            char fn[120];
            fit(dc, f_semi, r->name, bx0 - x - U(40), fn, sizeof fn);
            txtc(dc, x + U(32) + off, cy, fn, fade(C(K_TEXT), re), f_semi, 0);
        }
        if (bx1 > bx0 + U(30)) {
            barw = (int)((bx1 - bx0) * ((double)r->points / maxp) * re);
            rrect(dc, bx0, cy - U(4), bx1, cy + U(4), U(4), fade(C(K_THEAD), re), fade(C(K_THEAD), re), 0);
            if (barw > U(3)) rrect(dc, bx0, cy - U(4), bx0 + barw, cy + U(4), U(4), i == 0 ? C(K_GOLD) : C(K_ACCENT), C(K_ACCENT), 0);
        }
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, x + w - U(8) - U(92) + off, cy, buf, fade(C(K_MUTED), re), f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->wickets); txtc(dc, x + w - U(8) - U(56) + off, cy, buf, fade(C(K_MUTED), re), f_body, 2);
        snprintf(buf, sizeof buf, "%d", (int)(r->points * re + 0.5)); txtc(dc, x + w - U(8) + off, cy, buf, fade(C(K_TEXT), re), f_bold, 2);
        line_(dc, x, ry + rh2 - 1, x + w, ry + rh2 - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
    }
    return y + U(62) + g_nmvp * U(34) + U(10);
}
static int strip_width(HDC dc, const char *const *labs[3], int n, int maxw)
{
    int pass, i, tot = 0;
    for (pass = 0; pass < 3; pass++) {
        tot = U(8);
        for (i = 0; i < n; i++) tot += tw(dc, f_semi, labs[pass][i]) + U(pass == 2 ? 18 : 26);
        if (tot <= maxw) break;
    }
    return tot;
}
static void draw_score_card(HDC dc, int x, int y, int w, int h)
{
    const char *const *labs[3];
    int ix = x + U(16), iy = y + U(70), iw = w - U(32), ih = h - U(70) - U(12), ty, endy, sw;
    labs[0] = RT_FULL; labs[1] = RT_SHORT; labs[2] = RT_SHORT;
    card(dc, x, y, x + w, y + h, U(14));
    txtc(dc, x + U(20), y + U(35), "Scorecard & Metrics", C(K_TEXT), f_h3, 0);
    sw = strip_width(dc, labs, NRTAB, w - U(40) - tw(dc, f_h3, "Scorecard & Metrics") - U(16));
    tab_strip(dc, x + w - U(16) - sw, y + U(16), U(38), sw + U(2), labs, NRTAB, g_rtab, ID_RTAB, &g_rt_l, &g_rt_r, &g_rt_init, 1);
    line_(dc, x + 1, y + U(68), x + w - 1, y + U(68), C(K_BORDER), 1, PS_SOLID);

    g_inner.left = ix; g_inner.top = iy; g_inner.right = ix + iw; g_inner.bottom = iy + ih;
    {
        int sv = SaveDC(dc);
        IntersectClipRect(dc, ix, iy, ix + iw, iy + ih);
        ty = iy - (int)(g_rs + 0.5);
        if (g_rtab < 2) {
            ty = draw_bat(dc, ix, ty, iw - U(8), g_rtab);
            ty = draw_bowl(dc, ix, ty, iw - U(8), g_rtab);
            ty = draw_fow(dc, ix, ty, iw - U(8), g_rtab);
        } else ty = draw_awards(dc, ix, ty, iw - U(8));
        RestoreDC(dc, sv);
    }
    endy = ty + (int)(g_rs + 0.5) - iy;
    g_rs_content = endy;
    g_rs_max = endy - ih + U(4);
    if (g_rs_max < 0) g_rs_max = 0;
    if (g_rs_goal > g_rs_max) g_rs_goal = g_rs_max;
    if (g_rs > g_rs_max) g_rs = g_rs_max;
    g_rs_rect.left = ix; g_rs_rect.top = iy + g_oy; g_rs_rect.right = ix + iw; g_rs_rect.bottom = iy + ih + g_oy;
    if (g_rs_max > 0) {
        int th = (int)((double)ih * ih / (ih + g_rs_max)), tp;
        if (th < U(30)) th = U(30);
        tp = iy + (int)((ih - th) * (g_rs / g_rs_max));
        rrect(dc, ix + iw - U(5), tp, ix + iw - U(1), tp + th, U(4), C(K_FAINT), C(K_FAINT), 0);
    }
}

/* ----------------------------------------------------------------- top bar */
static RECT g_sel_rect;
static HINSTANCE g_inst;

static void draw_topbar(HDC dc, const Lay *L)
{
    int pad = L->pad, y0 = (L->top_h - U(38)) / 2, y1 = y0 + U(38), rx = g_w - pad, dw, plw = 0, i;
    const char *tt = "CricLens \xB7 Cricket Analytics";
    const char *sub = "Course: IC103 \xB7 Group 37 \xB7 Standard C99";
    const char *dl = g_theme_goal > 0.5 ? "Light" : "Dark";
    char sel[130], fitted[130];
    int dkw = tw(dc, f_semi, dl) + U(52), upw = tw(dc, f_semi, "Upload Scorecard") + U(54), mlw = tw(dc, f_body, "Match:");
    int brand_w = pad + U(58) + (tw(dc, f_h2, tt) > tw(dc, f_cap, sub) ? tw(dc, f_h2, tt) : tw(dc, f_cap, sub));

    fill(dc, 0, 0, g_w, L->top_h, C(K_CARD));
    for (i = 0; i < 4; i++) alpha_rect(dc, 0, L->top_h + i, g_w, L->top_h + i + 1, C(K_SCRIM), 7 - i * 2);
    line_(dc, 0, L->top_h - 1, g_w, L->top_h - 1, C(K_BORDER), 1, PS_SOLID);
    brand_glyph(dc, pad, (L->top_h - U(44)) / 2, U(44));
    if (g_w >= U(1000)) {
        txtc(dc, pad + U(58), L->top_h / 2 - U(11), tt, C(K_TEXT), f_h2, 0);
        txtc(dc, pad + U(58), L->top_h / 2 + U(13), sub, C(K_MUTED), f_cap, 0);
    } else {
        txtc(dc, pad + U(58), L->top_h / 2, "CricLens", C(K_TEXT), f_h2, 0);
        brand_w = pad + U(58) + tw(dc, f_h2, "CricLens");
    }
    button(dc, ID_UPLOAD, rx - upw, y0, rx, y1, "Upload Scorecard", BS_OUTLINE, IC_PLUS, f_semi);
    rx -= upw + U(14);
    plw = (g_w >= U(1180)) ? tw(dc, f_capb, "Pure C99 Engine") + U(46) : 0;
    dw = rx - brand_w - U(30) - dkw - U(14) - plw - (plw ? U(14) : 0) - mlw - U(10);
    if (dw > U(300)) dw = U(300);
    if (dw < U(150)) dw = U(150);
    {   /* match selector */
        int open = g_dd_open, hot = (g_hot_id == ID_MATCHSEL);
        double hv = g_hv[ID_MATCHSEL];
        g_sel_rect.left = rx - dw; g_sel_rect.top = y0; g_sel_rect.right = rx; g_sel_rect.bottom = y1;
        rrect(dc, rx - dw, y0, rx, y1, U(9), lerp_col(C(K_CARD), C(K_HOVER), hv), (open || hot) ? C(K_ACCENT) : C(K_BORDER), 1);
        snprintf(sel, sizeof sel, "%s", g_ntitles > g_match_index ? g_titles[g_match_index] : "(no match)");
        fit(dc, f_semi, sel, dw - U(52), fitted, sizeof fitted);
        txtc(dc, rx - dw + U(14), (y0 + y1) / 2, fitted, C(K_TEXT), f_semi, 0);
        {
            int cx = rx - U(20), cy = (y0 + y1) / 2 + (open ? -U(1) : U(1));
            int d = open ? -U(3) : U(3);
            line_(dc, cx - U(4), cy - d / 2, cx, cy + d / 2, C(K_MUTED), 2, PS_SOLID);
            line_(dc, cx, cy + d / 2, cx + U(4), cy - d / 2, C(K_MUTED), 2, PS_SOLID);
        }
        reg(ID_MATCHSEL, rx - dw, y0, rx, y1);
    }
    txtc(dc, rx - dw - U(10), (y0 + y1) / 2, "Match:", C(K_MUTED), f_body, 2);
    rx -= dw + U(10) + mlw + U(14);
    if (plw) {
        rrect(dc, rx - plw, y0 + U(2), rx, y1 - U(2), U(8), C(K_GREENBG), lerp_col(C(K_GREENBG), C(K_GREEN), 0.35), 1);
        pulse_dot(dc, rx - plw + U(16), (y0 + y1) / 2, U(4), C(K_GREEN), C(K_GREENBG));
        txtc(dc, rx - plw + U(30), (y0 + y1) / 2, "Pure C99 Engine", C(K_GREENFG), f_capb, 0);
        rx -= plw + U(14);
    }
    button(dc, ID_DARK, rx - dkw, y0, rx, y1, dl, BS_OUTLINE, g_theme_goal > 0.5 ? IC_SUN : IC_MOON, f_semi);
}

static void draw_outer_scrollbar(HDC dc, const Lay *L)
{
    int th, tp, vh = L->view_h;
    if (g_scroll_max <= 0) return;
    th = (int)((double)vh * vh / (vh + g_scroll_max));
    if (th < U(36)) th = U(36);
    tp = L->top_h + (int)((vh - th) * (g_scroll / g_scroll_max));
    rrect(dc, g_w - U(8), tp + U(2), g_w - U(3), tp + th - U(2), U(5), C(K_FAINT), C(K_FAINT), 0);
}

static void draw_error(HDC dc, const Lay *L)
{
    double t, e;
    int x, y, w, h = U(42);
    if (!g_err[0]) return;
    t = since(g_err_t);
    if (t > 12000.0) { g_err[0] = 0; return; }
    e = ease_out(t / 300.0);
    if (t < 320.0) g_busy = 1;
    x = L->pad; w = L->cw; y = L->top_h + U(12) - (int)((1.0 - e) * U(56));
    shadow(dc, x, y, x + w, y + h, U(9), 6);
    rrect(dc, x, y, x + w, y + h, U(9), C(K_REDBG), lerp_col(C(K_REDBG), C(K_RED), 0.45), 1);
    txtc(dc, x + U(16), y + h / 2, g_err, C(K_RED), f_semi, 0);
    button(dc, ID_ERRCLOSE, x + w - U(40), y + U(7), x + w - U(8), y + h - U(7), "x", BS_OUTLINE, IC_NONE, f_semi);
}

static void draw_toast(HDC dc, const Lay *L)
{
    double t;
    int w, h = U(38), x, y;
    if (!g_toast[0]) return;
    t = since(g_toast_t);
    if (t > 3900.0) { g_toast[0] = 0; return; }
    g_busy = 1;
    w = tw(dc, f_semi, g_toast) + U(40);
    {
        double ein = ease_out(t / 300.0), eout = t > 3600.0 ? ease_out((t - 3600.0) / 300.0) : 0.0;
        x = g_w - L->pad - w + (int)((1.0 - ein) * U(40)) + (int)(eout * U(60));
    }
    y = g_h - L->stat_h - U(14) - h;
    shadow(dc, x, y, x + w, y + h, U(10), 9);
    rrect(dc, x, y, x + w, y + h, U(10), C(K_TIP), C(K_TIP), 0);
    circle(dc, x + U(16), y + h / 2, U(4), C(K_GREEN), C(K_GREEN), 0);
    txtc(dc, x + U(28), y + h / 2, g_toast, RGB(255, 255, 255), f_semi, 0);
}

static const char *hint_for(int id)
{
    static const char *const ct[NCTAB] = {"Cumulative runs, over by over  (1)", "Runs per over, first innings  (2)", "Runs per over, second innings  (3)",
                                          "Partnerships, first innings  (4)", "Partnerships, second innings  (5)", "Run rate after each over  (6)"};
    if (id == ID_DARK) return "Switch between light and dark theme  (Ctrl+D)";
    if (id == ID_UPLOAD) return "Load a scorecard file or paste scorecard lines  (Ctrl+O)";
    if (id == ID_MATCHSEL || (id >= ID_MITEM && id < ID_MITEM + MAX_TITLES)) return "Choose which match to analyse  (Left / Right arrows)";
    if (id >= ID_CTAB && id < ID_CTAB + NCTAB) return ct[id - ID_CTAB];
    if (id >= ID_RTAB && id < ID_RTAB + NRTAB) return "Scorecard tables, fall of wickets and awards";
    if (id == ID_DL_SVG) return "Save this chart as an SVG vector file";
    if (id == ID_DL_BMP) return "Save this chart as a 24-bit BMP image  (Ctrl+S)";
    if (id == ID_ABOUT) return "About CricLens and desktop shortcut  (F1)";
    return "Ready";
}
static void draw_statusbar(HDC dc, const Lay *L)
{
    char buf[160], clk[32];
    time_t now = time(NULL);
    struct tm *tmv = localtime(&now);
    int yc = (g_h - L->stat_h) + L->stat_h / 2, lend, cstart, aw;
    fill(dc, 0, g_h - L->stat_h, g_w, g_h, C(K_CARD));
    line_(dc, 0, g_h - L->stat_h, g_w, g_h - L->stat_h, C(K_BORDER), 1, PS_SOLID);
    circle(dc, L->pad + U(5), yc, U(4), C(K_GREEN), C(K_GREEN), 0);
    txtc(dc, L->pad + U(18), yc, hint_for(g_hot_id), C(K_MUTED), f_cap, 0);
    lend = L->pad + U(18) + tw(dc, f_cap, hint_for(g_hot_id));
    snprintf(buf, sizeof buf, "CricLens v1.0  |  Cricket Analytics Suite  |  Match %d of %d", g_match_index + 1, sg5_match_count());
    cstart = g_w / 2 - tw(dc, f_cap, buf) / 2;
    if (cstart > lend + U(30)) txtc(dc, g_w / 2, yc, buf, C(K_FAINT), f_cap, 1);
    aw = tw(dc, f_cap, "About  (F1)") + U(16);
    {
        double hv = g_hv[ID_ABOUT];
        txtc(dc, g_w - L->pad, yc, "About  (F1)", lerp_col(C(K_MUTED), C(K_ACCENT), hv), f_cap, 2);
        reg(ID_ABOUT, g_w - L->pad - aw, g_h - L->stat_h, g_w - L->pad + U(4), g_h);
    }
    if (tmv && strftime(clk, sizeof clk, "%I:%M %p", tmv)) txtc(dc, g_w - L->pad - aw - U(10), yc, clk, C(K_MUTED), f_cap, 2);
}

static void draw_dropdown(HDC dc)
{
    int n = g_ntitles, i, rh = U(38), w, x, y, h, full;
    double a = ease_out(g_dd_a);
    if (a <= 0.01 || n < 1) return;
    w = g_sel_rect.right - g_sel_rect.left;
    {
        int mw = 0;
        for (i = 0; i < n; i++) { int t = tw(dc, f_semi, g_titles[i]); if (t > mw) mw = t; }
        if (mw + U(76) > w) w = mw + U(76);
    }
    if (w < U(300)) w = U(300);
    if (w > g_w - U(30)) w = g_w - U(30);
    x = g_sel_rect.right - w; y = g_sel_rect.bottom + U(6);
    full = n * rh + U(12);
    h = (int)(full * a);
    shadow(dc, x, y, x + w, y + h, U(10), 8);
    rrect(dc, x, y, x + w, y + h, U(10), C(K_CARD), C(K_BORDER), 1);
    {
        int sv = SaveDC(dc);
        IntersectClipRect(dc, x + 1, y + 1, x + w - 1, y + h - 1);
        for (i = 0; i < n; i++) {
            int ry = y + U(6) + i * rh;
            double hv = g_hv[ID_MITEM + i];
            char fb[130];
            if (hv > 0.01) rrect(dc, x + U(6), ry, x + w - U(6), ry + rh - U(2), U(7), lerp_col(C(K_CARD), C(K_HOVER), hv), C(K_CARD), 0);
            fit(dc, f_semi, g_titles[i], w - U(70), fb, sizeof fb);
            txtc(dc, x + U(18), ry + rh / 2 - U(1), fb, i == g_match_index ? C(K_ACCENT) : C(K_TEXT), f_semi, 0);
            if (i == g_match_index) {
                line_(dc, x + w - U(30), ry + rh / 2, x + w - U(26), ry + rh / 2 + U(4), C(K_ACCENT), 2, PS_SOLID);
                line_(dc, x + w - U(26), ry + rh / 2 + U(4), x + w - U(18), ry + rh / 2 - U(4), C(K_ACCENT), 2, PS_SOLID);
            }
            if (g_dd_open && a > 0.9) reg(ID_MITEM + i, x + U(6), ry, x + w - U(6), ry + rh - U(2));
        }
        RestoreDC(dc, sv);
    }
}

/* ------------------------------------------------------------------- modal */
static RECT g_edit_pos;
static void rich_line(HDC dc, int x, int yc, const char *const *seg, int n)
{
    int i;
    for (i = 0; i < n; i++) {
        HFONT f = (i % 2) ? f_mono : f_cap;
        txtc(dc, x, yc, seg[i], C(K_MUTED), f, 0);
        x += tw(dc, f, seg[i]);
    }
}
static const char *base_name(const char *p)
{
    const char *s = strrchr(p, '\\'), *t = strrchr(p, '/');
    if (t && (!s || t > s)) s = t;
    return s ? s + 1 : p;
}
static void draw_modal(HDC dc)
{
    double a = ease_out(g_mod_a);
    int dw = g_w - U(40) < U(480) ? g_w - U(40) : U(480), dh = U(420), dx, dy, b2;
    char fn[200];
    if (a <= 0.005) return;
    g_busy = (g_mod_a > 0.0 && g_mod_a < 1.0) ? 1 : g_busy;
    alpha_rect(dc, 0, 0, g_w, g_h, C(K_SCRIM), (int)(120 * a));
    dx = (g_w - dw) / 2; dy = (g_h - dh) / 2 + (int)((1.0 - a) * U(22));
    if (g_modal) { reg(ID_M_BACK, 0, 0, g_w, g_h); reg(ID_M_PANEL, dx, dy, dx + dw, dy + dh); }
    shadow(dc, dx, dy, dx + dw, dy + dh, U(14), 10);
    rrect(dc, dx, dy, dx + dw, dy + dh, U(14), C(K_CARD), C(K_BORDER), 1);
    txtc(dc, dx + U(24), dy + U(36), "Upload Scorecard", C(K_TEXT), f_h3, 0);
    if (g_modal) button(dc, ID_M_CLOSE, dx + dw - U(24) - U(70), dy + U(19), dx + dw - U(24), dy + U(53), "Close", BS_OUTLINE, IC_NONE, f_semi);
    line_(dc, dx + 1, dy + U(70), dx + dw - 1, dy + U(70), C(K_BORDER), 1, PS_SOLID);

    txtc(dc, dx + U(24), dy + U(94), "Scorecard text file (Component 1 format)", C(K_TEXT), f_semi, 0);
    rrect(dc, dx + U(24), dy + U(112), dx + dw - U(24), dy + U(162), U(10), C(K_CARD2), C(K_CARD2), 0);
    outline_rrect(dc, dx + U(24), dy + U(112), dx + dw - U(24), dy + U(162), U(10), C(K_BORDER), 1, PS_DASH);
    if (g_modal) button(dc, ID_M_CHOOSE, dx + U(38), dy + U(125), dx + U(142), dy + U(149), "Choose File", BS_OUTLINE, IC_NONE, f_cap);
    else rrect(dc, dx + U(38), dy + U(125), dx + U(142), dy + U(149), U(9), C(K_CARD), C(K_BORDER), 1);
    fit(dc, f_body, g_pick[0] ? base_name(g_pick) : "no file selected", dw - U(200), fn, sizeof fn);
    txtc(dc, dx + U(154), dy + U(137), fn, g_pick[0] ? C(K_TEXT) : C(K_MUTED), f_body, 0);

    txtc(dc, dx + U(24), dy + U(186), "Or paste scorecard lines directly", C(K_TEXT), f_semi, 0);
    rrect(dc, dx + U(24), dy + U(204), dx + dw - U(24), dy + U(306), U(10), C(K_CARD2), (GetFocus() == g_edit) ? C(K_ACCENT) : C(K_BORDER), 1);
    g_edit_pos.left = dx + U(34); g_edit_pos.top = dy + U(210); g_edit_pos.right = dx + dw - U(34); g_edit_pos.bottom = dy + U(300);
    {
        static const char *const l1[5] = {"Validated by Component 1 (", "load_match_file", ") and Component 2 (", "match_validate", ")"};
        static const char *const l2[1] = {"before storing."};
        rich_line(dc, dx + U(24), dy + U(328), l1, 5);
        rich_line(dc, dx + U(24), dy + U(346), l2, 1);
    }
    line_(dc, dx + 1, dy + dh - U(66), dx + dw - 1, dy + dh - U(66), C(K_BORDER), 1, PS_SOLID);
    b2 = dx + dw - U(24);
    if (g_modal) {
        button(dc, ID_M_LOAD, b2 - U(112), dy + dh - U(52), b2, dy + dh - U(18), "Load Match", BS_PRIMARY, IC_NONE, f_semi);
        button(dc, ID_M_CANCEL, b2 - U(112) - U(10) - U(84), dy + dh - U(52), b2 - U(122), dy + dh - U(18), "Cancel", BS_OUTLINE, IC_NONE, f_semi);
    }
}

static void draw_tooltip(HDC dc)
{
    int i, wmax = 0, lh = U(22), pad = U(12), W, H, x, y;
    if (g_tip.n < 1 || g_modal || g_dd_open || g_mx < 0) return;
    for (i = 0; i < g_tip.n; i++) { int w = tw(dc, i == 0 ? f_bold : f_body, g_tip.text[i]); if (w > wmax) wmax = w; }
    W = wmax + 2 * pad; H = g_tip.n * lh + 2 * pad - U(4);
    x = g_mx + U(18); y = g_my + U(18);
    if (x + W > g_w - U(10)) x = g_mx - W - U(18);
    if (x < U(8)) x = U(8);
    if (y + H > g_h - U(36)) y = g_h - U(36) - H;
    shadow(dc, x, y, x + W, y + H, U(10), 9);
    rrect(dc, x, y, x + W, y + H, U(10), C(K_TIP), C(K_TIP), 0);
    for (i = 0; i < g_tip.n; i++)
        txtc(dc, x + pad, y + pad + lh * i + lh / 2 - U(2), g_tip.text[i], g_tip.col[i], i == 0 ? f_bold : f_body, 0);
}

/* ------------------------------------------------------------------ splash */
static void draw_splash(HDC dc)
{
    double el = since(g_t_start), t = clampd(el / SPLASH_MS, 0, 1);
    int cx = g_w / 2, cy = g_h / 2 - U(50), r, dim, bw = U(380), by = cy + U(205), k;
    COLORREF bg = RGB(11, 18, 44), gold = RGB(246, 196, 83);
    const char *stage = t < 0.3 ? "Initialising statistics engine..." : (t < 0.6 ? "Parsing match scorecards..." : (t < 0.88 ? "Building charts..." : "Ready"));
    g_busy = 1;
    vgrad(dc, 0, 0, g_w, g_h, RGB(8, 14, 36), RGB(16, 28, 64));
    for (k = 0; k < 2; k++) {
        double ph = fmod(el / 1400.0 + k * 0.5, 1.0);
        r = U(96) + (int)(ph * U(130));
        ring(dc, cx, cy, r, lerp_col(gold, bg, clampd(ph * 1.15, 0, 1)), 2);
    }
    dim = (int)(U(190) * (0.5 + 0.5 * ease_back(el / 700.0)));
    blit_rgba(dc, g_logo_splash, 256, cx - dim / 2, cy - dim / 2, dim);
    txtc(dc, cx, cy + U(140), "CricLens", lerp_col(bg, gold, clampd((el - 350) / 600.0, 0, 1)), f_score, 1);
    SetTextCharacterExtra(dc, U(3));
    txtc(dc, cx, cy + U(176), "CRICKET ANALYTICS DESKTOP", lerp_col(bg, RGB(240, 240, 250), clampd((el - 750) / 500.0, 0, 1)), f_capb, 1);
    SetTextCharacterExtra(dc, 0);
    rrect(dc, cx - bw / 2, by, cx + bw / 2, by + U(8), U(8), RGB(26, 38, 80), RGB(26, 38, 80), 0);
    r = (int)(bw * ease_out(t));
    if (r > U(8)) rrect(dc, cx - bw / 2, by, cx - bw / 2 + r, by + U(8), U(8), gold, gold, 0);
    txtc(dc, cx, by + U(28), stage, RGB(150, 160, 200), f_cap, 1);
}

/* -------------------------------------------------------------------- scene */
static void set_oy(HDC dc, int v) { g_oy = v; SetViewportOrgEx(dc, 0, v, NULL); }
static void draw_content(HDC dc, const Lay *L, int base)
{
    int dy = (int)((1.0 - prog_of(g_t_enter, 650, 0)) * U(26));
    set_oy(dc, base + dy);
    draw_match_card(dc, L->pad, L->mc_y, L->cw, L->mc_h);
    dy = (int)((1.0 - prog_of(g_t_enter, 650, 120)) * U(26));
    set_oy(dc, base + dy);
    draw_chart_card(dc, L->pad, L->pn_y, L->lw, L->pn_h);
    dy = (int)((1.0 - prog_of(g_t_enter, 650, 240)) * U(26));
    set_oy(dc, base + dy);
    draw_score_card(dc, L->rx, L->pn_y, L->rw, L->pn_h);
    set_oy(dc, base);
}
static void draw_scene(HDC dc)
{
    Lay L = lay();
    int sv, base;
    g_busy = 0; g_idle = 0; g_ntg = 0; g_tip.n = 0; g_oy = 0; g_clip_on = 0;
    fill(dc, 0, 0, g_w, g_h, C(K_BG));
    if (g_splash) { draw_splash(dc); return; }
    g_scroll_max = L.total - L.view_h;
    if (g_scroll_max < 0) g_scroll_max = 0;
    if (g_scroll_goal > g_scroll_max) g_scroll_goal = g_scroll_max;
    if (g_scroll > g_scroll_max) g_scroll = g_scroll_max;
    sv = SaveDC(dc);
    IntersectClipRect(dc, 0, L.top_h, g_w, g_h - L.stat_h);
    g_clipwin.left = 0; g_clipwin.top = L.top_h; g_clipwin.right = g_w; g_clipwin.bottom = g_h - L.stat_h;
    g_clip_on = 1;
    base = L.top_h - (int)(g_scroll + 0.5);
    g_cmx = g_mx; g_cmy = g_my - base;
    g_hover_content = g_mx >= 0 && g_my >= L.top_h && g_my < g_h - L.stat_h && !g_modal && !g_dd_open && g_mod_a < 0.01;
    draw_content(dc, &L, base);
    RestoreDC(dc, sv);
    g_oy = 0; g_clip_on = 0;
    draw_topbar(dc, &L);
    draw_outer_scrollbar(dc, &L);
    draw_error(dc, &L);
    draw_statusbar(dc, &L);
    draw_toast(dc, &L);
    draw_dropdown(dc);
    draw_modal(dc);
    draw_tooltip(dc);
}

/* ----------------------------------------------------------------- actions */
static void select_view(View v) { g_view = v; g_t_chart = GetTickCount(); g_plot_valid = 0; }
static void select_rtab(int t) { g_rtab = t; g_t_rtab = GetTickCount(); g_rs = g_rs_goal = 0; }
static void set_match(int idx)
{
    if (idx == g_match_index || idx < 0 || idx >= sg5_match_count()) return;
    g_match_index = idx;
    load_current();
}
static void change_match(int delta)
{
    int n = sg5_match_count();
    if (n < 1) return;
    set_match((g_match_index + delta + n) % n);
}
static void toggle_theme(void)
{
    g_theme_goal = g_theme_goal > 0.5 ? 0.0 : 1.0;
    cl_apply_titlebar(g_hwnd, g_theme_goal > 0.5);
    toast(g_theme_goal > 0.5 ? "Dark theme on" : "Light theme on");
}
static void open_modal(void)
{
    g_modal = 1; g_dd_open = 0; g_pick[0] = 0;
    SetWindowTextA(g_edit, "");
}
static void close_modal(void)
{
    g_modal = 0;
    ShowWindow(g_edit, SW_HIDE);
    SetFocus(g_hwnd);
}
static void choose_file(HWND w)
{
    OPENFILENAMEA ofn;
    char path[MAX_PATH] = "";
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = "Scorecard text (*.txt;*.csv)\0*.txt;*.csv\0All files (*.*)\0*.*\0";
    ofn.lpstrFile = path; ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameA(&ofn)) {
        snprintf(g_pick, sizeof g_pick, "%s", path);
        SetWindowTextA(g_edit, "");
    }
}
static void do_load(void)
{
    char err[256] = "", path[MAX_PATH] = "", tmp[MAX_PATH] = "", msg[220];
    int len = GetWindowTextLengthA(g_edit), usetmp = 0, ok;
    if (len > 0) {
        char *text = (char *)malloc((size_t)len + 2);
        FILE *f;
        if (!text) return;
        GetWindowTextA(g_edit, text, len + 1);
        GetTempPathA(MAX_PATH, tmp);
        GetTempFileNameA(tmp, "CLS", 0, path);
        f = fopen(path, "wb");
        if (f) {
            const char *s;
            for (s = text; *s; s++) if (*s != '\r') fputc(*s, f);        /* normalise line endings */
            fclose(f);
            usetmp = 1;
        }
        free(text);
        if (!usetmp) { set_error("Could not create a temporary file for the pasted scorecard."); return; }
    } else if (g_pick[0]) snprintf(path, sizeof path, "%s", g_pick);
    else { set_error("Choose a scorecard file or paste scorecard lines first."); return; }
    ok = sg5_add_from_file(path, err, sizeof err);
    if (usetmp) DeleteFileA(path);
    if (ok) {
        g_err[0] = 0;
        g_match_index = sg5_match_count() - 1;
        load_current();
        close_modal();
        snprintf(msg, sizeof msg, "Match loaded: %s vs %s", g_match.in[0].team, g_match.in[1].team);
        toast(msg);
    } else set_error(err[0] ? err : "The scorecard could not be read.");
}
static void svg_runrate(FILE *f)
{
    int w = 760, h = 420, k, i, n = 1;
    double mx = 4.0;
    for (k = 0; k < 2; k++) {
        const InningsPlot *p = &g_match.in[k];
        if (p->overs > n) n = p->overs;
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++) if (rr_val(p, i) > mx) mx = rr_val(p, i);
    }
    mx = ceil(mx) + 1;
    fprintf(f, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\">\n", w, h, w, h);
    fprintf(f, "<rect width=\"%d\" height=\"%d\" fill=\"#ffffff\"/>\n", w, h);
    fprintf(f, "<text x=\"%d\" y=\"30\" font-family=\"sans-serif\" font-size=\"18\" font-weight=\"bold\">RUN RATE: %s vs %s</text>\n", 60, g_match.in[0].team, g_match.in[1].team);
    fprintf(f, "<line x1=\"60\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#94a3b8\"/><line x1=\"60\" y1=\"60\" x2=\"60\" y2=\"%d\" stroke=\"#94a3b8\"/>\n", h - 50, w - 30, h - 50, h - 50);
    for (k = 0; k < 2; k++) {
        const InningsPlot *p = &g_match.in[k];
        fprintf(f, "<polyline fill=\"none\" stroke=\"%s\" stroke-width=\"2.5\" points=\"", k ? "#b91c26" : "#2454a6");
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++)
            fprintf(f, "%.1f,%.1f ", 60.0 + (w - 90.0) * i / n, (h - 50.0) - (h - 110.0) * rr_val(p, i) / mx);
        fprintf(f, "\"/>\n<text x=\"%d\" y=\"%d\" font-family=\"sans-serif\" font-size=\"13\" fill=\"%s\">%s</text>\n", 420, 30 + k * 18, k ? "#b91c26" : "#2454a6", p->team);
    }
    fprintf(f, "</svg>\n");
}
static void save_dialog_path(HWND w, const char *defname, const char *filter, const char *ext, char *path, size_t n, int *ok)
{
    OPENFILENAMEA ofn;
    snprintf(path, n, "%s", defname);
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = filter; ofn.lpstrFile = path; ofn.nMaxFile = (DWORD)n; ofn.lpstrDefExt = ext;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    *ok = GetSaveFileNameA(&ofn);
}
static void do_svg(HWND w)
{
    static const char *const names[VIEW_COUNT] = {"worm", "manhattan1", "manhattan2", "partnerships1", "partnerships2", "runrate"};
    char path[MAX_PATH], def[80], msg[MAX_PATH + 40];
    int ok;
    FILE *f;
    snprintf(def, sizeof def, "CricLens_%s.svg", names[g_view]);
    save_dialog_path(w, def, "SVG vector image (*.svg)\0*.svg\0", "svg", path, sizeof path, &ok);
    if (!ok) return;
    f = fopen(path, "w");
    if (!f) { set_error("The SVG file could not be written."); return; }
    switch (g_view) {
    case VIEW_WORM: sg5_worm_svg(f, &g_match); break;
    case VIEW_MAN1: sg5_manhattan_svg(f, &g_match.in[0], sg5_max_over_runs(&g_match)); break;
    case VIEW_MAN2: sg5_manhattan_svg(f, &g_match.in[1], sg5_max_over_runs(&g_match)); break;
    case VIEW_PS1: sg5_partnership_svg(f, &g_match.in[0]); break;
    case VIEW_PS2: sg5_partnership_svg(f, &g_match.in[1]); break;
    default: svg_runrate(f); break;
    }
    fclose(f);
    snprintf(msg, sizeof msg, "SVG saved: %s", base_name(path));
    toast(msg);
}
static int export_region_bmp(const char *path, RECT rc)
{
    int w, h, ok = 0;
    size_t stride;
    unsigned char *px;
    BITMAPINFO bi;
    BITMAPFILEHEADER bf;
    HDC sd, td;
    HBITMAP bm;
    HGDIOBJ old;
    FILE *f;
    if (rc.left < 0) rc.left = 0;
    if (rc.top < 0) rc.top = 0;
    if (rc.right > g_w) rc.right = g_w;
    if (rc.bottom > g_h) rc.bottom = g_h;
    w = rc.right - rc.left; h = rc.bottom - rc.top;
    if (w < 1 || h < 1 || !g_mem) return 0;
    stride = ((size_t)w * 3 + 3) & ~(size_t)3;
    px = (unsigned char *)malloc(stride * (size_t)h);
    if (!px) return 0;
    sd = GetDC(NULL); td = CreateCompatibleDC(sd); bm = CreateCompatibleBitmap(sd, w, h);
    old = SelectObject(td, bm);
    BitBlt(td, 0, 0, w, h, g_mem, rc.left, rc.top, SRCCOPY);
    SelectObject(td, old);
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = h;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 24; bi.bmiHeader.biCompression = BI_RGB;
    ok = GetDIBits(sd, bm, 0, (UINT)h, px, &bi, DIB_RGB_COLORS) == h;
    DeleteObject(bm); DeleteDC(td); ReleaseDC(NULL, sd);
    if (ok) {
        memset(&bf, 0, sizeof bf);
        bf.bfType = 0x4D42;
        bf.bfOffBits = (DWORD)(sizeof bf + sizeof bi.bmiHeader);
        bf.bfSize = (DWORD)(bf.bfOffBits + stride * (size_t)h);
        f = fopen(path, "wb");
        ok = f != NULL;
        if (f) {
            fwrite(&bf, sizeof bf, 1, f);
            fwrite(&bi.bmiHeader, sizeof bi.bmiHeader, 1, f);
            fwrite(px, 1, stride * (size_t)h, f);
            fclose(f);
        }
    }
    free(px);
    return ok;
}
static void do_bmp(HWND w)
{
    static const char *const names[VIEW_COUNT] = {"worm", "manhattan1", "manhattan2", "partnerships1", "partnerships2", "runrate"};
    char path[MAX_PATH], def[80], msg[MAX_PATH + 40];
    int ok, sx = g_mx, sy = g_my, sh = g_hot_id;
    snprintf(def, sizeof def, "CricLens_%s.bmp", names[g_view]);
    save_dialog_path(w, def, "Bitmap image (*.bmp)\0*.bmp\0", "bmp", path, sizeof path, &ok);
    if (!ok) return;
    g_mx = g_my = -1; g_hot_id = 0;                     /* capture without hover effects */
    draw_scene(g_mem);
    g_mx = sx; g_my = sy; g_hot_id = sh;
    if (export_region_bmp(path, g_chart_win)) { snprintf(msg, sizeof msg, "BMP saved: %s", base_name(path)); toast(msg); }
    else set_error("The BMP image could not be saved.");
}
static void do_about(HWND w)
{
    int r = MessageBoxA(w,
        "CricLens - Cricket Analytics Desktop  v1.0\n\n"
        "Written entirely in C (Win32 API + GDI).\n"
        "Integrated scorecard parser, match storage, statistics engine and chart renderer.\n\n"
        "Keyboard:  Left/Right = match   1-6 = charts   Ctrl+O = upload\n"
        "                  Ctrl+S = save chart image   Ctrl+D = dark/light   F11 = full screen\n\n"
        "Create a Desktop shortcut now?",
        "About CricLens", MB_YESNO | MB_ICONINFORMATION);
    if (r == IDYES) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        toast(msg);
    }
}
static void do_id(HWND w, int id)
{
    if (id == ID_DARK) toggle_theme();
    else if (id == ID_UPLOAD) open_modal();
    else if (id == ID_MATCHSEL) g_dd_open = !g_dd_open;
    else if (id >= ID_MITEM && id < ID_MITEM + MAX_TITLES) { set_match(id - ID_MITEM); g_dd_open = 0; }
    else if (id >= ID_CTAB && id < ID_CTAB + NCTAB) select_view((View)(id - ID_CTAB));
    else if (id >= ID_RTAB && id < ID_RTAB + NRTAB) select_rtab(id - ID_RTAB);
    else if (id == ID_DL_SVG) do_svg(w);
    else if (id == ID_DL_BMP) do_bmp(w);
    else if (id == ID_ERRCLOSE) g_err[0] = 0;
    else if (id == ID_ABOUT) do_about(w);
    else if (id == ID_M_CLOSE || id == ID_M_CANCEL || id == ID_M_BACK) close_modal();
    else if (id == ID_M_CHOOSE) choose_file(w);
    else if (id == ID_M_LOAD) do_load();
}
static void toggle_fullscreen(HWND w)
{
    DWORD st = (DWORD)GetWindowLong(w, GWL_STYLE);
    if (!g_full) {
        MONITORINFO mi;
        memset(&mi, 0, sizeof mi);
        mi.cbSize = sizeof mi;
        g_wp.length = sizeof g_wp;
        if (GetWindowPlacement(w, &g_wp) && GetMonitorInfo(MonitorFromWindow(w, MONITOR_DEFAULTTOPRIMARY), &mi)) {
            SetWindowLong(w, GWL_STYLE, (LONG)(st & ~WS_OVERLAPPEDWINDOW));
            SetWindowPos(w, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top,
                         mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top,
                         SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
            g_full = 1;
        }
    } else {
        SetWindowLong(w, GWL_STYLE, (LONG)(st | WS_OVERLAPPEDWINDOW));
        SetWindowPlacement(w, &g_wp);
        SetWindowPos(w, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        g_full = 0;
    }
}
static void end_splash(void) { g_splash = 0; g_t_enter = GetTickCount(); g_t_match = g_t_chart = g_t_rtab = g_t_enter; }

static void resize_backbuffer(HWND w, int cw, int ch)
{
    HDC sdc;
    if (cw < 1 || ch < 1) return;
    if (g_mem) { SelectObject(g_mem, g_memold); DeleteObject(g_membmp); DeleteDC(g_mem); }
    sdc = GetDC(w);
    g_mem = CreateCompatibleDC(sdc);
    g_membmp = CreateCompatibleBitmap(sdc, cw, ch);
    g_memold = SelectObject(g_mem, g_membmp);
    ReleaseDC(w, sdc);
    g_w = cw; g_h = ch;
    g_plot_valid = 0;
}

/* One animation step (about 60 times a second). Returns non-zero when another frame is needed. */
static int step_anims(void)
{
    DWORD now = GetTickCount();
    int i, need = 0;
    double d, k;
    g_dt = clampd((double)(now - g_t_last) / 1000.0, 0.001, 0.1);
    g_t_last = now;
    for (i = 0; i < ID_MAX; i++) {
        double tgt = (i == g_hot_id && g_hot_id != 0) ? 1.0 : 0.0;
        if (fabs(g_hv[i] - tgt) > 0.003) { g_hv[i] += (tgt - g_hv[i]) * (1.0 - exp(-g_dt * 16.0)); need = 1; }
        else g_hv[i] = tgt;
    }
    if (g_theme_t != g_theme_goal) {
        d = g_dt * 3.4;
        if (g_theme_t < g_theme_goal) { g_theme_t += d; if (g_theme_t > g_theme_goal) g_theme_t = g_theme_goal; }
        else { g_theme_t -= d; if (g_theme_t < g_theme_goal) g_theme_t = g_theme_goal; }
        theme_update();
        g_plot_valid = 0;
        need = 1;
    }
    d = (g_modal ? 1.0 : 0.0) - g_mod_a;
    if (fabs(d) > 0.002) { g_mod_a += d * (1.0 - exp(-g_dt * 14.0)); need = 1; } else g_mod_a = g_modal ? 1.0 : 0.0;
    d = (g_dd_open ? 1.0 : 0.0) - g_dd_a;
    if (fabs(d) > 0.002) { g_dd_a += d * (1.0 - exp(-g_dt * 18.0)); need = 1; } else g_dd_a = g_dd_open ? 1.0 : 0.0;
    k = 1.0 - exp(-g_dt * 16.0);
    if (fabs(g_scroll - g_scroll_goal) > 0.4) { g_scroll += (g_scroll_goal - g_scroll) * k; need = 1; } else g_scroll = g_scroll_goal;
    if (fabs(g_rs - g_rs_goal) > 0.4) { g_rs += (g_rs_goal - g_rs) * k; need = 1; } else g_rs = g_rs_goal;
    /* the multi-line edit box is only visible once the dialog has finished opening */
    if (g_edit) {
        int want = g_modal && g_mod_a > 0.97;
        if (want) {
            if (!IsWindowVisible(g_edit)) { ShowWindow(g_edit, SW_SHOW); SetFocus(g_edit); }
            SetWindowPos(g_edit, NULL, g_edit_pos.left, g_edit_pos.top, g_edit_pos.right - g_edit_pos.left,
                         g_edit_pos.bottom - g_edit_pos.top, SWP_NOZORDER | SWP_NOACTIVATE);
        } else if (IsWindowVisible(g_edit)) ShowWindow(g_edit, SW_HIDE);
    }
    return need;
}

/* ------------------------------------------------------- edit box subclass */
static LRESULT CALLBACK edit_proc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    LRESULT r;
    int ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    if (m == WM_KEYDOWN && wp == VK_RETURN && ctrl) { PostMessage(GetParent(h), WM_CL_LOAD, 0, 0); return 0; }
    if (m == WM_KEYDOWN && wp == VK_ESCAPE) { PostMessage(GetParent(h), WM_CL_CLOSE, 0, 0); return 0; }
    if (m == WM_CHAR && wp == VK_RETURN && ctrl) return 0;
    r = CallWindowProcA(g_edit_old, h, m, wp, lp);
    if (m == WM_PAINT && GetWindowTextLengthA(h) == 0) {          /* placeholder text */
        HDC dc = GetDC(h);
        RECT rc;
        GetClientRect(h, &rc);
        rc.left += 2; rc.top += 1;
        SelectObject(dc, f_mono);
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, C(K_FAINT));
        DrawTextA(dc, "MATCH,ID,Team A,Team B,Venue,2026-11-18\nINNINGS,1,Team A,42,2,18\nBATTER,1,Player,25,12,2,1\n"
                      "BOWLER,2,Bowler,12,12,22\nOVER,1,1,10,0\nFOW,1,1,25,2.4,Player", -1, &rc, DT_LEFT | DT_TOP | DT_NOPREFIX);
        ReleaseDC(h, dc);
    }
    if (m == WM_CHAR || m == WM_PASTE || m == WM_CUT || m == WM_CLEAR || m == WM_UNDO || m == WM_KEYUP) InvalidateRect(h, NULL, TRUE);
    return r;
}

/* ------------------------------------------------------------ window proc */
static LRESULT CALLBACK window_proc(HWND w, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE:
        g_hwnd = w;
        make_fonts();
        theme_update();
        g_icon_big = cl_make_hicon(GetSystemMetrics(SM_CXICON) > 0 ? GetSystemMetrics(SM_CXICON) : 32);
        g_icon_small = cl_make_hicon(GetSystemMetrics(SM_CXSMICON) > 0 ? GetSystemMetrics(SM_CXSMICON) : 16);
        if (g_icon_big) SendMessage(w, WM_SETICON, ICON_BIG, (LPARAM)g_icon_big);
        if (g_icon_small) SendMessage(w, WM_SETICON, ICON_SMALL, (LPARAM)g_icon_small);
        g_logo_splash = (unsigned char *)malloc(256 * 256 * 4);
        if (g_logo_splash) { cl_render_icon(g_logo_splash, 256); cl_flatten_icon(g_logo_splash, 256, RGB(11, 18, 44)); }
        g_edit = CreateWindowExA(0, "EDIT", "", WS_CHILD | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN,
                                 0, 0, 10, 10, w, (HMENU)(UINT_PTR)1001, g_inst, NULL);
        if (g_edit) {
            SendMessage(g_edit, WM_SETFONT, (WPARAM)f_mono, TRUE);
            SendMessage(g_edit, EM_LIMITTEXT, 300000, 0);
            g_edit_old = (WNDPROC)SetWindowLongPtrA(g_edit, GWLP_WNDPROC, (LONG_PTR)edit_proc);
        }
        g_t_start = g_t_last = GetTickCount();
        SetTimer(w, 1, 16, NULL);
        return 0;
    case WM_SIZE:
        if (wp != SIZE_MINIMIZED) { resize_backbuffer(w, LOWORD(lp), HIWORD(lp)); InvalidateRect(w, NULL, FALSE); }
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO *mm = (MINMAXINFO *)lp;
        RECT r;
        r.left = 0; r.top = 0; r.right = U(1080); r.bottom = U(680);
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        mm->ptMinTrackSize.x = r.right - r.left;
        mm->ptMinTrackSize.y = r.bottom - r.top;
        return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)wp;
        COLORREF bgc = C(K_CARD2);
        SetTextColor(hdc, C(K_TEXT));
        SetBkColor(hdc, bgc);
        if (!g_edit_brush || g_edit_brush_col != bgc) {
            if (g_edit_brush) DeleteObject(g_edit_brush);
            g_edit_brush = CreateSolidBrush(bgc);
            g_edit_brush_col = bgc;
        }
        return (LRESULT)g_edit_brush;
    }
    case WM_CL_LOAD: if (g_modal) do_load(); return 0;
    case WM_CL_CLOSE: if (g_modal) close_modal(); return 0;
    case WM_TIMER: {
        int need = step_anims();
        static unsigned tick;
        tick++;
        if (g_splash && GetTickCount() - g_t_start >= SPLASH_MS) end_splash();
        if (need || g_busy || g_splash || (g_idle && (tick & 1))) InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_MOUSEMOVE:
        g_mx = (short)LOWORD(lp); g_my = (short)HIWORD(lp);
        if (!g_tracking) {
            TRACKMOUSEEVENT te;
            te.cbSize = sizeof te; te.dwFlags = TME_LEAVE; te.hwndTrack = w; te.dwHoverTime = 0;
            TrackMouseEvent(&te);
            g_tracking = 1;
        }
        g_hot_id = g_splash ? 0 : hit_id(g_mx, g_my);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_MOUSELEAVE:
        g_tracking = 0; g_mx = g_my = -1; g_hot_id = 0;
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT && g_hot_id != 0 && !g_splash) { SetCursor(LoadCursor(NULL, IDC_HAND)); return TRUE; }
        break;
    case WM_MOUSEWHEEL: {
        int delta = (short)HIWORD(wp);
        POINT pt;
        pt.x = (short)LOWORD(lp); pt.y = (short)HIWORD(lp);
        ScreenToClient(w, &pt);
        if (g_splash || g_modal || g_dd_open) return 0;
        if (g_rs_max > 0 && PtInRect(&g_rs_rect, pt)) g_rs_goal = clampd(g_rs_goal - delta / 120.0 * U(70), 0, g_rs_max);
        else g_scroll_goal = clampd(g_scroll_goal - delta / 120.0 * U(80), 0, g_scroll_max);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_LBUTTONDOWN:
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        g_down_id = hit_id((short)LOWORD(lp), (short)HIWORD(lp));
        if (g_down_id == 0 && g_dd_open) g_dd_open = 0;
        if (g_down_id != 0) SetCapture(w);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_LBUTTONUP: {
        int id = hit_id((short)LOWORD(lp), (short)HIWORD(lp)), was = g_down_id;
        if (GetCapture() == w) ReleaseCapture();
        g_down_id = 0;
        if (was != 0 && id == was) do_id(w, id);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_KEYDOWN: {
        int ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0, shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        if (g_modal) { if (wp == VK_ESCAPE) close_modal(); return 0; }
        if (g_dd_open) { if (wp == VK_ESCAPE) g_dd_open = 0; return 0; }
        if (wp == VK_LEFT) change_match(-1);
        else if (wp == VK_RIGHT) change_match(1);
        else if (wp >= '1' && wp <= '6') select_view((View)(wp - '1'));
        else if (wp == VK_TAB) select_view((View)(((int)g_view + (shift ? VIEW_COUNT - 1 : 1)) % VIEW_COUNT));
        else if (wp == VK_DOWN) g_scroll_goal = clampd(g_scroll_goal + U(60), 0, g_scroll_max);
        else if (wp == VK_UP) g_scroll_goal = clampd(g_scroll_goal - U(60), 0, g_scroll_max);
        else if (wp == VK_NEXT) g_scroll_goal = clampd(g_scroll_goal + U(400), 0, g_scroll_max);
        else if (wp == VK_PRIOR) g_scroll_goal = clampd(g_scroll_goal - U(400), 0, g_scroll_max);
        else if (wp == VK_HOME) g_scroll_goal = 0;
        else if (wp == VK_END) g_scroll_goal = g_scroll_max;
        else if (wp == VK_F11) toggle_fullscreen(w);
        else if (wp == VK_ESCAPE) { if (g_full) toggle_fullscreen(w); else g_err[0] = 0; }
        else if (wp == VK_F1) do_about(w);
        else if (ctrl && wp == 'O') open_modal();
        else if (ctrl && wp == 'S') do_bmp(w);
        else if (ctrl && wp == 'D') toggle_theme();
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(w, &ps);
        if (g_mem) {
            draw_scene(g_mem);
            BitBlt(dc, 0, 0, g_w, g_h, g_mem, 0, 0, SRCCOPY);
        }
        EndPaint(w, &ps);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(w, 1);
        if (g_mem) { SelectObject(g_mem, g_memold); DeleteObject(g_membmp); DeleteDC(g_mem); g_mem = NULL; }
        if (g_pxdc) { SelectObject(g_pxdc, g_pxold); DeleteObject(g_pxbmp); DeleteDC(g_pxdc); g_pxdc = NULL; }
        if (g_plot) DeleteObject(g_plot);
        if (g_edit_brush) DeleteObject(g_edit_brush);
        kill_all_fonts();
        if (g_icon_big) DestroyIcon(g_icon_big);
        if (g_icon_small) DestroyIcon(g_icon_small);
        free(g_logo_splash);
        sg5_shutdown();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(w, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE prev, LPSTR cmd, int show)
{
    WNDCLASSA wc;
    HWND w;
    MSG m;
    HDC sd;
    RECT wa, r;
    int cw, ch, ww, wh;
    (void)prev;

    /* "CricLens.exe --install" creates the Desktop / Start Menu shortcuts and exits. */
    if (cmd && strstr(cmd, "--install")) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        if (!strstr(cmd, "--quiet")) MessageBoxA(NULL, msg, "CricLens setup", MB_OK | MB_ICONINFORMATION);
        return 0;
    }
    g_inst = instance;
    cl_enable_dpi_awareness();
    sd = GetDC(NULL);
    g_s = GetDeviceCaps(sd, LOGPIXELSX) / 96.0;
    ReleaseDC(NULL, sd);
    if (g_s < 1.0) g_s = 1.0;
    theme_update();
    if (!sg5_init()) { MessageBoxA(NULL, "Could not initialise CricLens match data.", "CricLens", MB_OK | MB_ICONERROR); return 1; }
    load_current();

    ZeroMemory(&wc, sizeof wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = window_proc; wc.hInstance = instance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW); wc.hbrBackground = NULL; wc.lpszClassName = "CricLensNativeWindow";
    wc.hIcon = cl_make_hicon(32);
    if (!RegisterClassA(&wc)) { sg5_shutdown(); return 1; }

    SystemParametersInfoA(SPI_GETWORKAREA, 0, &wa, 0);
    cw = U(1280); ch = U(840);
    if (cw > wa.right - wa.left - U(40)) cw = wa.right - wa.left - U(40);
    if (ch > wa.bottom - wa.top - U(70)) ch = wa.bottom - wa.top - U(70);
    r.left = 0; r.top = 0; r.right = cw; r.bottom = ch;
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    ww = r.right - r.left; wh = r.bottom - r.top;
    w = CreateWindowExA(0, wc.lpszClassName, "CricLens - Cricket Analytics Desktop", WS_OVERLAPPEDWINDOW,
                        wa.left + (wa.right - wa.left - ww) / 2, wa.top + (wa.bottom - wa.top - wh) / 2, ww, wh,
                        NULL, NULL, instance, NULL);
    if (!w) { sg5_shutdown(); return 1; }
    cl_apply_titlebar(w, 0);
    ShowWindow(w, show);
    UpdateWindow(w);
    while (GetMessageA(&m, NULL, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageA(&m); }
    return (int)m.wParam;
}

