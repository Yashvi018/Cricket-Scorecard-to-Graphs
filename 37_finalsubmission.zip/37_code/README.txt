CricLens — 5 Historical Match Scorecard Inputs

HOW TO USE
1. Extract this ZIP.
2. Open CricLens.
3. Choose Upload Scorecard / Import Scorecard.
4. Select any .txt file in this folder.
5. Select the imported match in the match selector.

FILES
- WC2023_FINAL.txt — India v Australia, 2023 World Cup Final
- WC2011_FINAL.txt — Sri Lanka v India, 2011 World Cup Final
- WC2003_FINAL.txt — Australia v India, 2003 World Cup Final
- WC2007_FINAL.txt — Australia v Sri Lanka, 2007 World Cup Final
- WC2019_FINAL.txt — New Zealand v England, 2019 World Cup Final

IMPORTANT DATA NOTE
The scorecard batting figures, match totals, and Fall of Wickets are based on published historical scorecards. The 2007 final uses the archived Cricinfo scorecard.
The OVER run allocations are illustrative distributions that add up to each innings total; they are NOT official
over-by-over run figures. They are included so CricLens can draw a complete Worm/Manhattan progression.
The OVER wicket counts are placed in the correct over based on the listed Fall of Wickets, so the wicket markers
can be tested. Do not use these illustrative over-run series as official historical statistics.

CRICLENS FORMAT
MATCH,id,team1,team2,venue,date
INNINGS,n,batting_team,total_runs,wickets,legal_balls
BATTER,n,name,runs,balls,fours,sixes
BOWLER,n,name,wickets,balls_bowled,runs_conceded
OVER,n,over_number,runs,wickets
FOW,n,wicket_number,team_score,stored_over_number,ball_in_over,player_out

WHY WICKETS NEED TWO RECORDS
- FOW rows populate the Fall of Wickets scorecard table.
- OVER rows populate wicket markers on the Manhattan/over charts.
- So a scorecard needs BOTH. If an OVER row has 0 wickets for every over, the chart will show runs but no wicket markers even when FOW rows exist.
