# CricLens — Integrated C Project

This folder combines the five CricLens subgroups and uses the improved Component 3 statistics engine.

## Components

- **Component 1 — Input and parsing** (`component1/`): parses scorecard files and loads match data.
- **Component 2 — Data model and storage** (`component2/`): shared `Match`/`Innings`/`Player` structures, validation, and storage.
- **Component 3 — Statistics** (`component3/stats_engine.c`, `stats_engine.h`): improved statistics calculations, validation, innings summaries, required run rate, and graph-ready series. Its `match_model.h` is kept identical to Component 2's shared header.
- **Component 4 — Graph rendering** (`component4/`): ASCII, SVG, and BMP chart rendering.
- **Component 5 — Charts, menu, and awards** (`component5/`): sample matches, visualizations, partnerships, and awards.

## Integration design

Component 2's `match_model.h` is the canonical shared data model. Component 3's improved API is retained unchanged. Component 5 still calls the earlier statistics API, so `component3/stats_legacy_compat.c` and `stats_legacy_compat.h` provide a compatibility layer for those older calls. This lets the enhanced Component 3 coexist with the existing Components 4 and 5 without changing their public interfaces.

## Requirements

- GCC or another C99-compatible compiler (on Windows: MSYS2 UCRT64 GCC)
- Standard C math library (`-lm`)

No build scripts or other tools are needed; everything is compiled with one `gcc` command.

## Build and run (Windows desktop application)

From this folder, in an MSYS2 UCRT64 or Command Prompt window where `gcc` works:

```sh
gcc -std=gnu99 -O2 -Wall -Wextra -Icomponent1 -Icomponent2 -Icomponent3 -Icomponent4 -Icomponent5 component1/component1_input_parser.c component1/component1_match_loader.c component2/match_store.c component2/match_validate.c component3/stats_engine.c component3/stats_legacy_compat.c component4/chart_render.c component5/sg5_adapter.c component5/sg5_awards.c component5/sg5_manhattan.c component5/sg5_partnership.c component5/sg5_sample_data.c component5/sg5_worm.c component5/sg5_menu.c component5/desktop_shell_win32.c component5/desktop_gui_win32.c -o CricLens.exe -static -s -mwindows -lm -lgdi32 -luser32 -lcomdlg32 -lshell32 -lole32 -luuid -lmsimg32
```

Then create the Desktop and Start Menu icon (done by C code inside the program) and start the app:

```sh
CricLens.exe --install
CricLens.exe
```

## Build and run (text menu, any platform)

```sh
gcc -std=c99 -Wall -Wextra -pedantic -O2 -Icomponent1 -Icomponent2 -Icomponent3 -Icomponent4 -Icomponent5 component1/component1_input_parser.c component1/component1_match_loader.c component2/match_store.c component2/match_validate.c component3/stats_engine.c component3/stats_legacy_compat.c component4/chart_render.c component5/sg5_adapter.c component5/sg5_awards.c component5/sg5_manhattan.c component5/sg5_partnership.c component5/sg5_sample_data.c component5/sg5_worm.c component5/sg5_menu.c component5/sg5_main.c -o criclens -lm
./criclens
```

## Test

Compile and run each test program (same flags and include paths as above):

```sh
INC="-Icomponent1 -Icomponent2 -Icomponent3 -Icomponent4 -Icomponent5"
FL="-std=c99 -Wall -Wextra -pedantic -O2"
C1="component1/component1_input_parser.c component1/component1_match_loader.c"
C2="component2/match_store.c component2/match_validate.c"
C3="component3/stats_engine.c component3/stats_legacy_compat.c"
gcc $FL $INC $C3 component3/test_stats_engine.c -o test_stats_engine -lm && ./test_stats_engine
gcc $FL $INC $C3 component3/test_legacy_compat.c -o test_legacy_compat -lm && ./test_legacy_compat
gcc $FL $INC $C1 $C2 component1/test_parser.c -o test_parser -lm && ./test_parser --match component1/sample_match.txt
gcc $FL $INC $C2 component2/test_storage.c -o test_storage -lm && ./test_storage
gcc $FL $INC component4/chart_render.c component4/test_render.c -o test_render -lm && ./test_render
```

These cover Component 3 (improved and legacy-API tests), the Component 1 scorecard loader, Component 2 storage and Component 4 chart rendering.

## Important notes

- `component1/sample_match.txt` is the scorecard input example.
- Component 5 currently initializes its own fictional sample matches; it is not automatically loading `sample_match.txt` at startup. Use its file-import option where available to add a parsed scorecard.
- The legacy compatibility module preserves existing Component 5 calls. Batting calculations and over-series data are delegated to the improved Component 3 API; partnership, awards and result functions retain their legacy interface. New code should use the improved API in `stats_engine.h`.

## Native Windows desktop application (C)

`component5/desktop_gui_win32.c` is a native graphical Windows application written in C using the Win32 API and GDI, with `component5/desktop_shell_win32.c` generating the application icon and creating the Desktop and Start Menu shortcuts. It uses the integrated Components 1-5 and provides an animated splash screen, score dashboard, worm/Manhattan/partnership charts with hover tooltips, awards, scorecard import and image export. It does not use HTML, CSS, JavaScript, Electron, a browser, or any language other than C. See `README_DESKTOP_WINDOWS.md` for details.
