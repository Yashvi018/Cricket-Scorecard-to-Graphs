#ifndef SG5_VIZ_H
#define SG5_VIZ_H
/* Subgroup 5: charts, awards and menu. Plain C99.
   Data comes from Component 2's Match model; statistics from Component 3; charts from Components 4 and 5. */
#include <stdio.h>
#include "match_store.h"
#include "stats_engine.h"
#include "../component3/stats_legacy_compat.h"
#include "chart_render.h"

#define SG5_MAX_OVERS  60
#define SG5_MAX_PSHIPS 12

typedef struct { char title[2 * NAME_LEN + 8]; char venue[VENUE_LEN]; char date[DATE_LEN]; char id[MATCH_ID_LEN]; } MatchInfo;

typedef struct {
    char team[NAME_LEN];
    int  total_runs, wickets, balls, overs;
    int  runs_per_over[SG5_MAX_OVERS];
    int  cumulative_runs[SG5_MAX_OVERS];
    int  wicket_in_over[SG5_MAX_OVERS];
    int  num_partnerships;
    char pship_bat1[SG5_MAX_PSHIPS][NAME_LEN];
    char pship_bat2[SG5_MAX_PSHIPS][NAME_LEN];
    int  pship_runs[SG5_MAX_PSHIPS];
    int  pship_unbeaten[SG5_MAX_PSHIPS];
} InningsPlot;

typedef struct {
    MatchInfo   info;
    InningsPlot in[2];
    MatchAwards aw;
    char        result[96];
} Sg5Match;

/* Adapter (sg5_adapter.c): owns the MatchStore and builds chart-ready data from it. */
int  sg5_init(void);                 /* loads the three sample matches; returns 1 on success */
void sg5_shutdown(void);
int  sg5_match_count(void);
void sg5_match_title(int index, char *buf, size_t size);
int  sg5_load_match(int index, Sg5Match *m);
int  sg5_add_from_file(const char *path, char *error, size_t error_size);   /* Component 1 text scorecard */
int  sg5_max_over_runs(const Sg5Match *m);

/* Scorecard tables for the desktop GUI (read from Component 2's Match structs inside the adapter). */
#define SG5_MAX_ROWS 16
typedef struct { char name[NAME_LEN]; int runs, balls, fours, sixes, out; double sr, bnd_pct; } Sg5BatRow;
typedef struct { char name[NAME_LEN]; int runs, wickets, balls; double econ; } Sg5BowlRow;
typedef struct { int wkt, score, over, ball; char name[NAME_LEN]; } Sg5FowRow;
typedef struct { int nbat, nbowl, nfow; Sg5BatRow bat[SG5_MAX_ROWS]; Sg5BowlRow bowl[SG5_MAX_ROWS]; Sg5FowRow fow[SG5_MAX_ROWS]; } Sg5Card;
typedef struct { char name[NAME_LEN]; int runs, wickets, points; } Sg5MvpRow;
int  sg5_scorecard(int index, int innings, Sg5Card *out);          /* 0 on success */
int  sg5_mvp(int index, Sg5MvpRow *out, int max_rows);             /* rows sorted by points, returns count */

int  sg5_sample_matches(MatchStore *store);   /* sg5_sample_data.c: fictional matches built as Match structs */

void sg5_worm_show(const Sg5Match *m);
void sg5_worm_svg(FILE *f, const Sg5Match *m);
void sg5_manhattan_show(const InningsPlot *p);
void sg5_manhattan_svg(FILE *f, const InningsPlot *p, int mx);
void sg5_partnership_show(const InningsPlot *p);
void sg5_partnership_svg(FILE *f, const InningsPlot *p);
void sg5_awards_show(const Sg5Match *m);
void sg5_menu_run(void);
#endif
