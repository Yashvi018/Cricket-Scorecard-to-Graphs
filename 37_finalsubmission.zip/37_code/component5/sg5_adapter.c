/* Adapter: the only subgroup 5 file that reads Component 2's Match structs directly. */
#include <string.h>
#include "sg5_viz.h"
#include "component1_match_loader.h"

static MatchStore g_store;

int sg5_init(void)
{
    store_init(&g_store);
    if (!sg5_sample_matches(&g_store)) {
        store_free(&g_store);
        return 0;
    }
    return 1;
}

void sg5_shutdown(void)
{
    store_free(&g_store);
}

int sg5_match_count(void)
{
    return (int)g_store.count;
}

void sg5_match_title(int index, char *buf, size_t size)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    if (m) snprintf(buf, size, "%s v %s", m->team1, m->team2);
    else snprintf(buf, size, "(no match)");
}

static void fill_innings(const Innings *in, InningsPlot *p)
{
    Partnership ps[SG5_MAX_PSHIPS];
    int i, n;

    memset(p, 0, sizeof *p);
    snprintf(p->team, NAME_LEN, "%s", in->batting_team);
    p->total_runs = in->total_runs;
    p->wickets = in->wickets;
    p->balls = in->legal_balls;
    p->overs = stats_over_runs(in, p->runs_per_over, SG5_MAX_OVERS);
    stats_cumulative_runs(in, p->cumulative_runs, SG5_MAX_OVERS);
    stats_over_wickets(in, p->wicket_in_over, SG5_MAX_OVERS);
    n = stats_partnerships(in, ps, SG5_MAX_PSHIPS);
    for (i = 0; i < n; i++) {
        snprintf(p->pship_bat1[i], NAME_LEN, "%.49s", ps[i].bat1);
        snprintf(p->pship_bat2[i], NAME_LEN, "%.49s", ps[i].bat2);
        p->pship_runs[i] = ps[i].runs;
        p->pship_unbeaten[i] = ps[i].unbeaten;
    }
    p->num_partnerships = n;
}

int sg5_load_match(int index, Sg5Match *out)
{
    const Match *m = store_get_match(&g_store, (size_t)index);

    if (!m || !out) return -1;
    memset(out, 0, sizeof *out);
    snprintf(out->info.title, sizeof out->info.title, "%s v %s", m->team1, m->team2);
    snprintf(out->info.venue, VENUE_LEN, "%s", m->venue);
    snprintf(out->info.date, DATE_LEN, "%s", m->date);
    snprintf(out->info.id, MATCH_ID_LEN, "%s", m->match_id);
    fill_innings(&m->innings[0], &out->in[0]);
    fill_innings(&m->innings[1], &out->in[1]);
    if (!stats_awards(m, &out->aw) || !stats_result(m, out->result, sizeof out->result)) return -1;
    return 0;
}

int sg5_add_from_file(const char *path, char *error, size_t error_size)
{
    Match m;
    int ok;

    memset(&m, 0, sizeof m);
    if (!load_match_file(path, &m, error, error_size)) return 0;
    ok = store_add_match(&g_store, &m);
    match_free(&m);
    if (!ok && error && error_size) snprintf(error, error_size, "the match could not be stored");
    return ok;
}

int sg5_max_over_runs(const Sg5Match *m)
{
    int i, k, mx = 10;

    for (i = 0; i < 2; i++)
        for (k = 0; k < m->in[i].overs; k++)
            if (m->in[i].runs_per_over[k] > mx) mx = m->in[i].runs_per_over[k];
    return mx;
}

int sg5_scorecard(int index, int innings, Sg5Card *out)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    const Innings *in;
    size_t k, j;

    if (!m || !out || innings < 0 || innings > 1) return -1;
    memset(out, 0, sizeof *out);
    in = &m->innings[innings];
    for (k = 0; k < in->batter_count && out->nbat < SG5_MAX_ROWS; k++) {
        const Player *p = &in->batters[k];
        Sg5BatRow *r = &out->bat[out->nbat];
        int dismissed = 0;
        for (j = 0; j < in->fow_count; j++)
            if (strcmp(in->fow[j].player_out, p->name) == 0) dismissed = 1;
        if (p->balls_faced <= 0 && !dismissed) continue;          /* did not bat */
        snprintf(r->name, NAME_LEN, "%.49s", p->name);
        r->runs = p->runs; r->balls = p->balls_faced; r->fours = p->fours; r->sixes = p->sixes; r->out = dismissed;
        r->sr = p->balls_faced > 0 ? 100.0 * p->runs / p->balls_faced : 0.0;
        r->bnd_pct = p->runs > 0 ? 100.0 * (4 * p->fours + 6 * p->sixes) / p->runs : 0.0;
        out->nbat++;
    }
    for (k = 0; k < in->bowler_count && out->nbowl < SG5_MAX_ROWS; k++) {
        const Player *p = &in->bowlers[k];
        Sg5BowlRow *r = &out->bowl[out->nbowl];
        if (p->balls_bowled <= 0) continue;
        snprintf(r->name, NAME_LEN, "%.49s", p->name);
        r->runs = p->runs_conceded; r->wickets = p->wickets; r->balls = p->balls_bowled;
        r->econ = 6.0 * p->runs_conceded / p->balls_bowled;
        out->nbowl++;
    }
    for (k = 0; k < in->fow_count && out->nfow < SG5_MAX_ROWS; k++) {
        const FallOfWicket *f = &in->fow[k];
        Sg5FowRow *r = &out->fow[out->nfow++];
        r->wkt = f->wicket_number; r->score = f->team_score; r->over = f->over_number; r->ball = f->ball_in_over;
        snprintf(r->name, NAME_LEN, "%.49s", f->player_out);
    }
    return 0;
}

int sg5_mvp(int index, Sg5MvpRow *out, int max_rows)
{
    const Match *m = store_get_match(&g_store, (size_t)index);
    Sg5MvpRow t[64];
    int n = 0, i, j, a;
    size_t k;

    if (!m || !out || max_rows < 1) return 0;
    for (a = 0; a < 2; a++) {
        const Innings *in = &m->innings[a];
        for (k = 0; k < in->batter_count + in->bowler_count; k++) {
            int bat = k < in->batter_count;
            const Player *p = bat ? &in->batters[k] : &in->bowlers[k - in->batter_count];
            int add_runs = bat ? p->runs : 0, add_wk = bat ? 0 : p->wickets;
            for (i = 0; i < n; i++) if (strcmp(t[i].name, p->name) == 0) break;
            if (i == n) {
                if (n >= 64) continue;
                memset(&t[n], 0, sizeof t[n]);
                snprintf(t[n].name, NAME_LEN, "%.49s", p->name);
                n++;
            }
            t[i].runs += add_runs; t[i].wickets += add_wk;
            t[i].points += add_runs + STATS_POINTS_PER_WICKET * add_wk;     /* same formula as the Man of the Match */
        }
    }
    for (i = 1; i < n; i++) {                                              /* insertion sort, highest points first */
        Sg5MvpRow x = t[i];
        for (j = i - 1; j >= 0 && t[j].points < x.points; j--) t[j + 1] = t[j];
        t[j + 1] = x;
    }
    if (n > max_rows) n = max_rows;
    memcpy(out, t, (size_t)n * sizeof t[0]);
    return n;
}
