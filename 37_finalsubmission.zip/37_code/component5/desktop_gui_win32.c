/* CricLens native Windows desktop GUI -- plain C, Win32 API + GDI only.
 *
 * A light "analytics dashboard" interface with a dark-mode toggle:
 *   - top bar with match selector, engine badge, dark/light switch and scorecard upload dialog
 *   - match summary card (animated scores, run rates, result banner, Man of the Match)
 *   - chart card: worm, Manhattan x2, partnerships x2 and run-rate charts with hover tooltips,
 *     SVG export (Component 5 renderers) and 24-bit BMP export
 *   - "Scorecard & Metrics" card: batting and bowling tables, fall of wickets, awards, MVP ranking
 *   - smooth animations everywhere (tab pills, count-ups, chart reveals, row fades, modal, toasts)
 *   - double-buffered, DPI-aware, resizable, scrollable; runtime-generated icon and shortcuts
 * Data comes from Components 1-5 through the Component 5 adapter (sg5_*).
 */
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sg5_viz.h"
#include "desktop_shell_win32.h"

#define PI 3.14159265358979323846
#define SSC 2                 /* supersampling factor for chart plots */
#define SPLASH_MS 2000
#define ANIM_MS 1100
#define NCTAB 6
#define NRTAB 3
#define MAX_TITLES 12
#define WM_CL_LOAD  (WM_APP + 1)
#define WM_CL_CLOSE (WM_APP + 2)

/* ------------------------------------------------------------------- theme */
enum { K_BG, K_CARD, K_CARD2, K_BORDER, K_TEXT, K_MUTED, K_FAINT, K_ACCENT, K_ACCENT_H, K_ONACC, K_T1, K_T2,
       K_BANNER, K_THEAD, K_GRID, K_HOVER, K_GREEN, K_GREENBG, K_GREENFG, K_RED, K_REDBG, K_SCRIM, K_TIP, K_GOLD, K_COUNT };
static const COLORREF TH_LIGHT[K_COUNT] = {
    RGB(244, 246, 250), RGB(255, 255, 255), RGB(249, 250, 252), RGB(226, 231, 240), RGB(15, 23, 42), RGB(100, 116, 139),
    RGB(148, 163, 184), RGB(30, 58, 95), RGB(44, 78, 124), RGB(255, 255, 255), RGB(36, 84, 166), RGB(185, 28, 38),
    RGB(234, 242, 255), RGB(241, 245, 249), RGB(226, 231, 240), RGB(244, 247, 252), RGB(34, 197, 94), RGB(220, 252, 231),
    RGB(21, 128, 61), RGB(185, 28, 28), RGB(254, 226, 226), RGB(15, 23, 42), RGB(15, 23, 42), RGB(217, 154, 20)};
static const COLORREF TH_DARK[K_COUNT] = {
    RGB(10, 15, 30), RGB(18, 26, 46), RGB(22, 31, 54), RGB(40, 52, 84), RGB(232, 236, 246), RGB(140, 152, 180),
    RGB(96, 108, 140), RGB(59, 110, 200), RGB(80, 130, 222), RGB(255, 255, 255), RGB(96, 165, 250), RGB(248, 113, 113),
    RGB(22, 35, 68), RGB(26, 36, 62), RGB(38, 50, 82), RGB(28, 39, 70), RGB(52, 211, 120), RGB(20, 60, 40),
    RGB(110, 231, 160), RGB(252, 165, 165), RGB(70, 28, 34), RGB(0, 0, 0), RGB(40, 52, 92), RGB(246, 196, 83)};
static COLORREF TC[K_COUNT];
#define C(k) TC[k]

/* --------------------------------------------------------- ids and targets */
typedef enum { VIEW_WORM, VIEW_MAN1, VIEW_MAN2, VIEW_PS1, VIEW_PS2, VIEW_RR, VIEW_COUNT } View;
enum { ID_NONE = 0, ID_DARK, ID_UPLOAD, ID_MATCHSEL, ID_ERRCLOSE, ID_DL_SVG, ID_DL_BMP, ID_ABOUT,
       ID_CTAB = 10, ID_RTAB = 20, ID_MITEM = 24, ID_M_BACK = 40, ID_M_PANEL, ID_M_CLOSE, ID_M_CHOOSE, ID_M_CANCEL, ID_M_LOAD, ID_MAX };
typedef struct { RECT r; int id; } Target;
static Target g_tg[160];
static int g_ntg, g_oy, g_clip_on;
static RECT g_clipwin;
static int g_hot_id, g_down_id;
static double g_hv[ID_MAX];

typedef struct { int pad, top_h, stat_h, view_h, cw, mc_y, mc_h, pn_y, pn_h, lw, rx, rw, total; } Lay;
typedef struct { int bx0, by0, bx1, by1, px0, py0, px1, py1, n, ymax, ystep; } Geo;
typedef struct { int n; char text[4][170]; COLORREF col[4]; } Tip;

/* ------------------------------------------------------------------- state */
static HWND g_hwnd, g_edit;
static WNDPROC g_edit_old;
static HBRUSH g_edit_brush;
static COLORREF g_edit_brush_col = 0xFFFFFFFF;
static HDC g_mem;
static HBITMAP g_membmp;
static HGDIOBJ g_memold;
static int g_w, g_h, g_full;
static double g_s = 1.0, g_dt = 0.016;
static WINDOWPLACEMENT g_wp;

static HFONT f_cap, f_capb, f_body, f_semi, f_bold, f_h1, f_h2, f_h3, f_score, f_mid, f_mono, f_rot;
static HICON g_icon_big, g_icon_small;
static unsigned char *g_logo_splash;

static Sg5Match g_match;
static Sg5Card g_card[2];
static Sg5MvpRow g_mvp[8];
static int g_nmvp, g_match_index, g_match_gen;
static View g_view = VIEW_WORM;
static int g_rtab;                         /* 0 = 1st innings, 1 = 2nd innings, 2 = awards */
static DWORD g_t_start, g_t_match, g_t_chart, g_t_rtab, g_t_enter, g_t_last;
static int g_splash = 1, g_tracking, g_busy, g_idle;
static int g_mx = -1, g_my = -1, g_cmx, g_cmy, g_hover_content;

static double g_theme_t, g_theme_goal;
static double g_scroll, g_scroll_goal, g_scroll_max;
static double g_rs, g_rs_goal, g_rs_max;
static RECT g_rs_rect;
static int g_rs_content;
static double g_ct_l, g_ct_r, g_rt_l, g_rt_r;
static int g_ct_init, g_rt_init;

static HBITMAP g_plot;
static int g_plot_w, g_plot_h, g_plot_valid, g_plot_key;
static RECT g_chart_win;

static Tip g_tip;
static char g_err[260], g_toast[200], g_pick[MAX_PATH];
static DWORD g_err_t, g_toast_t;
static int g_modal, g_dd_open, g_ntitles;
static double g_mod_a, g_dd_a;
static char g_titles[MAX_TITLES][130];

static HDC g_pxdc;
static HBITMAP g_pxbmp;
static HGDIOBJ g_pxold;

/* ----------------------------------------------------------------- helpers */
static int U(double v) { return (int)(v * g_s + 0.5); }
static double clampd(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
static double ease_out(double t) { t = 1.0 - clampd(t, 0, 1); return 1.0 - t * t * t; }
static double ease_io(double t) { t = clampd(t, 0, 1); return t * t * (3.0 - 2.0 * t); }
static double ease_back(double t)
{
    const double c1 = 1.70158, c3 = c1 + 1.0;
    t = clampd(t, 0, 1) - 1.0;
    return 1.0 + c3 * t * t * t + c1 * t * t;
}
static COLORREF lerp_col(COLORREF a, COLORREF b, double t)
{
    t = clampd(t, 0, 1);
    return RGB((int)(GetRValue(a) + (GetRValue(b) - GetRValue(a)) * t + 0.5),
               (int)(GetGValue(a) + (GetGValue(b) - GetGValue(a)) * t + 0.5),
               (int)(GetBValue(a) + (GetBValue(b) - GetBValue(a)) * t + 0.5));
}
static COLORREF lighten(COLORREF c, double t) { return lerp_col(c, RGB(255, 255, 255), t); }
static COLORREF fade(COLORREF c, double t) { return lerp_col(C(K_CARD), c, t); }
static double since(DWORD t0) { return (double)(GetTickCount() - t0); }
static double prog_of(DWORD t0, double ms, double delay)
{
    double t = (since(t0) - delay) / ms;
    if (t < 1.0) g_busy = 1;
    return ease_out(t);
}
static void slide(double *cur, double tgt)
{
    double d = tgt - *cur;
    if (fabs(d) < 0.5) { *cur = tgt; return; }
    *cur += d * (1.0 - exp(-g_dt * 22.0));
    g_busy = 1;
}
static void theme_update(void)
{
    int k;
    double e = ease_io(g_theme_t);
    for (k = 0; k < K_COUNT; k++) TC[k] = lerp_col(TH_LIGHT[k], TH_DARK[k], e);
}
static void toast(const char *s) { snprintf(g_toast, sizeof g_toast, "%s", s); g_toast_t = GetTickCount(); }
static void set_error(const char *s) { snprintf(g_err, sizeof g_err, "%s", s); g_err_t = GetTickCount(); }

static HFONT mkfont(int px, int weight, const char *face, int rot)
{
    return CreateFontA(-px, 0, rot, rot, weight, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                       OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
}
static void kill_font(HFONT *f) { if (*f) { DeleteObject(*f); *f = NULL; } }
static void kill_all_fonts(void)
{
    kill_font(&f_cap); kill_font(&f_capb); kill_font(&f_body); kill_font(&f_semi); kill_font(&f_bold); kill_font(&f_h1);
    kill_font(&f_h2); kill_font(&f_h3); kill_font(&f_score); kill_font(&f_mid); kill_font(&f_mono); kill_font(&f_rot);
}
static void make_fonts(void)
{
    kill_all_fonts();
    f_cap = mkfont(U(12), FW_NORMAL, "Segoe UI", 0);
    f_capb = mkfont(U(11), FW_BOLD, "Segoe UI", 0);
    f_body = mkfont(U(14), FW_NORMAL, "Segoe UI", 0);
    f_semi = mkfont(U(14), FW_SEMIBOLD, "Segoe UI", 0);
    f_bold = mkfont(U(14), FW_BOLD, "Segoe UI", 0);
    f_h1 = mkfont(U(21), FW_BOLD, "Segoe UI", 0);
    f_h2 = mkfont(U(18), FW_BOLD, "Segoe UI", 0);
    f_h3 = mkfont(U(17), FW_BOLD, "Segoe UI", 0);
    f_score = mkfont(U(46), FW_BOLD, "Segoe UI", 0);
    f_mid = mkfont(U(24), FW_BOLD, "Segoe UI", 0);
    f_mono = mkfont(U(13), FW_NORMAL, "Consolas", 0);
    f_rot = mkfont(U(12), FW_NORMAL, "Segoe UI", 900);
}

/* ------------------------------------------------------ drawing primitives */
static void fill(HDC dc, int l, int t, int r, int b, COLORREF c)
{
    RECT rc;
    rc.left = l; rc.top = t; rc.right = r; rc.bottom = b;
    SetBkColor(dc, c);
    ExtTextOutA(dc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
}
static void vgrad(HDC dc, int l, int t, int r, int b, COLORREF c1, COLORREF c2)
{
    int i, h = b - t;
    if (h <= 0) return;
    for (i = 0; i < h; i++) fill(dc, l, t + i, r, t + i + 1, lerp_col(c1, c2, h > 1 ? (double)i / (h - 1) : 0.0));
}
static void alpha_rect(HDC dc, int l, int t, int r, int b, COLORREF c, int a)
{
    BLENDFUNCTION bf;
    if (r <= l || b <= t || a <= 0) return;
    if (!g_pxdc) {
        HDC s = GetDC(NULL);
        g_pxdc = CreateCompatibleDC(s);
        g_pxbmp = CreateCompatibleBitmap(s, 1, 1);
        g_pxold = SelectObject(g_pxdc, g_pxbmp);
        ReleaseDC(NULL, s);
    }
    SetPixelV(g_pxdc, 0, 0, c);
    bf.BlendOp = AC_SRC_OVER; bf.BlendFlags = 0; bf.SourceConstantAlpha = (BYTE)(a > 255 ? 255 : a); bf.AlphaFormat = 0;
    AlphaBlend(dc, l, t, r - l, b - t, g_pxdc, 0, 0, 1, 1, bf);
}
static void line_(HDC dc, int x1, int y1, int x2, int y2, COLORREF c, int w, int style)
{
    HPEN p = CreatePen(style, w, c), old = (HPEN)SelectObject(dc, p);
    SetBkMode(dc, TRANSPARENT);
    MoveToEx(dc, x1, y1, NULL); LineTo(dc, x2, y2);
    SelectObject(dc, old); DeleteObject(p);
}
static void rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void outline_rrect(HDC dc, int l, int t, int r, int b, int rad, COLORREF edge, int ew, int style)
{
    HPEN pen;
    HGDIOBJ ob, op;
    pen = CreatePen(style, ew, edge);
    SetBkMode(dc, TRANSPARENT);
    ob = SelectObject(dc, GetStockObject(NULL_BRUSH)); op = SelectObject(dc, pen);
    RoundRect(dc, l, t, r + 1, b + 1, rad, rad);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
static void circle(HDC dc, int cx, int cy, int r, COLORREF fillc, COLORREF edge, int ew)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = ew > 0 ? CreatePen(PS_SOLID, ew, edge) : (HPEN)GetStockObject(NULL_PEN);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op);
    DeleteObject(br);
    if (ew > 0) DeleteObject(pen);
}
static void ring(HDC dc, int cx, int cy, int r, COLORREF edge, int ew)
{
    HPEN pen = CreatePen(PS_SOLID, ew, edge);
    HGDIOBJ ob = SelectObject(dc, GetStockObject(NULL_BRUSH)), op = SelectObject(dc, pen);
    Ellipse(dc, cx - r, cy - r, cx + r + 1, cy + r + 1);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(pen);
}
static void poly(HDC dc, const POINT *pts, int n, COLORREF fillc, COLORREF edge)
{
    HBRUSH br = CreateSolidBrush(fillc);
    HPEN pen = CreatePen(PS_SOLID, 1, edge);
    HGDIOBJ ob = SelectObject(dc, br), op = SelectObject(dc, pen);
    Polygon(dc, pts, n);
    SelectObject(dc, ob); SelectObject(dc, op); DeleteObject(br); DeleteObject(pen);
}
/* Rounded clip that works with the content viewport offset (clip regions use device coordinates). */
static void clip_rrect(HDC dc, int l, int t, int r, int b, int rad)
{
    HRGN rg = CreateRoundRectRgn(l, t + g_oy, r + 2, b + 2 + g_oy, rad, rad);
    ExtSelectClipRgn(dc, rg, RGN_AND);
    DeleteObject(rg);
}
static void shadow(HDC dc, int l, int t, int r, int b, int rad, int a)
{
    int i;
    for (i = 3; i >= 1; i--) {
        int e = U(i * 2), sv = SaveDC(dc);
        clip_rrect(dc, l - e, t - e + U(3), r + e, b + e + U(3), rad + e * 2);
        alpha_rect(dc, l - e, t - e + U(3), r + e + 1, b + e + U(4), C(K_SCRIM), a);
        RestoreDC(dc, sv);
    }
}
static void card(HDC dc, int l, int t, int r, int b, int rad)
{
    shadow(dc, l, t, r, b, rad, 5);
    rrect(dc, l, t, r, b, rad, C(K_CARD), C(K_BORDER), 1);
}
/* Text anchored at x, vertically centred on yc. align: 0 left, 1 centre, 2 right. */
static void txtc(HDC dc, int x, int yc, const char *s, COLORREF c, HFONT f, int align)
{
    RECT r;
    UINT fm = DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP;
    r.top = yc - U(40); r.bottom = yc + U(40);
    if (align == 1) { r.left = x - 4000; r.right = x + 4000; fm |= DT_CENTER; }
    else if (align == 2) { r.left = x - 8000; r.right = x; fm |= DT_RIGHT; }
    else { r.left = x; r.right = x + 8000; fm |= DT_LEFT; }
    SelectObject(dc, f); SetBkMode(dc, TRANSPARENT); SetTextColor(dc, c);
    DrawTextA(dc, s, -1, &r, fm);
}
static int tw(HDC dc, HFONT f, const char *s)
{
    SIZE z;
    SelectObject(dc, f);
    GetTextExtentPoint32A(dc, s, (int)strlen(s), &z);
    return z.cx;
}
static void fit(HDC dc, HFONT f, const char *s, int maxw, char *out, size_t n)
{
    size_t len;
    char t[200];
    snprintf(out, n, "%s", s);
    if (tw(dc, f, out) <= maxw) return;
    len = strlen(out);
    while (len > 1) {
        out[--len] = 0;
        snprintf(t, sizeof t, "%s...", out);
        if (tw(dc, f, t) <= maxw) { snprintf(out, n, "%s", t); return; }
    }
}
static void blit_rgba(HDC dc, const unsigned char *buf, int src, int x, int y, int dim)
{
    BITMAPINFO bi;
    if (!buf || dim < 1) return;
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = src; bi.bmiHeader.biHeight = -src;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    SetStretchBltMode(dc, HALFTONE);
    SetBrushOrgEx(dc, 0, 0, NULL);
    StretchDIBits(dc, x, y, dim, dim, 0, 0, src, src, buf, &bi, DIB_RGB_COLORS, SRCCOPY);
}

/* --------------------------------------------------- targets and widgets */
static void reg(int id, int l, int t, int r, int b)
{
    RECT rc;
    if (g_ntg >= (int)(sizeof g_tg / sizeof g_tg[0])) return;
    rc.left = l; rc.top = t + g_oy; rc.right = r; rc.bottom = b + g_oy;
    if (g_clip_on) {
        if (rc.left < g_clipwin.left) rc.left = g_clipwin.left;
        if (rc.right > g_clipwin.right) rc.right = g_clipwin.right;
        if (rc.top < g_clipwin.top) rc.top = g_clipwin.top;
        if (rc.bottom > g_clipwin.bottom) rc.bottom = g_clipwin.bottom;
    }
    if (rc.right <= rc.left || rc.bottom <= rc.top) return;
    g_tg[g_ntg].r = rc; g_tg[g_ntg].id = id; g_ntg++;
}
static int hit_id(int x, int y)
{
    int i;
    POINT p;
    p.x = x; p.y = y;
    for (i = g_ntg - 1; i >= 0; i--) {
        int id = g_tg[i].id;
        if (!PtInRect(&g_tg[i].r, p)) continue;
        if (g_modal && id < ID_M_BACK) continue;
        if (g_dd_open && id != ID_MATCHSEL && !(id >= ID_MITEM && id < ID_MITEM + MAX_TITLES)) continue;
        return id;
    }
    return ID_NONE;
}
enum { BS_OUTLINE, BS_PRIMARY };
enum { IC_NONE, IC_MOON, IC_SUN, IC_PLUS, IC_DL };

static void draw_icon(HDC dc, int icon, int cx, int cy, COLORREF fg, COLORREF bg)
{
    int i;
    if (icon == IC_MOON) {
        circle(dc, cx, cy, U(7), fg, fg, 0);
        circle(dc, cx + U(4), cy - U(3), U(6), bg, bg, 0);
    } else if (icon == IC_SUN) {
        circle(dc, cx, cy, U(4), fg, fg, 0);
        for (i = 0; i < 8; i++) {
            double a = i * PI / 4;
            line_(dc, cx + (int)(cos(a) * U(6.5)), cy + (int)(sin(a) * U(6.5)), cx + (int)(cos(a) * U(9)), cy + (int)(sin(a) * U(9)), fg, 2, PS_SOLID);
        }
    } else if (icon == IC_PLUS) {
        line_(dc, cx - U(6), cy, cx + U(6), cy, fg, 2, PS_SOLID);
        line_(dc, cx, cy - U(6), cx, cy + U(6), fg, 2, PS_SOLID);
    } else if (icon == IC_DL) {
        line_(dc, cx, cy - U(6), cx, cy + U(3), fg, 2, PS_SOLID);
        line_(dc, cx - U(4), cy - U(1), cx, cy + U(4), fg, 2, PS_SOLID);
        line_(dc, cx + U(4), cy - U(1), cx, cy + U(4), fg, 2, PS_SOLID);
        line_(dc, cx - U(6), cy + U(7), cx + U(6), cy + U(7), fg, 2, PS_SOLID);
    }
}
static void button(HDC dc, int id, int l, int t, int r, int b, const char *label, int style, int icon, HFONT f)
{
    double hv = g_hv[id];
    int down = (g_down_id == id && g_hot_id == id), off = down ? 1 : 0, tx = (l + r) / 2, icw = icon ? U(24) : 0;
    COLORREF bg, fg, bd;
    if (style == BS_PRIMARY) { bg = lerp_col(C(K_ACCENT), C(K_ACCENT_H), hv); fg = C(K_ONACC); bd = bg; }
    else { bg = lerp_col(C(K_CARD), C(K_HOVER), hv); fg = C(K_TEXT); bd = lerp_col(C(K_BORDER), C(K_ACCENT), hv * 0.8); }
    if (hv > 0.04 && !down) shadow(dc, l, t, r, b, U(9), (int)(7 * hv));
    rrect(dc, l, t + off, r, b + off, U(9), bg, bd, 1);
    if (label && label[0]) {
        int w = tw(dc, f, label);
        if (icon) tx = (l + r) / 2 + icw / 2;
        txtc(dc, tx, (t + b) / 2 + off, label, fg, f, 1);
        if (icon) draw_icon(dc, icon, tx - w / 2 - U(14), (t + b) / 2 + off, fg, bg);
    } else if (icon) draw_icon(dc, icon, (l + r) / 2, (t + b) / 2 + off, fg, bg);
    reg(id, l, t, r, b);
}
static int chip(HDC dc, int x, int yc, const char *s, HFONT f, COLORREF bg, COLORREF fg, COLORREF bd)
{
    int w = tw(dc, f, s) + U(20), h = U(24);
    rrect(dc, x, yc - h / 2, x + w, yc + h / 2, U(8), bg, bd, 1);
    txtc(dc, x + w / 2, yc, s, fg, f, 1);
    return w;
}
/* Sliding-pill tab strip. Chooses shorter labels automatically when the space is tight. */
static int tab_strip(HDC dc, int x, int y, int hgt, int maxw, const char *const *labs[3], int n, int sel, int idbase,
                     double *pl, double *pr, int *init, int enabled)
{
    int pass, i, wd[8], tot = 0, tl[8], tr[8], cur;
    const char *const *lab = labs[0];
    for (pass = 0; pass < 3; pass++) {
        lab = labs[pass];
        tot = U(8);
        for (i = 0; i < n; i++) { wd[i] = tw(dc, f_semi, lab[i]) + U(pass == 2 ? 16 : 22); tot += wd[i]; }
        if (tot <= maxw) break;
    }
    rrect(dc, x, y, x + tot, y + hgt, U(10), C(K_THEAD), C(K_BORDER), 1);
    cur = x + U(4);
    for (i = 0; i < n; i++) { tl[i] = cur; tr[i] = cur + wd[i]; cur += wd[i]; }
    if (!*init) { *pl = tl[sel]; *pr = tr[sel]; *init = 1; }
    slide(pl, tl[sel]); slide(pr, tr[sel]);
    shadow(dc, (int)*pl, y + U(4), (int)*pr, y + hgt - U(4), U(8), 4);
    rrect(dc, (int)*pl, y + U(4), (int)*pr, y + hgt - U(4), U(8), C(K_CARD), C(K_BORDER), 1);
    for (i = 0; i < n; i++) {
        double hv = g_hv[idbase + i];
        COLORREF c = (i == sel) ? C(K_TEXT) : lerp_col(C(K_MUTED), C(K_TEXT), hv);
        txtc(dc, (tl[i] + tr[i]) / 2, y + hgt / 2, lab[i], c, f_semi, 1);
        if (enabled) reg(idbase + i, tl[i], y, tr[i], y + hgt);
    }
    return tot;
}

/* -------------------------------------------------------------- match data */
static void fmt_overs(int balls, char *out, size_t n) { snprintf(out, n, "%d.%d", balls / 6, balls % 6); }
static double rr_of(const InningsPlot *p) { return p->balls ? 6.0 * p->total_runs / p->balls : 0.0; }
static void refresh_titles(void)
{
    int i, n = sg5_match_count();
    static Sg5Match tmp;
    g_ntitles = n > MAX_TITLES ? MAX_TITLES : n;
    for (i = 0; i < g_ntitles; i++) {
        if (sg5_load_match(i, &tmp) == 0) snprintf(g_titles[i], sizeof g_titles[i], "%s vs %s", tmp.in[0].team, tmp.in[1].team);
        else snprintf(g_titles[i], sizeof g_titles[i], "(match %d)", i + 1);
    }
}
static void load_current(void)
{
    int k;
    if (sg5_load_match(g_match_index, &g_match) != 0) memset(&g_match, 0, sizeof g_match);
    for (k = 0; k < 2; k++) if (sg5_scorecard(g_match_index, k, &g_card[k]) != 0) memset(&g_card[k], 0, sizeof g_card[k]);
    g_nmvp = sg5_mvp(g_match_index, g_mvp, 8);
    g_t_match = g_t_chart = g_t_rtab = GetTickCount();
    g_rs = g_rs_goal = 0;
    g_match_gen++;
    g_plot_valid = 0;
    refresh_titles();
}
static int is_winner(const InningsPlot *p)
{
    size_t n = strlen(p->team);
    return n > 0 && strncmp(g_match.result, p->team, n) == 0;
}
static void nice_scale(int raw, int *ymax, int *step)
{
    static const int st[] = {5, 10, 20, 25, 50, 100, 200, 250, 500};
    int i;
    if (raw < 1) raw = 1;
    for (i = 0; i < 9; i++) {
        if ((raw + st[i] - 1) / st[i] <= 8) {
            *step = st[i];
            *ymax = ((raw + st[i] - 1) / st[i]) * st[i];
            if (*ymax < st[i]) *ymax = st[i];
            return;
        }
    }
    *step = 1000; *ymax = ((raw + 999) / 1000) * 1000;
}
static int runs_at(const InningsPlot *p, int v)
{
    if (v <= 0 || p->overs < 1) return 0;
    if (v > p->overs) return p->total_runs;
    return p->cumulative_runs[v - 1 < SG5_MAX_OVERS ? v - 1 : SG5_MAX_OVERS - 1];
}
static int wkts_at(const InningsPlot *p, int v)
{
    int i, s = 0;
    if (v > p->overs) v = p->overs;
    for (i = 0; i < v && i < SG5_MAX_OVERS; i++) s += p->wicket_in_over[i];
    return s;
}

/* ------------------------------------------------------------------ layout */
static Lay lay(void)
{
    Lay L;
    L.pad = U(24); L.top_h = U(76); L.stat_h = U(28);
    L.view_h = g_h - L.top_h - L.stat_h;
    L.cw = g_w - 2 * L.pad;
    L.mc_y = U(18); L.mc_h = U(250);
    L.pn_y = L.mc_y + L.mc_h + U(18);
    L.pn_h = L.view_h - L.pn_y - U(18);
    if (L.pn_h < U(440)) L.pn_h = U(440);
    L.rw = (int)((L.cw - U(18)) * 0.415);
    if (L.rw < U(450)) L.rw = U(450);
    L.lw = L.cw - U(18) - L.rw;
    L.rx = L.pad + L.lw + U(18);
    L.total = L.pn_y + L.pn_h + U(18);
    return L;
}

/* ----------------------------------------------------------- small shapes */
static void star(HDC dc, int cx, int cy, int r, COLORREF col)
{
    POINT p[10];
    int j;
    for (j = 0; j < 10; j++) {
        double ang = -PI / 2 + j * PI / 5, rad = (j % 2 ? 0.42 : 1.0) * r;
        p[j].x = cx + (int)(cos(ang) * rad); p[j].y = cy + (int)(sin(ang) * rad);
    }
    poly(dc, p, 10, col, col);
}
static void pulse_dot(HDC dc, int cx, int cy, int r, COLORREF col, COLORREF bg)
{
    double ph = fmod((double)GetTickCount() / 1500.0, 1.0);
    g_idle = 1;
    ring(dc, cx, cy, r + (int)(ph * U(7)), lerp_col(col, bg, ph), 1);
    circle(dc, cx, cy, r, col, col, 0);
}
static void brand_glyph(HDC dc, int x, int y, int s)
{
    int w = s / 5, i;
    rrect(dc, x, y, x + s, y + s, U(11), C(K_ACCENT), C(K_ACCENT), 0);
    for (i = 0; i < 3; i++) {
        int h = s * (i + 2) / 7;
        fill(dc, x + s / 5 + i * (w + U(3)), y + s - s / 5 - h, x + s / 5 + i * (w + U(3)) + w, y + s - s / 5, C(K_ONACC));
    }
}

/* ------------------------------------------------------------- match card */
static void team_block(HDC dc, int x, int y, int k, double cnt)
{
    const InningsPlot *p = &g_match.in[k];
    COLORREF tc = k ? C(K_T2) : C(K_T1);
    char buf[96], ov[24], fin[48];
    int runs = (int)(p->total_runs * cnt + 0.5), wk = (int)(p->wickets * cnt + 0.5), fw, ow;

    circle(dc, x + U(5), y, U(5), tc, tc, 0);
    txtc(dc, x + U(20), y, p->team, C(K_TEXT), f_h2, 0);
    if (is_winner(p)) star(dc, x + U(20) + tw(dc, f_h2, p->team) + U(16), y, U(8), C(K_GOLD));
    snprintf(fin, sizeof fin, "%d/%d", p->total_runs, p->wickets);
    fw = tw(dc, f_score, fin);
    snprintf(buf, sizeof buf, "%d/%d", runs, wk);
    txtc(dc, x, y + U(44), buf, C(K_TEXT), f_score, 0);
    fmt_overs(p->balls, ov, sizeof ov);
    snprintf(buf, sizeof buf, "(%s ov)", ov);
    txtc(dc, x + fw + U(16), y + U(52), buf, C(K_MUTED), f_body, 0);
    ow = tw(dc, f_body, buf);
    snprintf(buf, sizeof buf, "CRR: %.2f", rr_of(p) * cnt);
    chip(dc, x + fw + U(16) + ow + U(12), y + U(52), buf, f_cap, C(K_THEAD), C(K_MUTED), C(K_BORDER));
}

static void draw_match_card(HDC dc, int x, int y, int w, int h)
{
    double cnt = ease_out(since(g_t_match) / 1200.0);
    char title[170], sub[170], buf[160];
    int rx = x + w - U(24), pw, bx = x + U(24), bw = w - U(48), by = y + U(190), bh = U(42), half = x + w / 2;
    if (since(g_t_match) < 1300) g_busy = 1;
    card(dc, x, y, x + w, y + h, U(14));
    snprintf(title, sizeof title, "%s vs %s", g_match.in[0].team, g_match.in[1].team);
    txtc(dc, x + U(24), y + U(32), title, C(K_TEXT), f_h1, 0);
    snprintf(sub, sizeof sub, "%s \xB7 %s", g_match.info.venue, g_match.info.date);
    txtc(dc, x + U(24), y + U(58), sub, C(K_MUTED), f_body, 0);

    pw = tw(dc, f_capb, "Completed") + U(40);
    rrect(dc, rx - pw, y + U(20), rx, y + U(46), U(13), C(K_GREENBG), lerp_col(C(K_GREENBG), C(K_GREEN), 0.35), 1);
    pulse_dot(dc, rx - pw + U(15), y + U(33), U(4), C(K_GREEN), C(K_GREENBG));
    txtc(dc, rx - pw + U(27), y + U(33), "Completed", C(K_GREENFG), f_capb, 0);
    if (g_match.info.id[0]) {
        int cw2 = tw(dc, f_capb, g_match.info.id) + U(22);
        rrect(dc, rx - pw - U(10) - cw2, y + U(20), rx - pw - U(10), y + U(46), U(8), C(K_THEAD), C(K_BORDER), 1);
        txtc(dc, rx - pw - U(10) - cw2 / 2, y + U(33), g_match.info.id, C(K_MUTED), f_capb, 1);
    }
    line_(dc, x + 1, y + U(80), x + w - 1, y + U(80), C(K_BORDER), 1, PS_SOLID);

    team_block(dc, x + U(24), y + U(106), 0, cnt);
    txtc(dc, half - U(10), y + U(152), "vs", C(K_FAINT), f_semi, 1);
    team_block(dc, half + U(26), y + U(106), 1, cnt);

    rrect(dc, bx, by, bx + bw, by + bh, U(8), C(K_BANNER), C(K_BANNER), 0);
    fill(dc, bx, by + U(2), bx + U(4), by + bh - U(2), C(K_ACCENT));
    snprintf(buf, sizeof buf, "%s", g_match.result);
    txtc(dc, bx + U(18), by + bh / 2, buf, C(K_TEXT), f_bold, 0);
    if (g_match.aw.man_of_match[0] && strcmp(g_match.aw.man_of_match, "-") != 0) {
        char mom[100];
        int cwid;
        snprintf(mom, sizeof mom, "Man of Match: %s", g_match.aw.man_of_match);
        cwid = tw(dc, f_cap, mom) + U(24);
        if (bw - U(40) - tw(dc, f_bold, buf) > cwid) {
            rrect(dc, bx + bw - U(12) - cwid, by + U(8), bx + bw - U(12), by + bh - U(8), U(7), C(K_CARD), C(K_BORDER), 1);
            txtc(dc, bx + bw - U(12) - cwid / 2, by + bh / 2, mom, C(K_MUTED), f_cap, 1);
        }
    }
}

/* ------------------------------------------------------------ chart plots */
static double gx(const Geo *g, double v) { return g->px0 + (g->px1 - g->px0) * v / g->n; }
static double gy(const Geo *g, double v) { return g->py1 - (g->py1 - g->py0) * v / g->ymax; }
#define BX(g, v) ((int)((gx(g, (v)) - (g)->bx0) * SSC + 0.5))
#define BY(g, v) ((int)((gy(g, (v)) - (g)->by0) * SSC + 0.5))

static int x_step(const Geo *g)
{
    static const int s[4] = {1, 2, 5, 10};
    double px = (double)(g->px1 - g->px0) / g->n;
    int i;
    for (i = 0; i < 4; i++) if (px * s[i] >= U(48)) return s[i];
    return 20;
}
static double rr_val(const InningsPlot *p, int i) { return (double)p->cumulative_runs[i - 1] / i; }
static void make_geo(Geo *g, int view, int px0, int py0, int px1, int py1)
{
    int k, i, raw = 10, n1 = g_match.in[0].overs, n2 = g_match.in[1].overs;
    g->px0 = px0; g->py0 = py0; g->px1 = px1; g->py1 = py1;
    if (view == VIEW_MAN1 || view == VIEW_MAN2) {
        int mx = sg5_max_over_runs(&g_match);
        g->n = view == VIEW_MAN2 ? n2 : n1;
        raw = mx + mx / 8 + 1;
    } else {
        g->n = n1 > n2 ? n1 : n2;
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            if (view == VIEW_RR) {
                for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++) if ((int)ceil(rr_val(p, i)) + 1 > raw) raw = (int)ceil(rr_val(p, i)) + 1;
            } else {
                if (p->total_runs > raw) raw = p->total_runs;
                for (i = 0; i < p->overs && i < SG5_MAX_OVERS; i++) if (p->cumulative_runs[i] > raw) raw = p->cumulative_runs[i];
            }
        }
        if (view == VIEW_RR && raw < 8) raw = 8;
    }
    if (g->n < 1) g->n = 1;
    if (g->n > SG5_MAX_OVERS) g->n = SG5_MAX_OVERS;
    nice_scale(raw, &g->ymax, &g->ystep);
    g->bx0 = g->px0 - U(14); g->by0 = g->py0 - U(14);
    g->bx1 = g->px1 + U(14); g->by1 = g->py1 + U(10);
}
static int series_pts(const InningsPlot *p, int rr, double xv, double *xs, double *ys)
{
    int ns = p->overs, i, n = 0;
    if (ns > SG5_MAX_OVERS) ns = SG5_MAX_OVERS;
    if (ns < 1) return 0;
    if (!rr) { xs[n] = 0; ys[n] = 0; n++; }
    for (i = 1; i <= ns; i++) {
        double v = rr ? rr_val(p, i) : (double)p->cumulative_runs[i - 1];
        if (i <= xv) { xs[n] = i; ys[n] = v; n++; }
        else {
            if (n > 0) {
                double t = (xv - xs[n - 1]) / (i - xs[n - 1]);
                if (t > 0) { xs[n] = xv; ys[n] = ys[n - 1] + (v - ys[n - 1]) * t; n++; }
            }
            break;
        }
    }
    return n;
}
static void plot_grid(HDC d, const Geo *g, int vertical)
{
    int t, i, st = x_step(g);
    HPEN gp = CreatePen(PS_DASH, 1, C(K_GRID)), old = (HPEN)SelectObject(d, gp);
    SetBkMode(d, TRANSPARENT);
    for (t = 0; t <= g->ymax; t += g->ystep) { MoveToEx(d, BX(g, 0), BY(g, t), NULL); LineTo(d, BX(g, g->n), BY(g, t)); }
    if (vertical) for (i = 0; i <= g->n; i += st) { MoveToEx(d, BX(g, i), BY(g, g->ymax), NULL); LineTo(d, BX(g, i), BY(g, 0)); }
    SelectObject(d, old); DeleteObject(gp);
    gp = CreatePen(PS_SOLID, SSC, C(K_FAINT)); old = (HPEN)SelectObject(d, gp);
    MoveToEx(d, BX(g, 0), BY(g, g->ymax), NULL); LineTo(d, BX(g, 0), BY(g, 0)); LineTo(d, BX(g, g->n), BY(g, 0));
    SelectObject(d, old); DeleteObject(gp);
}
static void plot_lines(HDC d, const Geo *g, int rr, double prog)
{
    int k, i, np;
    double xv = prog * g->n, xs[SG5_MAX_OVERS + 3], ys[SG5_MAX_OVERS + 3];
    POINT pts[SG5_MAX_OVERS + 6];
    plot_grid(d, g, 1);
    if (!rr) {                                   /* soft areas first, so they never hide a line */
        for (k = 1; k >= 0; k--) {
            const InningsPlot *p = &g_match.in[k];
            COLORREF col = k ? C(K_T2) : C(K_T1);
            HBRUSH br;
            HGDIOBJ ob, op;
            np = series_pts(p, 0, xv, xs, ys);
            if (np < 2) continue;
            for (i = 0; i < np; i++) { pts[i].x = BX(g, xs[i]); pts[i].y = BY(g, ys[i]); }
            pts[np].x = pts[np - 1].x; pts[np].y = BY(g, 0);
            pts[np + 1].x = pts[0].x; pts[np + 1].y = BY(g, 0);
            br = CreateSolidBrush(lerp_col(C(K_CARD), col, k ? 0.06 : 0.09));
            ob = SelectObject(d, br); op = SelectObject(d, GetStockObject(NULL_PEN));
            Polygon(d, pts, np + 2);
            SelectObject(d, ob); SelectObject(d, op); DeleteObject(br);
        }
    }
    for (k = 1; k >= 0; k--) {                   /* second innings first so the first stays on top */
        const InningsPlot *p = &g_match.in[k];
        COLORREF col = k ? C(K_T2) : C(K_T1);
        HPEN pn, ringp;
        HBRUSH br;
        HGDIOBJ ob, op;
        int lw = (int)(2.5 * g_s * SSC + 0.5), mr = (int)(4.5 * g_s * SSC + 0.5);
        np = series_pts(p, rr, xv, xs, ys);
        if (np < 2) continue;
        pn = CreatePen(PS_SOLID, lw, col);
        op = SelectObject(d, pn);
        MoveToEx(d, BX(g, xs[0]), BY(g, ys[0]), NULL);
        for (i = 1; i < np; i++) LineTo(d, BX(g, xs[i]), BY(g, ys[i]));
        SelectObject(d, op); DeleteObject(pn);
        br = CreateSolidBrush(C(K_CARD)); ringp = CreatePen(PS_SOLID, SSC * 2, col);
        ob = SelectObject(d, br); op = SelectObject(d, ringp);
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS && i <= xv; i++) {      /* wickets */
            if (p->wicket_in_over[i - 1] > 0) {
                int cx = BX(g, i), cy = BY(g, rr ? rr_val(p, i) : (double)p->cumulative_runs[i - 1]);
                Ellipse(d, cx - mr, cy - mr, cx + mr + 1, cy + mr + 1);
            }
        }
        SelectObject(d, ob); SelectObject(d, op); DeleteObject(br); DeleteObject(ringp);
    }
}
static void plot_bars(HDC d, const Geo *g, int k, double prog)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->overs, i, maxv = 0, bands = 5;
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    double slot, barw;
    plot_grid(d, g, 0);
    if (n < 1) return;
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    for (i = 0; i < n; i++) if (p->runs_per_over[i] > maxv) maxv = p->runs_per_over[i];
    slot = (double)(g->px1 - g->px0) / n;
    barw = slot * 0.62;
    for (i = 0; i < n; i++) {
        double st = (double)i / n * 0.45, e = ease_out((prog - st) / 0.55);
        double v = p->runs_per_over[i] * e;
        double x0 = (g->px0 - g->bx0) + slot * i + (slot - barw) / 2.0, x1 = x0 + barw;
        double y1 = gy(g, 0) - g->by0, y0 = gy(g, v) - g->by0;
        COLORREF col = (p->runs_per_over[i] == maxv) ? lerp_col(acc, C(K_GOLD), 0.92) : acc;
        int b;
        if (y1 - y0 < 1.0) continue;
        for (b = 0; b < bands; b++) {
            double ya = y0 + (y1 - y0) * b / bands, yb = y0 + (y1 - y0) * (b + 1) / bands;
            COLORREF c = lerp_col(lighten(col, 0.22), col, (double)b / (bands - 1));
            fill(d, (int)(x0 * SSC), (int)(ya * SSC), (int)(x1 * SSC), (int)(yb * SSC) + 1, c);
        }
    }
}
/* Renders the plot at 2x into a memory bitmap and shrinks it with HALFTONE: smooth, anti-aliased lines. */
static void render_plot(const Geo *g, int view, double prog)
{
    int bw = g->bx1 - g->bx0, bh = g->by1 - g->by0, W = bw * SSC, H = bh * SSC;
    HDC sdc = GetDC(NULL), big = CreateCompatibleDC(sdc), small_;
    HBITMAP bb = CreateCompatibleBitmap(sdc, W, H);
    HGDIOBJ ob = SelectObject(big, bb), os;

    fill(big, 0, 0, W, H, C(K_CARD));
    if (view == VIEW_WORM || view == VIEW_RR) plot_lines(big, g, view == VIEW_RR, prog);
    else plot_bars(big, g, view == VIEW_MAN2 ? 1 : 0, prog);
    if (!g_plot || g_plot_w != bw || g_plot_h != bh) {
        if (g_plot) DeleteObject(g_plot);
        g_plot = CreateCompatibleBitmap(sdc, bw, bh);
        g_plot_w = bw; g_plot_h = bh;
    }
    small_ = CreateCompatibleDC(sdc);
    os = SelectObject(small_, g_plot);
    SetStretchBltMode(small_, HALFTONE);
    SetBrushOrgEx(small_, 0, 0, NULL);
    StretchBlt(small_, 0, 0, bw, bh, big, 0, 0, W, H, SRCCOPY);
    SelectObject(small_, os); DeleteDC(small_);
    SelectObject(big, ob); DeleteObject(bb); DeleteDC(big);
    ReleaseDC(NULL, sdc);
}
static void show_plot(HDC dc, const Geo *g, int view, double prog)
{
    int key = view * 100000 + g_match_gen * 100 + ((g_w ^ (g_h << 3)) & 63);
    HDC t;
    if (!g_plot_valid || g_plot_key != key || prog < 1.0) {
        render_plot(g, view, prog);
        g_plot_key = key;
        g_plot_valid = (prog >= 1.0);
    }
    t = CreateCompatibleDC(dc);
    SelectObject(t, g_plot);
    BitBlt(dc, g->bx0, g->by0, g->bx1 - g->bx0, g->by1 - g->by0, t, 0, 0, SRCCOPY);
    DeleteDC(t);
}

/* ------------------------------------------------------------ chart views */
static void y_labels(HDC dc, const Geo *g, int dec)
{
    int t;
    char b[16];
    (void)dec;
    for (t = 0; t <= g->ymax; t += g->ystep) {
        snprintf(b, sizeof b, "%d", t);
        txtc(dc, g->px0 - U(10), (int)(gy(g, t) + 0.5), b, C(K_MUTED), f_cap, 2);
    }
}
static void tip_start(const char *head, COLORREF hc)
{
    g_tip.n = 1;
    snprintf(g_tip.text[0], sizeof g_tip.text[0], "%s", head);
    g_tip.col[0] = hc;
}
static void tip_add(COLORREF c, const char *fmt, ...)
{
    va_list ap;
    if (g_tip.n >= 4) return;
    va_start(ap, fmt);
    vsnprintf(g_tip.text[g_tip.n], sizeof g_tip.text[0], fmt, ap);
    va_end(ap);
    g_tip.col[g_tip.n++] = c;
}
static void legend_item(HDC dc, int *rx, int yc, COLORREF col, const char *label)
{
    int w = tw(dc, f_cap, label);
    *rx -= w;
    txtc(dc, *rx, yc, label, C(K_MUTED), f_cap, 0);
    *rx -= U(34);
    line_(dc, *rx, yc, *rx + U(22), yc, col, 3, PS_SOLID);
    circle(dc, *rx + U(11), yc, U(4), C(K_CARD), col, 2);
    *rx -= U(14);
}

static void view_lines(HDC dc, int fx, int fy, int fw, int fh, int rr)
{
    Geo g;
    double prog = prog_of(g_t_chart, 1200, 0);
    int i, st, k;
    char b[96];
    make_geo(&g, rr ? VIEW_RR : VIEW_WORM, fx + U(52), fy + U(66), fx + fw - U(26), fy + fh - U(40));
    show_plot(dc, &g, rr ? VIEW_RR : VIEW_WORM, prog);
    y_labels(dc, &g, rr);
    st = x_step(&g);
    for (i = 0; i <= g.n; i += st) {
        snprintf(b, sizeof b, "Ov %d", i);
        txtc(dc, (int)(gx(&g, i) + 0.5), g.py1 + U(16), b, C(K_MUTED), f_cap, 1);
    }
    if (g_hover_content && g_cmx >= g.px0 - U(4) && g_cmx <= g.px1 + U(4) && g_cmy >= g.py0 - U(4) && g_cmy <= g.py1 + U(4)) {
        int v = (int)(((g_cmx - g.px0) * (double)g.n) / (g.px1 - g.px0) + 0.5), hx;
        if (v < 0) v = 0;
        if (v > g.n) v = g.n;
        hx = (int)(gx(&g, v) + 0.5);
        line_(dc, hx, g.py0, hx, g.py1, C(K_FAINT), 1, PS_DOT);
        for (k = 0; k < 2; k++) {
            const InningsPlot *p = &g_match.in[k];
            double val;
            if (p->overs < 1 || (rr && v < 1)) continue;
            val = rr ? (v > p->overs ? rr_of(p) : rr_val(p, v)) : (double)runs_at(p, v);
            circle(dc, hx, (int)(gy(&g, val) + 0.5), U(5), C(K_CARD), k ? C(K_T2) : C(K_T1), 2);
        }
        snprintf(b, sizeof b, "After over %d", v);
        tip_start(b, C(K_ONACC));
        if (rr) {
            for (k = 0; k < 2; k++) {
                const InningsPlot *p = &g_match.in[k];
                double val = (v < 1) ? 0.0 : (v > p->overs ? rr_of(p) : rr_val(p, v));
                tip_add(k ? lighten(C(K_T2), 0.45) : lighten(C(K_T1), 0.5), "%s   RR %.2f", p->team, val);
            }
        } else {
            int r0 = runs_at(&g_match.in[0], v), r1 = runs_at(&g_match.in[1], v);
            tip_add(lighten(C(K_T1), 0.5), "%s   %d/%d", g_match.in[0].team, r0, wkts_at(&g_match.in[0], v));
            tip_add(lighten(C(K_T2), 0.45), "%s   %d/%d", g_match.in[1].team, r1, wkts_at(&g_match.in[1], v));
            if (r0 == r1) tip_add(C(K_GREEN), "Scores level");
            else tip_add(C(K_GREEN), "%s lead by %d", r0 > r1 ? g_match.in[0].team : g_match.in[1].team, abs(r0 - r1));
        }
    }
}

static void view_bars(HDC dc, int fx, int fy, int fw, int fh, int k)
{
    const InningsPlot *p = &g_match.in[k];
    Geo g;
    double prog = prog_of(g_t_chart, 1200, 0), slot;
    int n = p->overs, i, st = 1, hover = -1;
    char b[96];
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    make_geo(&g, k ? VIEW_MAN2 : VIEW_MAN1, fx + U(52), fy + U(70), fx + fw - U(24), fy + fh - U(40));
    if (n < 1) { txtc(dc, fx + fw / 2, fy + fh / 2, "No chart data available", C(K_MUTED), f_body, 1); return; }
    if (n > SG5_MAX_OVERS) n = SG5_MAX_OVERS;
    show_plot(dc, &g, k ? VIEW_MAN2 : VIEW_MAN1, prog);
    y_labels(dc, &g, 0);
    slot = (double)(g.px1 - g.px0) / n;
    if (slot < U(26)) st = 2;
    if (slot < U(13)) st = 5;
    for (i = 0; i < n; i++) {
        if (i % st == 0) {
            snprintf(b, sizeof b, "%d", i + 1);
            txtc(dc, (int)(g.px0 + slot * i + slot / 2), g.py1 + U(16), b, C(K_MUTED), f_cap, 1);
        }
    }
    txtc(dc, (g.px0 + g.px1) / 2, g.py1 + U(34), "Overs", C(K_MUTED), f_capb, 1);
    {
        char lab[48];
        int lx2 = fx + fw - U(16);
        snprintf(lab, sizeof lab, "Average %.2f runs / over", rr_of(p));
        lx2 -= tw(dc, f_cap, lab);
        txtc(dc, lx2, fy + U(22), lab, C(K_MUTED), f_cap, 0);
        line_(dc, lx2 - U(30), fy + U(22), lx2 - U(8), fy + U(22), C(K_MUTED), 1, PS_DASH);
    }
    if (prog >= 0.95) {
        double avg = rr_of(p);
        int ay = (int)(gy(&g, avg) + 0.5);
        for (i = 0; i < n; i++) {
            int cx = (int)(g.px0 + slot * i + slot / 2), top = (int)(gy(&g, p->runs_per_over[i]) + 0.5);
            if (n <= 24 && p->runs_per_over[i] > 0) {
                snprintf(b, sizeof b, "%d", p->runs_per_over[i]);
                txtc(dc, cx, top - U(10), b, C(K_TEXT), f_capb, 1);
            }
            if (p->wicket_in_over[i] > 0) {
                circle(dc, cx, top - U(30), U(9), C(K_RED), C(K_RED), 0);
                txtc(dc, cx, top - U(30), "W", RGB(255, 255, 255), f_capb, 1);
            }
        }
        line_(dc, g.px0, ay, g.px1, ay, C(K_MUTED), 1, PS_DASH);
    }
    if (g_hover_content && g_cmx >= g.px0 && g_cmx <= g.px1 && g_cmy >= g.py0 - U(30) && g_cmy <= g.py1) {
        hover = (int)((g_cmx - g.px0) / slot);
        if (hover >= n) hover = n - 1;
        if (hover >= 0) {
            int x0 = (int)(g.px0 + slot * hover + slot * 0.16), x1 = (int)(g.px0 + slot * hover + slot * 0.84);
            int top = (int)(gy(&g, p->runs_per_over[hover]) + 0.5), wk = p->wicket_in_over[hover];
            outline_rrect(dc, x0 - 2, top - 2, x1 + 2, g.py1, U(3), C(K_TEXT), 2, PS_SOLID);
            snprintf(b, sizeof b, "Over %d", hover + 1);
            tip_start(b, C(K_ONACC));
            tip_add(C(K_ONACC), "%d runs  (cumulative %d)", p->runs_per_over[hover], runs_at(p, hover + 1));
            if (wk > 0) tip_add(lighten(C(K_RED), 0.5), "%d wicket%s fell", wk, wk == 1 ? "" : "s");
            else tip_add(C(K_FAINT), "No wicket");
            (void)acc;
        }
    }
}

static void view_partner(HDC dc, int fx, int fy, int fw, int fh, int k)
{
    const InningsPlot *p = &g_match.in[k];
    int n = p->num_partnerships, i, mx = 1, rh, top, namew = U(190), bx0, bx1, hover = -1;
    COLORREF acc = k ? C(K_T2) : C(K_T1);
    double el = since(g_t_chart);
    if (n > SG5_MAX_PSHIPS) n = SG5_MAX_PSHIPS;
    if (n < 1) { txtc(dc, fx + fw / 2, fy + fh / 2, "No partnership data available", C(K_MUTED), f_body, 1); return; }
    for (i = 0; i < n; i++) if (p->pship_runs[i] > mx) mx = p->pship_runs[i];
    top = fy + U(74);
    rh = (fy + fh - U(10) - top) / n;
    if (rh > U(40)) rh = U(40);
    if (fw < U(520)) namew = U(130);
    bx0 = fx + U(60) + namew; bx1 = fx + fw - U(92);
    for (i = 0; i < n; i++) {
        int ry = top + i * rh, cy = ry + rh / 2, bh = rh - U(12), bwid, over;
        double e = ease_out((el - i * 80.0) / 600.0);
        char b[160], nm[160], fnm[160];
        if (e < 1.0) g_busy = 1;
        if (bh > U(22)) bh = U(22);
        bwid = (int)((bx1 - bx0) * ((double)p->pship_runs[i] / mx) * e);
        over = g_hover_content && g_cmx >= fx && g_cmx <= fx + fw && g_cmy >= ry && g_cmy < ry + rh;
        if (over) { hover = i; rrect(dc, fx + U(8), ry + 1, fx + fw - U(8), ry + rh - 1, U(8), C(K_HOVER), C(K_HOVER), 0); }
        circle(dc, fx + U(30), cy, U(12), C(K_THEAD), C(K_BORDER), 1);
        snprintf(b, sizeof b, "W%d", i + 1);
        txtc(dc, fx + U(30), cy, b, C(K_MUTED), f_capb, 1);
        if (p->pship_bat2[i][0]) snprintf(nm, sizeof nm, "%s & %s%s", p->pship_bat1[i], p->pship_bat2[i], p->pship_unbeaten[i] ? "*" : "");
        else snprintf(nm, sizeof nm, "%s%s", p->pship_bat1[i], p->pship_unbeaten[i] ? "*" : "");
        fit(dc, f_body, nm, namew, fnm, sizeof fnm);
        txtc(dc, fx + U(52), cy, fnm, C(K_TEXT), f_body, 0);
        rrect(dc, bx0, cy - bh / 2, bx1, cy + bh / 2, U(7), C(K_THEAD), C(K_THEAD), 0);
        if (bwid > U(4)) rrect(dc, bx0, cy - bh / 2, bx0 + bwid, cy + bh / 2, U(7), p->pship_unbeaten[i] ? C(K_GOLD) : acc, acc, 0);
        snprintf(b, sizeof b, "%d", (int)(p->pship_runs[i] * e + 0.5));
        txtc(dc, bx1 + U(12), cy, b, C(K_TEXT), f_bold, 0);
        snprintf(b, sizeof b, "%d%%", p->total_runs ? p->pship_runs[i] * 100 / p->total_runs : 0);
        txtc(dc, fx + fw - U(16), cy, b, C(K_MUTED), f_cap, 2);
    }
    if (hover >= 0) {
        char b[48];
        snprintf(b, sizeof b, "Wicket %d partnership", hover + 1);
        tip_start(b, C(K_ONACC));
        tip_add(C(K_ONACC), "%s%s%s", p->pship_bat1[hover], p->pship_bat2[hover][0] ? " & " : "", p->pship_bat2[hover]);
        tip_add(C(K_GOLD), "%d runs%s", p->pship_runs[hover], p->pship_unbeaten[hover] ? "  (unbeaten)" : "");
    }
}

static const char *const CT_FULL[NCTAB] = {"Worm Chart", "Manhattan (Inn 1)", "Manhattan (Inn 2)", "Partnerships (Inn 1)", "Partnerships (Inn 2)", "Run Rate"};
static const char *const CT_SHORT[NCTAB] = {"Worm", "Manhattan 1", "Manhattan 2", "Partnerships 1", "Partnerships 2", "Run Rate"};
static const char *const CT_TINY[NCTAB] = {"Worm", "Man 1", "Man 2", "Part 1", "Part 2", "RR"};
static const char *const RT_FULL[NRTAB] = {"1st Innings", "2nd Innings", "Awards"};
static const char *const RT_SHORT[NRTAB] = {"1st Inn", "2nd Inn", "Awards"};

static void draw_chart_card(HDC dc, int x, int y, int w, int h)
{
    const char *const *labs[3];
    int fx = x + U(16), fy = y + U(80), fw = w - U(32), fh = h - U(80) - U(64), lx;
    char title[200], sub[100];
    labs[0] = CT_FULL; labs[1] = CT_SHORT; labs[2] = CT_TINY;
    card(dc, x, y, x + w, y + h, U(14));
    tab_strip(dc, x + U(16), y + U(14), U(40), w - U(32), labs, NCTAB, (int)g_view, ID_CTAB, &g_ct_l, &g_ct_r, &g_ct_init, 1);
    line_(dc, x + 1, y + U(68), x + w - 1, y + U(68), C(K_BORDER), 1, PS_SOLID);
    rrect(dc, fx, fy, fx + fw, fy + fh, U(12), C(K_CARD), C(K_BORDER), 1);

    switch (g_view) {
    case VIEW_WORM: snprintf(title, sizeof title, "WORM CHART: %s vs %s", g_match.in[0].team, g_match.in[1].team); snprintf(sub, sizeof sub, "Cumulative Runs Progression & Wickets"); break;
    case VIEW_RR: snprintf(title, sizeof title, "RUN RATE: %s vs %s", g_match.in[0].team, g_match.in[1].team); snprintf(sub, sizeof sub, "Run rate after each over (rings mark wickets)"); break;
    case VIEW_MAN1: case VIEW_MAN2: snprintf(title, sizeof title, "MANHATTAN: %s", g_match.in[g_view == VIEW_MAN2].team); snprintf(sub, sizeof sub, "Runs per over \xB7 W marks a wicket \xB7 gold = best over"); break;
    default: snprintf(title, sizeof title, "PARTNERSHIPS: %s", g_match.in[g_view == VIEW_PS2].team); snprintf(sub, sizeof sub, "Runs added by each batting pair"); break;
    }
    {
        char ft[200], l1[130], l2[130];
        int legw = 0;
        if (g_view == VIEW_WORM || g_view == VIEW_RR) {
            snprintf(l1, sizeof l1, "%s (%d/%d)", g_match.in[0].team, g_match.in[0].total_runs, g_match.in[0].wickets);
            snprintf(l2, sizeof l2, "%s (%d/%d)", g_match.in[1].team, g_match.in[1].total_runs, g_match.in[1].wickets);
            legw = tw(dc, f_cap, l1) > tw(dc, f_cap, l2) ? tw(dc, f_cap, l1) : tw(dc, f_cap, l2);
            legw += U(48);
        }
        fit(dc, f_bold, title, fw - U(32) - legw - U(16), ft, sizeof ft);
        txtc(dc, fx + U(16), fy + U(22), ft, C(K_TEXT), f_bold, 0);
        txtc(dc, fx + U(16), fy + U(42), sub, C(K_MUTED), f_cap, 0);
        if (legw) {
            lx = fx + fw - U(16);
            legend_item(dc, &lx, fy + U(22), C(K_T1), l1);
            lx = fx + fw - U(16);
            legend_item(dc, &lx, fy + U(42), C(K_T2), l2);
        }
    }
    switch (g_view) {
    case VIEW_WORM: view_lines(dc, fx, fy, fw, fh, 0); break;
    case VIEW_RR: view_lines(dc, fx, fy, fw, fh, 1); break;
    case VIEW_MAN1: view_bars(dc, fx, fy, fw, fh, 0); break;
    case VIEW_MAN2: view_bars(dc, fx, fy, fw, fh, 1); break;
    case VIEW_PS1: view_partner(dc, fx, fy, fw, fh, 0); break;
    default: view_partner(dc, fx, fy, fw, fh, 1); break;
    }
    line_(dc, x + 1, y + h - U(54), x + w - 1, y + h - U(54), C(K_BORDER), 1, PS_SOLID);
    button(dc, ID_DL_SVG, x + U(16), y + h - U(44), x + U(16) + tw(dc, f_semi, "Download SVG Vector") + U(46), y + h - U(14), "Download SVG Vector", BS_OUTLINE, IC_DL, f_semi);
    {
        int b1 = x + U(16) + tw(dc, f_semi, "Download SVG Vector") + U(46) + U(10);
        int b2 = b1 + tw(dc, f_semi, "Download Pure C BMP (24bpp)") + U(46);
        button(dc, ID_DL_BMP, b1, y + h - U(44), b2, y + h - U(14), "Download Pure C BMP (24bpp)", BS_OUTLINE, IC_DL, f_semi);
        if (x + w - U(16) - tw(dc, f_cap, "Engine: Components 1-5 \xB7 Pure C99 \xB7 Win32/GDI") > b2 + U(16))
            txtc(dc, x + w - U(16), y + h - U(29), "Engine: Components 1-5 \xB7 Pure C99 \xB7 Win32/GDI", C(K_MUTED), f_cap, 2);
    }
    g_chart_win.left = x; g_chart_win.top = y + g_oy; g_chart_win.right = x + w; g_chart_win.bottom = y + h + g_oy;
}

/* ----------------------------------------------------------- scorecard card */
static RECT g_inner;                         /* inner scroll rectangle, content coordinates */
static int row_hot(int x, int y, int w, int h)
{
    return g_hover_content && g_cmx >= x && g_cmx < x + w && g_cmy >= y && g_cmy < y + h &&
           g_cmy >= g_inner.top && g_cmy < g_inner.bottom;
}
static void thead(HDC dc, int x, int y, int w, const char *first, const char *const *cols, const int *right, int n)
{
    int i;
    rrect(dc, x, y, x + w, y + U(28), U(7), C(K_THEAD), C(K_THEAD), 0);
    SetTextCharacterExtra(dc, U(1));
    txtc(dc, x + U(14), y + U(14), first, C(K_MUTED), f_capb, 0);
    for (i = 0; i < n; i++) txtc(dc, right[i], y + U(14), cols[i], C(K_MUTED), f_capb, 2);
    SetTextCharacterExtra(dc, 0);
}
static void sect_title(HDC dc, int x, int y, int w, const char *left, const char *right)
{
    txtc(dc, x + U(4), y, left, C(K_ACCENT), f_bold, 0);
    if (right && right[0]) txtc(dc, x + w - U(4), y, right, C(K_MUTED), f_semi, 2);
}
static int draw_bat(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    const InningsPlot *p = &g_match.in[k];
    double el = since(g_t_rtab);
    char buf[160], ov[16], nm[160];
    static const char *const cols[6] = {"R", "B", "4S", "6S", "SR", "BND%"};
    static const int cw[6] = {38, 34, 32, 32, 54, 60};
    int right[6], i, e, fours = 0, sixes = 0, nmw;

    snprintf(buf, sizeof buf, "%s Batting", p->team);
    fmt_overs(p->balls, ov, sizeof ov);
    {
        char rt[60];
        snprintf(rt, sizeof rt, "%d/%d (%s ov)", p->total_runs, p->wickets, ov);
        sect_title(dc, x, y + U(12), w, buf, rt);
    }
    e = x + w - U(8);
    for (i = 5; i >= 0; i--) { right[i] = e; e -= U(cw[i]); }
    nmw = right[0] - U(cw[0]) - x - U(28);
    thead(dc, x, y + U(32), w, "BATTER", cols, right, 6);
    for (i = 0; i < c->nbat; i++) {
        const Sg5BatRow *r = &c->bat[i];
        int ry = y + U(66) + i * U(34), rh = U(34), cy = ry + rh / 2;
        double re = ease_out((el - i * 45.0) / 360.0);
        int off = (int)((1.0 - re) * U(18));
        COLORREF tc = fade(C(K_TEXT), re), mc = fade(C(K_MUTED), re);
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh)) rrect(dc, x, ry + 1, x + w, ry + rh - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        snprintf(nm, sizeof nm, "%s%s", r->name, r->out ? "" : "*");
        fit(dc, f_semi, nm, nmw, buf, sizeof buf);
        txtc(dc, x + U(14) + off, cy, buf, tc, f_semi, 0);
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, right[0] + off, cy, buf, tc, f_bold, 2);
        snprintf(buf, sizeof buf, "%d", r->balls); txtc(dc, right[1] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->fours); txtc(dc, right[2] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->sixes); txtc(dc, right[3] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%.1f", r->sr); txtc(dc, right[4] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d%%", (int)(r->bnd_pct + 0.5)); txtc(dc, right[5] + off, cy, buf, mc, f_body, 2);
        line_(dc, x, ry + rh - 1, x + w, ry + rh - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
        fours += r->fours; sixes += r->sixes;
    }
    y += U(66) + c->nbat * U(34) + U(8);
    snprintf(buf, sizeof buf, "Total: %d/%d (%s ov) \xB7 Run rate %.2f \xB7 4s: %d \xB7 6s: %d   (* not out)", p->total_runs, p->wickets, ov, rr_of(p), fours, sixes);
    txtc(dc, x + U(4), y + U(10), buf, C(K_MUTED), f_cap, 0);
    return y + U(26);
}
static int draw_fow(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    int i, lx = x + U(4), ly = y + U(12);
    char tok[120];
    if (c->nfow < 1) return y;
    txtc(dc, x + U(4), ly, "FALL OF WICKETS", C(K_MUTED), f_capb, 0);
    ly += U(22);
    for (i = 0; i < c->nfow; i++) {
        const Sg5FowRow *f = &c->fow[i];
        int tww;
        snprintf(tok, sizeof tok, "%d-%d (%s, %d.%d)", f->wkt, f->score, f->name, f->over > 0 ? f->over - 1 : 0, f->ball);
        tww = tw(dc, f_cap, tok) + U(14);
        if (lx + tww > x + w - U(4)) { lx = x + U(4); ly += U(20); }
        txtc(dc, lx, ly, tok, C(K_MUTED), f_cap, 0);
        lx += tww;
    }
    return ly + U(22);
}
static int draw_bowl(HDC dc, int x, int y, int w, int k)
{
    const Sg5Card *c = &g_card[k];
    const char *team = g_match.in[1 - k].team;
    double el = since(g_t_rtab);
    char buf[160], fn[160];
    static const char *const cols[4] = {"O", "R", "W", "ECON"};
    static const int cw[4] = {46, 46, 40, 62};
    int right[4], i, e, nmw;

    snprintf(buf, sizeof buf, "%s Bowling", team);
    sect_title(dc, x, y + U(12), w, buf, NULL);
    e = x + w - U(8);
    for (i = 3; i >= 0; i--) { right[i] = e; e -= U(cw[i]); }
    nmw = right[0] - U(cw[0]) - x - U(28);
    thead(dc, x, y + U(32), w, "BOWLER", cols, right, 4);
    for (i = 0; i < c->nbowl; i++) {
        const Sg5BowlRow *r = &c->bowl[i];
        int ry = y + U(66) + i * U(34), rh = U(34), cy = ry + rh / 2;
        double re = ease_out((el - 250.0 - i * 45.0) / 360.0);
        int off = (int)((1.0 - re) * U(18));
        COLORREF tc = fade(C(K_TEXT), re), mc = fade(C(K_MUTED), re);
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh)) rrect(dc, x, ry + 1, x + w, ry + rh - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        fit(dc, f_semi, r->name, nmw, fn, sizeof fn);
        txtc(dc, x + U(14) + off, cy, fn, tc, f_semi, 0);
        snprintf(buf, sizeof buf, "%d.%d", r->balls / 6, r->balls % 6); txtc(dc, right[0] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, right[1] + off, cy, buf, mc, f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->wickets); txtc(dc, right[2] + off, cy, buf, tc, f_bold, 2);
        snprintf(buf, sizeof buf, "%.2f", r->econ); txtc(dc, right[3] + off, cy, buf, mc, f_body, 2);
        line_(dc, x, ry + rh - 1, x + w, ry + rh - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
    }
    return y + U(66) + c->nbowl * U(34) + U(4);
}
static void award_glyph(HDC dc, int i, int cx, int cy, int s, COLORREF bg)
{
    int j;
    circle(dc, cx, cy, s / 2, bg, bg, 0);
    if (i == 0) star(dc, cx, cy + U(1), (int)(s * 0.30), C(K_GOLD));
    else if (i == 1) {
        circle(dc, cx, cy, (int)(s * 0.27), C(K_T2), C(K_T2), 0);
        txtc(dc, cx, cy, "6", RGB(255, 255, 255), f_capb, 1);
    } else if (i == 2) {
        for (j = 0; j < 3; j++) fill(dc, cx - U(7) + j * U(7), cy - U(7), cx - U(5) + j * U(7), cy + U(8), C(K_ACCENT));
        fill(dc, cx - U(8), cy - U(9), cx + U(9), cy - U(8), C(K_ACCENT));
    } else {
        POINT bp[6];
        static const double bx[6] = {0.58, 0.28, 0.48, 0.40, 0.74, 0.54}, by[6] = {0.10, 0.54, 0.54, 0.92, 0.42, 0.42};
        for (j = 0; j < 6; j++) { bp[j].x = cx - s / 2 + (int)(bx[j] * s); bp[j].y = cy - s / 2 + (int)(by[j] * s); }
        poly(dc, bp, 6, C(K_GOLD), C(K_GOLD));
    }
}
static int draw_awards(HDC dc, int x, int y, int w)
{
    static const char *const heads[4] = {"PLAYER OF THE MATCH", "MOST SIXES", "MOST WICKETS", "SUPER STRIKER"};
    const char *names[4];
    char vals[4][48], buf[120];
    double el = since(g_t_rtab);
    int i, rh = U(56), maxp = 1;
    names[0] = g_match.aw.man_of_match; names[1] = g_match.aw.most_sixes;
    names[2] = g_match.aw.most_wickets; names[3] = g_match.aw.super_striker;
    snprintf(vals[0], sizeof vals[0], "%d points", g_match.aw.mom_points);
    snprintf(vals[1], sizeof vals[1], "%d six%s", g_match.aw.sixes, g_match.aw.sixes == 1 ? "" : "es");
    snprintf(vals[2], sizeof vals[2], "%d wicket%s", g_match.aw.wickets, g_match.aw.wickets == 1 ? "" : "s");
    snprintf(vals[3], sizeof vals[3], "SR %.1f", g_match.aw.strike_rate);
    for (i = 0; i < 4; i++) {
        int ry = y + U(6) + i * (rh + U(8)), cy = ry + rh / 2, vw, avail;
        double re = ease_out((el - i * 90.0) / 420.0);
        int off = (int)((1.0 - re) * U(24));
        if (re < 1.0) g_busy = 1;
        rrect(dc, x + off, ry, x + w + off, ry + rh, U(10), fade(C(K_CARD2), re), fade(C(K_BORDER), re), 1);
        award_glyph(dc, i, x + U(32) + off, cy, U(38), fade(C(K_THEAD), re));
        txtc(dc, x + U(60) + off, cy - U(12), heads[i], fade(C(K_MUTED), re), f_capb, 0);
        vw = tw(dc, f_cap, vals[i]) + U(20);
        avail = w - U(60) - vw - U(24);
        fit(dc, f_bold, names[i][0] ? names[i] : "Not available", avail, buf, sizeof buf);
        txtc(dc, x + U(60) + off, cy + U(9), buf, fade(C(K_TEXT), re), f_bold, 0);
        rrect(dc, x + w - U(12) - vw + off, cy - U(12), x + w - U(12) + off, cy + U(12), U(8), fade(C(K_BANNER), re), fade(C(K_BORDER), re), 1);
        txtc(dc, x + w - U(12) - vw / 2 + off, cy, vals[i], fade(C(K_ACCENT), re), f_cap, 1);
    }
    y += U(6) + 4 * (rh + U(8)) + U(10);
    sect_title(dc, x, y + U(10), w, "MVP Rankings", "runs + 25 per wicket");
    for (i = 0; i < g_nmvp; i++) if (g_mvp[i].points > maxp) maxp = g_mvp[i].points;
    {
        static const char *const cols[3] = {"R", "W", "PTS"};
        int right[3], e = x + w - U(8), j;
        static const int cw[3] = {40, 36, 56};
        for (j = 2; j >= 0; j--) { right[j] = e; e -= U(cw[j]); }
        thead(dc, x, y + U(28), w, "   PLAYER", cols, right, 3);
    }
    for (i = 0; i < g_nmvp; i++) {
        const Sg5MvpRow *r = &g_mvp[i];
        int ry = y + U(62) + i * U(34), rh2 = U(34), cy = ry + rh2 / 2, barw, bx0 = x + U(150), bx1 = x + w - U(170);
        double re = ease_out((el - 380.0 - i * 45.0) / 380.0);
        int off = (int)((1.0 - re) * U(16));
        if (re < 1.0) g_busy = 1;
        if (row_hot(x, ry, w, rh2)) rrect(dc, x, ry + 1, x + w, ry + rh2 - 1, U(6), C(K_HOVER), C(K_HOVER), 0);
        snprintf(buf, sizeof buf, "%d", i + 1);
        txtc(dc, x + U(22) + off, cy, buf, fade(i == 0 ? C(K_GOLD) : C(K_FAINT), re), f_bold, 2);
        {
            char fn[120];
            fit(dc, f_semi, r->name, bx0 - x - U(40), fn, sizeof fn);
            txtc(dc, x + U(32) + off, cy, fn, fade(C(K_TEXT), re), f_semi, 0);
        }
        if (bx1 > bx0 + U(30)) {
            barw = (int)((bx1 - bx0) * ((double)r->points / maxp) * re);
            rrect(dc, bx0, cy - U(4), bx1, cy + U(4), U(4), fade(C(K_THEAD), re), fade(C(K_THEAD), re), 0);
            if (barw > U(3)) rrect(dc, bx0, cy - U(4), bx0 + barw, cy + U(4), U(4), i == 0 ? C(K_GOLD) : C(K_ACCENT), C(K_ACCENT), 0);
        }
        snprintf(buf, sizeof buf, "%d", r->runs); txtc(dc, x + w - U(8) - U(92) + off, cy, buf, fade(C(K_MUTED), re), f_body, 2);
        snprintf(buf, sizeof buf, "%d", r->wickets); txtc(dc, x + w - U(8) - U(56) + off, cy, buf, fade(C(K_MUTED), re), f_body, 2);
        snprintf(buf, sizeof buf, "%d", (int)(r->points * re + 0.5)); txtc(dc, x + w - U(8) + off, cy, buf, fade(C(K_TEXT), re), f_bold, 2);
        line_(dc, x, ry + rh2 - 1, x + w, ry + rh2 - 1, fade(C(K_BORDER), re), 1, PS_SOLID);
    }
    return y + U(62) + g_nmvp * U(34) + U(10);
}
static int strip_width(HDC dc, const char *const *labs[3], int n, int maxw)
{
    int pass, i, tot = 0;
    for (pass = 0; pass < 3; pass++) {
        tot = U(8);
        for (i = 0; i < n; i++) tot += tw(dc, f_semi, labs[pass][i]) + U(pass == 2 ? 18 : 26);
        if (tot <= maxw) break;
    }
    return tot;
}
static void draw_score_card(HDC dc, int x, int y, int w, int h)
{
    const char *const *labs[3];
    int ix = x + U(16), iy = y + U(70), iw = w - U(32), ih = h - U(70) - U(12), ty, endy, sw;
    labs[0] = RT_FULL; labs[1] = RT_SHORT; labs[2] = RT_SHORT;
    card(dc, x, y, x + w, y + h, U(14));
    txtc(dc, x + U(20), y + U(35), "Scorecard & Metrics", C(K_TEXT), f_h3, 0);
    sw = strip_width(dc, labs, NRTAB, w - U(40) - tw(dc, f_h3, "Scorecard & Metrics") - U(16));
    tab_strip(dc, x + w - U(16) - sw, y + U(16), U(38), sw + U(2), labs, NRTAB, g_rtab, ID_RTAB, &g_rt_l, &g_rt_r, &g_rt_init, 1);
    line_(dc, x + 1, y + U(68), x + w - 1, y + U(68), C(K_BORDER), 1, PS_SOLID);

    g_inner.left = ix; g_inner.top = iy; g_inner.right = ix + iw; g_inner.bottom = iy + ih;
    {
        int sv = SaveDC(dc);
        IntersectClipRect(dc, ix, iy, ix + iw, iy + ih);
        ty = iy - (int)(g_rs + 0.5);
        if (g_rtab < 2) {
            ty = draw_bat(dc, ix, ty, iw - U(8), g_rtab);
            ty = draw_bowl(dc, ix, ty, iw - U(8), g_rtab);
            ty = draw_fow(dc, ix, ty, iw - U(8), g_rtab);
        } else ty = draw_awards(dc, ix, ty, iw - U(8));
        RestoreDC(dc, sv);
    }
    endy = ty + (int)(g_rs + 0.5) - iy;
    g_rs_content = endy;
    g_rs_max = endy - ih + U(4);
    if (g_rs_max < 0) g_rs_max = 0;
    if (g_rs_goal > g_rs_max) g_rs_goal = g_rs_max;
    if (g_rs > g_rs_max) g_rs = g_rs_max;
    g_rs_rect.left = ix; g_rs_rect.top = iy + g_oy; g_rs_rect.right = ix + iw; g_rs_rect.bottom = iy + ih + g_oy;
    if (g_rs_max > 0) {
        int th = (int)((double)ih * ih / (ih + g_rs_max)), tp;
        if (th < U(30)) th = U(30);
        tp = iy + (int)((ih - th) * (g_rs / g_rs_max));
        rrect(dc, ix + iw - U(5), tp, ix + iw - U(1), tp + th, U(4), C(K_FAINT), C(K_FAINT), 0);
    }
}

/* ----------------------------------------------------------------- top bar */
static RECT g_sel_rect;
static HINSTANCE g_inst;

static void draw_topbar(HDC dc, const Lay *L)
{
    int pad = L->pad, y0 = (L->top_h - U(38)) / 2, y1 = y0 + U(38), rx = g_w - pad, dw, plw = 0, i;
    const char *tt = "CricLens \xB7 Cricket Analytics";
    const char *sub = "Course: IC103 \xB7 Group 37 \xB7 Standard C99";
    const char *dl = g_theme_goal > 0.5 ? "Light" : "Dark";
    char sel[130], fitted[130];
    int dkw = tw(dc, f_semi, dl) + U(52), upw = tw(dc, f_semi, "Upload Scorecard") + U(54), mlw = tw(dc, f_body, "Match:");
    int brand_w = pad + U(58) + (tw(dc, f_h2, tt) > tw(dc, f_cap, sub) ? tw(dc, f_h2, tt) : tw(dc, f_cap, sub));

    fill(dc, 0, 0, g_w, L->top_h, C(K_CARD));
    for (i = 0; i < 4; i++) alpha_rect(dc, 0, L->top_h + i, g_w, L->top_h + i + 1, C(K_SCRIM), 7 - i * 2);
    line_(dc, 0, L->top_h - 1, g_w, L->top_h - 1, C(K_BORDER), 1, PS_SOLID);
    brand_glyph(dc, pad, (L->top_h - U(44)) / 2, U(44));
    if (g_w >= U(1000)) {
        txtc(dc, pad + U(58), L->top_h / 2 - U(11), tt, C(K_TEXT), f_h2, 0);
        txtc(dc, pad + U(58), L->top_h / 2 + U(13), sub, C(K_MUTED), f_cap, 0);
    } else {
        txtc(dc, pad + U(58), L->top_h / 2, "CricLens", C(K_TEXT), f_h2, 0);
        brand_w = pad + U(58) + tw(dc, f_h2, "CricLens");
    }
    button(dc, ID_UPLOAD, rx - upw, y0, rx, y1, "Upload Scorecard", BS_OUTLINE, IC_PLUS, f_semi);
    rx -= upw + U(14);
    plw = (g_w >= U(1180)) ? tw(dc, f_capb, "Pure C99 Engine") + U(46) : 0;
    dw = rx - brand_w - U(30) - dkw - U(14) - plw - (plw ? U(14) : 0) - mlw - U(10);
    if (dw > U(300)) dw = U(300);
    if (dw < U(150)) dw = U(150);
    {   /* match selector */
        int open = g_dd_open, hot = (g_hot_id == ID_MATCHSEL);
        double hv = g_hv[ID_MATCHSEL];
        g_sel_rect.left = rx - dw; g_sel_rect.top = y0; g_sel_rect.right = rx; g_sel_rect.bottom = y1;
        rrect(dc, rx - dw, y0, rx, y1, U(9), lerp_col(C(K_CARD), C(K_HOVER), hv), (open || hot) ? C(K_ACCENT) : C(K_BORDER), 1);
        snprintf(sel, sizeof sel, "%s", g_ntitles > g_match_index ? g_titles[g_match_index] : "(no match)");
        fit(dc, f_semi, sel, dw - U(52), fitted, sizeof fitted);
        txtc(dc, rx - dw + U(14), (y0 + y1) / 2, fitted, C(K_TEXT), f_semi, 0);
        {
            int cx = rx - U(20), cy = (y0 + y1) / 2 + (open ? -U(1) : U(1));
            int d = open ? -U(3) : U(3);
            line_(dc, cx - U(4), cy - d / 2, cx, cy + d / 2, C(K_MUTED), 2, PS_SOLID);
            line_(dc, cx, cy + d / 2, cx + U(4), cy - d / 2, C(K_MUTED), 2, PS_SOLID);
        }
        reg(ID_MATCHSEL, rx - dw, y0, rx, y1);
    }
    txtc(dc, rx - dw - U(10), (y0 + y1) / 2, "Match:", C(K_MUTED), f_body, 2);
    rx -= dw + U(10) + mlw + U(14);
    if (plw) {
        rrect(dc, rx - plw, y0 + U(2), rx, y1 - U(2), U(8), C(K_GREENBG), lerp_col(C(K_GREENBG), C(K_GREEN), 0.35), 1);
        pulse_dot(dc, rx - plw + U(16), (y0 + y1) / 2, U(4), C(K_GREEN), C(K_GREENBG));
        txtc(dc, rx - plw + U(30), (y0 + y1) / 2, "Pure C99 Engine", C(K_GREENFG), f_capb, 0);
        rx -= plw + U(14);
    }
    button(dc, ID_DARK, rx - dkw, y0, rx, y1, dl, BS_OUTLINE, g_theme_goal > 0.5 ? IC_SUN : IC_MOON, f_semi);
}

static void draw_outer_scrollbar(HDC dc, const Lay *L)
{
    int th, tp, vh = L->view_h;
    if (g_scroll_max <= 0) return;
    th = (int)((double)vh * vh / (vh + g_scroll_max));
    if (th < U(36)) th = U(36);
    tp = L->top_h + (int)((vh - th) * (g_scroll / g_scroll_max));
    rrect(dc, g_w - U(8), tp + U(2), g_w - U(3), tp + th - U(2), U(5), C(K_FAINT), C(K_FAINT), 0);
}

static void draw_error(HDC dc, const Lay *L)
{
    double t, e;
    int x, y, w, h = U(42);
    if (!g_err[0]) return;
    t = since(g_err_t);
    if (t > 12000.0) { g_err[0] = 0; return; }
    e = ease_out(t / 300.0);
    if (t < 320.0) g_busy = 1;
    x = L->pad; w = L->cw; y = L->top_h + U(12) - (int)((1.0 - e) * U(56));
    shadow(dc, x, y, x + w, y + h, U(9), 6);
    rrect(dc, x, y, x + w, y + h, U(9), C(K_REDBG), lerp_col(C(K_REDBG), C(K_RED), 0.45), 1);
    txtc(dc, x + U(16), y + h / 2, g_err, C(K_RED), f_semi, 0);
    button(dc, ID_ERRCLOSE, x + w - U(40), y + U(7), x + w - U(8), y + h - U(7), "x", BS_OUTLINE, IC_NONE, f_semi);
}

static void draw_toast(HDC dc, const Lay *L)
{
    double t;
    int w, h = U(38), x, y;
    if (!g_toast[0]) return;
    t = since(g_toast_t);
    if (t > 3900.0) { g_toast[0] = 0; return; }
    g_busy = 1;
    w = tw(dc, f_semi, g_toast) + U(40);
    {
        double ein = ease_out(t / 300.0), eout = t > 3600.0 ? ease_out((t - 3600.0) / 300.0) : 0.0;
        x = g_w - L->pad - w + (int)((1.0 - ein) * U(40)) + (int)(eout * U(60));
    }
    y = g_h - L->stat_h - U(14) - h;
    shadow(dc, x, y, x + w, y + h, U(10), 9);
    rrect(dc, x, y, x + w, y + h, U(10), C(K_TIP), C(K_TIP), 0);
    circle(dc, x + U(16), y + h / 2, U(4), C(K_GREEN), C(K_GREEN), 0);
    txtc(dc, x + U(28), y + h / 2, g_toast, RGB(255, 255, 255), f_semi, 0);
}

static const char *hint_for(int id)
{
    static const char *const ct[NCTAB] = {"Cumulative runs, over by over  (1)", "Runs per over, first innings  (2)", "Runs per over, second innings  (3)",
                                          "Partnerships, first innings  (4)", "Partnerships, second innings  (5)", "Run rate after each over  (6)"};
    if (id == ID_DARK) return "Switch between light and dark theme  (Ctrl+D)";
    if (id == ID_UPLOAD) return "Load a scorecard file or paste scorecard lines  (Ctrl+O)";
    if (id == ID_MATCHSEL || (id >= ID_MITEM && id < ID_MITEM + MAX_TITLES)) return "Choose which match to analyse  (Left / Right arrows)";
    if (id >= ID_CTAB && id < ID_CTAB + NCTAB) return ct[id - ID_CTAB];
    if (id >= ID_RTAB && id < ID_RTAB + NRTAB) return "Scorecard tables, fall of wickets and awards";
    if (id == ID_DL_SVG) return "Save this chart as an SVG vector file";
    if (id == ID_DL_BMP) return "Save this chart as a 24-bit BMP image  (Ctrl+S)";
    if (id == ID_ABOUT) return "About CricLens and desktop shortcut  (F1)";
    return "Ready";
}
static void draw_statusbar(HDC dc, const Lay *L)
{
    char buf[160], clk[32];
    time_t now = time(NULL);
    struct tm *tmv = localtime(&now);
    int yc = (g_h - L->stat_h) + L->stat_h / 2, lend, cstart, aw;
    fill(dc, 0, g_h - L->stat_h, g_w, g_h, C(K_CARD));
    line_(dc, 0, g_h - L->stat_h, g_w, g_h - L->stat_h, C(K_BORDER), 1, PS_SOLID);
    circle(dc, L->pad + U(5), yc, U(4), C(K_GREEN), C(K_GREEN), 0);
    txtc(dc, L->pad + U(18), yc, hint_for(g_hot_id), C(K_MUTED), f_cap, 0);
    lend = L->pad + U(18) + tw(dc, f_cap, hint_for(g_hot_id));
    snprintf(buf, sizeof buf, "CricLens v1.0  |  Cricket Analytics Suite  |  Match %d of %d", g_match_index + 1, sg5_match_count());
    cstart = g_w / 2 - tw(dc, f_cap, buf) / 2;
    if (cstart > lend + U(30)) txtc(dc, g_w / 2, yc, buf, C(K_FAINT), f_cap, 1);
    aw = tw(dc, f_cap, "About  (F1)") + U(16);
    {
        double hv = g_hv[ID_ABOUT];
        txtc(dc, g_w - L->pad, yc, "About  (F1)", lerp_col(C(K_MUTED), C(K_ACCENT), hv), f_cap, 2);
        reg(ID_ABOUT, g_w - L->pad - aw, g_h - L->stat_h, g_w - L->pad + U(4), g_h);
    }
    if (tmv && strftime(clk, sizeof clk, "%I:%M %p", tmv)) txtc(dc, g_w - L->pad - aw - U(10), yc, clk, C(K_MUTED), f_cap, 2);
}

static void draw_dropdown(HDC dc)
{
    int n = g_ntitles, i, rh = U(38), w, x, y, h, full;
    double a = ease_out(g_dd_a);
    if (a <= 0.01 || n < 1) return;
    w = g_sel_rect.right - g_sel_rect.left;
    {
        int mw = 0;
        for (i = 0; i < n; i++) { int t = tw(dc, f_semi, g_titles[i]); if (t > mw) mw = t; }
        if (mw + U(76) > w) w = mw + U(76);
    }
    if (w < U(300)) w = U(300);
    if (w > g_w - U(30)) w = g_w - U(30);
    x = g_sel_rect.right - w; y = g_sel_rect.bottom + U(6);
    full = n * rh + U(12);
    h = (int)(full * a);
    shadow(dc, x, y, x + w, y + h, U(10), 8);
    rrect(dc, x, y, x + w, y + h, U(10), C(K_CARD), C(K_BORDER), 1);
    {
        int sv = SaveDC(dc);
        IntersectClipRect(dc, x + 1, y + 1, x + w - 1, y + h - 1);
        for (i = 0; i < n; i++) {
            int ry = y + U(6) + i * rh;
            double hv = g_hv[ID_MITEM + i];
            char fb[130];
            if (hv > 0.01) rrect(dc, x + U(6), ry, x + w - U(6), ry + rh - U(2), U(7), lerp_col(C(K_CARD), C(K_HOVER), hv), C(K_CARD), 0);
            fit(dc, f_semi, g_titles[i], w - U(70), fb, sizeof fb);
            txtc(dc, x + U(18), ry + rh / 2 - U(1), fb, i == g_match_index ? C(K_ACCENT) : C(K_TEXT), f_semi, 0);
            if (i == g_match_index) {
                line_(dc, x + w - U(30), ry + rh / 2, x + w - U(26), ry + rh / 2 + U(4), C(K_ACCENT), 2, PS_SOLID);
                line_(dc, x + w - U(26), ry + rh / 2 + U(4), x + w - U(18), ry + rh / 2 - U(4), C(K_ACCENT), 2, PS_SOLID);
            }
            if (g_dd_open && a > 0.9) reg(ID_MITEM + i, x + U(6), ry, x + w - U(6), ry + rh - U(2));
        }
        RestoreDC(dc, sv);
    }
}

/* ------------------------------------------------------------------- modal */
static RECT g_edit_pos;
static void rich_line(HDC dc, int x, int yc, const char *const *seg, int n)
{
    int i;
    for (i = 0; i < n; i++) {
        HFONT f = (i % 2) ? f_mono : f_cap;
        txtc(dc, x, yc, seg[i], C(K_MUTED), f, 0);
        x += tw(dc, f, seg[i]);
    }
}
static const char *base_name(const char *p)
{
    const char *s = strrchr(p, '\\'), *t = strrchr(p, '/');
    if (t && (!s || t > s)) s = t;
    return s ? s + 1 : p;
}
static void draw_modal(HDC dc)
{
    double a = ease_out(g_mod_a);
    int dw = g_w - U(40) < U(480) ? g_w - U(40) : U(480), dh = U(420), dx, dy, b2;
    char fn[200];
    if (a <= 0.005) return;
    g_busy = (g_mod_a > 0.0 && g_mod_a < 1.0) ? 1 : g_busy;
    alpha_rect(dc, 0, 0, g_w, g_h, C(K_SCRIM), (int)(120 * a));
    dx = (g_w - dw) / 2; dy = (g_h - dh) / 2 + (int)((1.0 - a) * U(22));
    if (g_modal) { reg(ID_M_BACK, 0, 0, g_w, g_h); reg(ID_M_PANEL, dx, dy, dx + dw, dy + dh); }
    shadow(dc, dx, dy, dx + dw, dy + dh, U(14), 10);
    rrect(dc, dx, dy, dx + dw, dy + dh, U(14), C(K_CARD), C(K_BORDER), 1);
    txtc(dc, dx + U(24), dy + U(36), "Upload Scorecard", C(K_TEXT), f_h3, 0);
    if (g_modal) button(dc, ID_M_CLOSE, dx + dw - U(24) - U(70), dy + U(19), dx + dw - U(24), dy + U(53), "Close", BS_OUTLINE, IC_NONE, f_semi);
    line_(dc, dx + 1, dy + U(70), dx + dw - 1, dy + U(70), C(K_BORDER), 1, PS_SOLID);

    txtc(dc, dx + U(24), dy + U(94), "Scorecard text file (Component 1 format)", C(K_TEXT), f_semi, 0);
    rrect(dc, dx + U(24), dy + U(112), dx + dw - U(24), dy + U(162), U(10), C(K_CARD2), C(K_CARD2), 0);
    outline_rrect(dc, dx + U(24), dy + U(112), dx + dw - U(24), dy + U(162), U(10), C(K_BORDER), 1, PS_DASH);
    if (g_modal) button(dc, ID_M_CHOOSE, dx + U(38), dy + U(125), dx + U(142), dy + U(149), "Choose File", BS_OUTLINE, IC_NONE, f_cap);
    else rrect(dc, dx + U(38), dy + U(125), dx + U(142), dy + U(149), U(9), C(K_CARD), C(K_BORDER), 1);
    fit(dc, f_body, g_pick[0] ? base_name(g_pick) : "no file selected", dw - U(200), fn, sizeof fn);
    txtc(dc, dx + U(154), dy + U(137), fn, g_pick[0] ? C(K_TEXT) : C(K_MUTED), f_body, 0);

    txtc(dc, dx + U(24), dy + U(186), "Or paste scorecard lines directly", C(K_TEXT), f_semi, 0);
    rrect(dc, dx + U(24), dy + U(204), dx + dw - U(24), dy + U(306), U(10), C(K_CARD2), (GetFocus() == g_edit) ? C(K_ACCENT) : C(K_BORDER), 1);
    g_edit_pos.left = dx + U(34); g_edit_pos.top = dy + U(210); g_edit_pos.right = dx + dw - U(34); g_edit_pos.bottom = dy + U(300);
    {
        static const char *const l1[5] = {"Validated by Component 1 (", "load_match_file", ") and Component 2 (", "match_validate", ")"};
        static const char *const l2[1] = {"before storing."};
        rich_line(dc, dx + U(24), dy + U(328), l1, 5);
        rich_line(dc, dx + U(24), dy + U(346), l2, 1);
    }
    line_(dc, dx + 1, dy + dh - U(66), dx + dw - 1, dy + dh - U(66), C(K_BORDER), 1, PS_SOLID);
    b2 = dx + dw - U(24);
    if (g_modal) {
        button(dc, ID_M_LOAD, b2 - U(112), dy + dh - U(52), b2, dy + dh - U(18), "Load Match", BS_PRIMARY, IC_NONE, f_semi);
        button(dc, ID_M_CANCEL, b2 - U(112) - U(10) - U(84), dy + dh - U(52), b2 - U(122), dy + dh - U(18), "Cancel", BS_OUTLINE, IC_NONE, f_semi);
    }
}

static void draw_tooltip(HDC dc)
{
    int i, wmax = 0, lh = U(22), pad = U(12), W, H, x, y;
    if (g_tip.n < 1 || g_modal || g_dd_open || g_mx < 0) return;
    for (i = 0; i < g_tip.n; i++) { int w = tw(dc, i == 0 ? f_bold : f_body, g_tip.text[i]); if (w > wmax) wmax = w; }
    W = wmax + 2 * pad; H = g_tip.n * lh + 2 * pad - U(4);
    x = g_mx + U(18); y = g_my + U(18);
    if (x + W > g_w - U(10)) x = g_mx - W - U(18);
    if (x < U(8)) x = U(8);
    if (y + H > g_h - U(36)) y = g_h - U(36) - H;
    shadow(dc, x, y, x + W, y + H, U(10), 9);
    rrect(dc, x, y, x + W, y + H, U(10), C(K_TIP), C(K_TIP), 0);
    for (i = 0; i < g_tip.n; i++)
        txtc(dc, x + pad, y + pad + lh * i + lh / 2 - U(2), g_tip.text[i], g_tip.col[i], i == 0 ? f_bold : f_body, 0);
}

/* ------------------------------------------------------------------ splash */
static void draw_splash(HDC dc)
{
    double el = since(g_t_start), t = clampd(el / SPLASH_MS, 0, 1);
    int cx = g_w / 2, cy = g_h / 2 - U(50), r, dim, bw = U(380), by = cy + U(205), k;
    COLORREF bg = RGB(11, 18, 44), gold = RGB(246, 196, 83);
    const char *stage = t < 0.3 ? "Initialising statistics engine..." : (t < 0.6 ? "Parsing match scorecards..." : (t < 0.88 ? "Building charts..." : "Ready"));
    g_busy = 1;
    vgrad(dc, 0, 0, g_w, g_h, RGB(8, 14, 36), RGB(16, 28, 64));
    for (k = 0; k < 2; k++) {
        double ph = fmod(el / 1400.0 + k * 0.5, 1.0);
        r = U(96) + (int)(ph * U(130));
        ring(dc, cx, cy, r, lerp_col(gold, bg, clampd(ph * 1.15, 0, 1)), 2);
    }
    dim = (int)(U(190) * (0.5 + 0.5 * ease_back(el / 700.0)));
    blit_rgba(dc, g_logo_splash, 256, cx - dim / 2, cy - dim / 2, dim);
    txtc(dc, cx, cy + U(140), "CricLens", lerp_col(bg, gold, clampd((el - 350) / 600.0, 0, 1)), f_score, 1);
    SetTextCharacterExtra(dc, U(3));
    txtc(dc, cx, cy + U(176), "CRICKET ANALYTICS DESKTOP", lerp_col(bg, RGB(240, 240, 250), clampd((el - 750) / 500.0, 0, 1)), f_capb, 1);
    SetTextCharacterExtra(dc, 0);
    rrect(dc, cx - bw / 2, by, cx + bw / 2, by + U(8), U(8), RGB(26, 38, 80), RGB(26, 38, 80), 0);
    r = (int)(bw * ease_out(t));
    if (r > U(8)) rrect(dc, cx - bw / 2, by, cx - bw / 2 + r, by + U(8), U(8), gold, gold, 0);
    txtc(dc, cx, by + U(28), stage, RGB(150, 160, 200), f_cap, 1);
}

/* -------------------------------------------------------------------- scene */
static void set_oy(HDC dc, int v) { g_oy = v; SetViewportOrgEx(dc, 0, v, NULL); }
static void draw_content(HDC dc, const Lay *L, int base)
{
    int dy = (int)((1.0 - prog_of(g_t_enter, 650, 0)) * U(26));
    set_oy(dc, base + dy);
    draw_match_card(dc, L->pad, L->mc_y, L->cw, L->mc_h);
    dy = (int)((1.0 - prog_of(g_t_enter, 650, 120)) * U(26));
    set_oy(dc, base + dy);
    draw_chart_card(dc, L->pad, L->pn_y, L->lw, L->pn_h);
    dy = (int)((1.0 - prog_of(g_t_enter, 650, 240)) * U(26));
    set_oy(dc, base + dy);
    draw_score_card(dc, L->rx, L->pn_y, L->rw, L->pn_h);
    set_oy(dc, base);
}
static void draw_scene(HDC dc)
{
    Lay L = lay();
    int sv, base;
    g_busy = 0; g_idle = 0; g_ntg = 0; g_tip.n = 0; g_oy = 0; g_clip_on = 0;
    fill(dc, 0, 0, g_w, g_h, C(K_BG));
    if (g_splash) { draw_splash(dc); return; }
    g_scroll_max = L.total - L.view_h;
    if (g_scroll_max < 0) g_scroll_max = 0;
    if (g_scroll_goal > g_scroll_max) g_scroll_goal = g_scroll_max;
    if (g_scroll > g_scroll_max) g_scroll = g_scroll_max;
    sv = SaveDC(dc);
    IntersectClipRect(dc, 0, L.top_h, g_w, g_h - L.stat_h);
    g_clipwin.left = 0; g_clipwin.top = L.top_h; g_clipwin.right = g_w; g_clipwin.bottom = g_h - L.stat_h;
    g_clip_on = 1;
    base = L.top_h - (int)(g_scroll + 0.5);
    g_cmx = g_mx; g_cmy = g_my - base;
    g_hover_content = g_mx >= 0 && g_my >= L.top_h && g_my < g_h - L.stat_h && !g_modal && !g_dd_open && g_mod_a < 0.01;
    draw_content(dc, &L, base);
    RestoreDC(dc, sv);
    g_oy = 0; g_clip_on = 0;
    draw_topbar(dc, &L);
    draw_outer_scrollbar(dc, &L);
    draw_error(dc, &L);
    draw_statusbar(dc, &L);
    draw_toast(dc, &L);
    draw_dropdown(dc);
    draw_modal(dc);
    draw_tooltip(dc);
}

/* ----------------------------------------------------------------- actions */
static void select_view(View v) { g_view = v; g_t_chart = GetTickCount(); g_plot_valid = 0; }
static void select_rtab(int t) { g_rtab = t; g_t_rtab = GetTickCount(); g_rs = g_rs_goal = 0; }
static void set_match(int idx)
{
    if (idx == g_match_index || idx < 0 || idx >= sg5_match_count()) return;
    g_match_index = idx;
    load_current();
}
static void change_match(int delta)
{
    int n = sg5_match_count();
    if (n < 1) return;
    set_match((g_match_index + delta + n) % n);
}
static void toggle_theme(void)
{
    g_theme_goal = g_theme_goal > 0.5 ? 0.0 : 1.0;
    cl_apply_titlebar(g_hwnd, g_theme_goal > 0.5);
    toast(g_theme_goal > 0.5 ? "Dark theme on" : "Light theme on");
}
static void open_modal(void)
{
    g_modal = 1; g_dd_open = 0; g_pick[0] = 0;
    SetWindowTextA(g_edit, "");
}
static void close_modal(void)
{
    g_modal = 0;
    ShowWindow(g_edit, SW_HIDE);
    SetFocus(g_hwnd);
}
static void choose_file(HWND w)
{
    OPENFILENAMEA ofn;
    char path[MAX_PATH] = "";
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = "Scorecard text (*.txt;*.csv)\0*.txt;*.csv\0All files (*.*)\0*.*\0";
    ofn.lpstrFile = path; ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameA(&ofn)) {
        snprintf(g_pick, sizeof g_pick, "%s", path);
        SetWindowTextA(g_edit, "");
    }
}
static void do_load(void)
{
    char err[256] = "", path[MAX_PATH] = "", tmp[MAX_PATH] = "", msg[220];
    int len = GetWindowTextLengthA(g_edit), usetmp = 0, ok;
    if (len > 0) {
        char *text = (char *)malloc((size_t)len + 2);
        FILE *f;
        if (!text) return;
        GetWindowTextA(g_edit, text, len + 1);
        GetTempPathA(MAX_PATH, tmp);
        GetTempFileNameA(tmp, "CLS", 0, path);
        f = fopen(path, "wb");
        if (f) {
            const char *s;
            for (s = text; *s; s++) if (*s != '\r') fputc(*s, f);        /* normalise line endings */
            fclose(f);
            usetmp = 1;
        }
        free(text);
        if (!usetmp) { set_error("Could not create a temporary file for the pasted scorecard."); return; }
    } else if (g_pick[0]) snprintf(path, sizeof path, "%s", g_pick);
    else { set_error("Choose a scorecard file or paste scorecard lines first."); return; }
    ok = sg5_add_from_file(path, err, sizeof err);
    if (usetmp) DeleteFileA(path);
    if (ok) {
        g_err[0] = 0;
        g_match_index = sg5_match_count() - 1;
        load_current();
        close_modal();
        snprintf(msg, sizeof msg, "Match loaded: %s vs %s", g_match.in[0].team, g_match.in[1].team);
        toast(msg);
    } else set_error(err[0] ? err : "The scorecard could not be read.");
}
static void svg_runrate(FILE *f)
{
    int w = 760, h = 420, k, i, n = 1;
    double mx = 4.0;
    for (k = 0; k < 2; k++) {
        const InningsPlot *p = &g_match.in[k];
        if (p->overs > n) n = p->overs;
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++) if (rr_val(p, i) > mx) mx = rr_val(p, i);
    }
    mx = ceil(mx) + 1;
    fprintf(f, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\">\n", w, h, w, h);
    fprintf(f, "<rect width=\"%d\" height=\"%d\" fill=\"#ffffff\"/>\n", w, h);
    fprintf(f, "<text x=\"%d\" y=\"30\" font-family=\"sans-serif\" font-size=\"18\" font-weight=\"bold\">RUN RATE: %s vs %s</text>\n", 60, g_match.in[0].team, g_match.in[1].team);
    fprintf(f, "<line x1=\"60\" y1=\"%d\" x2=\"%d\" y2=\"%d\" stroke=\"#94a3b8\"/><line x1=\"60\" y1=\"60\" x2=\"60\" y2=\"%d\" stroke=\"#94a3b8\"/>\n", h - 50, w - 30, h - 50, h - 50);
    for (k = 0; k < 2; k++) {
        const InningsPlot *p = &g_match.in[k];
        fprintf(f, "<polyline fill=\"none\" stroke=\"%s\" stroke-width=\"2.5\" points=\"", k ? "#b91c26" : "#2454a6");
        for (i = 1; i <= p->overs && i <= SG5_MAX_OVERS; i++)
            fprintf(f, "%.1f,%.1f ", 60.0 + (w - 90.0) * i / n, (h - 50.0) - (h - 110.0) * rr_val(p, i) / mx);
        fprintf(f, "\"/>\n<text x=\"%d\" y=\"%d\" font-family=\"sans-serif\" font-size=\"13\" fill=\"%s\">%s</text>\n", 420, 30 + k * 18, k ? "#b91c26" : "#2454a6", p->team);
    }
    fprintf(f, "</svg>\n");
}
static void save_dialog_path(HWND w, const char *defname, const char *filter, const char *ext, char *path, size_t n, int *ok)
{
    OPENFILENAMEA ofn;
    snprintf(path, n, "%s", defname);
    ZeroMemory(&ofn, sizeof ofn);
    ofn.lStructSize = sizeof ofn; ofn.hwndOwner = w;
    ofn.lpstrFilter = filter; ofn.lpstrFile = path; ofn.nMaxFile = (DWORD)n; ofn.lpstrDefExt = ext;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    *ok = GetSaveFileNameA(&ofn);
}
static void do_svg(HWND w)
{
    static const char *const names[VIEW_COUNT] = {"worm", "manhattan1", "manhattan2", "partnerships1", "partnerships2", "runrate"};
    char path[MAX_PATH], def[80], msg[MAX_PATH + 40];
    int ok;
    FILE *f;
    snprintf(def, sizeof def, "CricLens_%s.svg", names[g_view]);
    save_dialog_path(w, def, "SVG vector image (*.svg)\0*.svg\0", "svg", path, sizeof path, &ok);
    if (!ok) return;
    f = fopen(path, "w");
    if (!f) { set_error("The SVG file could not be written."); return; }
    switch (g_view) {
    case VIEW_WORM: sg5_worm_svg(f, &g_match); break;
    case VIEW_MAN1: sg5_manhattan_svg(f, &g_match.in[0], sg5_max_over_runs(&g_match)); break;
    case VIEW_MAN2: sg5_manhattan_svg(f, &g_match.in[1], sg5_max_over_runs(&g_match)); break;
    case VIEW_PS1: sg5_partnership_svg(f, &g_match.in[0]); break;
    case VIEW_PS2: sg5_partnership_svg(f, &g_match.in[1]); break;
    default: svg_runrate(f); break;
    }
    fclose(f);
    snprintf(msg, sizeof msg, "SVG saved: %s", base_name(path));
    toast(msg);
}
static int export_region_bmp(const char *path, RECT rc)
{
    int w, h, ok = 0;
    size_t stride;
    unsigned char *px;
    BITMAPINFO bi;
    BITMAPFILEHEADER bf;
    HDC sd, td;
    HBITMAP bm;
    HGDIOBJ old;
    FILE *f;
    if (rc.left < 0) rc.left = 0;
    if (rc.top < 0) rc.top = 0;
    if (rc.right > g_w) rc.right = g_w;
    if (rc.bottom > g_h) rc.bottom = g_h;
    w = rc.right - rc.left; h = rc.bottom - rc.top;
    if (w < 1 || h < 1 || !g_mem) return 0;
    stride = ((size_t)w * 3 + 3) & ~(size_t)3;
    px = (unsigned char *)malloc(stride * (size_t)h);
    if (!px) return 0;
    sd = GetDC(NULL); td = CreateCompatibleDC(sd); bm = CreateCompatibleBitmap(sd, w, h);
    old = SelectObject(td, bm);
    BitBlt(td, 0, 0, w, h, g_mem, rc.left, rc.top, SRCCOPY);
    SelectObject(td, old);
    memset(&bi, 0, sizeof bi);
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = h;
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 24; bi.bmiHeader.biCompression = BI_RGB;
    ok = GetDIBits(sd, bm, 0, (UINT)h, px, &bi, DIB_RGB_COLORS) == h;
    DeleteObject(bm); DeleteDC(td); ReleaseDC(NULL, sd);
    if (ok) {
        memset(&bf, 0, sizeof bf);
        bf.bfType = 0x4D42;
        bf.bfOffBits = (DWORD)(sizeof bf + sizeof bi.bmiHeader);
        bf.bfSize = (DWORD)(bf.bfOffBits + stride * (size_t)h);
        f = fopen(path, "wb");
        ok = f != NULL;
        if (f) {
            fwrite(&bf, sizeof bf, 1, f);
            fwrite(&bi.bmiHeader, sizeof bi.bmiHeader, 1, f);
            fwrite(px, 1, stride * (size_t)h, f);
            fclose(f);
        }
    }
    free(px);
    return ok;
}
static void do_bmp(HWND w)
{
    static const char *const names[VIEW_COUNT] = {"worm", "manhattan1", "manhattan2", "partnerships1", "partnerships2", "runrate"};
    char path[MAX_PATH], def[80], msg[MAX_PATH + 40];
    int ok, sx = g_mx, sy = g_my, sh = g_hot_id;
    snprintf(def, sizeof def, "CricLens_%s.bmp", names[g_view]);
    save_dialog_path(w, def, "Bitmap image (*.bmp)\0*.bmp\0", "bmp", path, sizeof path, &ok);
    if (!ok) return;
    g_mx = g_my = -1; g_hot_id = 0;                     /* capture without hover effects */
    draw_scene(g_mem);
    g_mx = sx; g_my = sy; g_hot_id = sh;
    if (export_region_bmp(path, g_chart_win)) { snprintf(msg, sizeof msg, "BMP saved: %s", base_name(path)); toast(msg); }
    else set_error("The BMP image could not be saved.");
}
static void do_about(HWND w)
{
    int r = MessageBoxA(w,
        "CricLens - Cricket Analytics Desktop  v1.0\n\n"
        "Written entirely in C (Win32 API + GDI).\n"
        "Integrated scorecard parser, match storage, statistics engine and chart renderer.\n\n"
        "Keyboard:  Left/Right = match   1-6 = charts   Ctrl+O = upload\n"
        "                  Ctrl+S = save chart image   Ctrl+D = dark/light   F11 = full screen\n\n"
        "Create a Desktop shortcut now?",
        "About CricLens", MB_YESNO | MB_ICONINFORMATION);
    if (r == IDYES) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        toast(msg);
    }
}
static void do_id(HWND w, int id)
{
    if (id == ID_DARK) toggle_theme();
    else if (id == ID_UPLOAD) open_modal();
    else if (id == ID_MATCHSEL) g_dd_open = !g_dd_open;
    else if (id >= ID_MITEM && id < ID_MITEM + MAX_TITLES) { set_match(id - ID_MITEM); g_dd_open = 0; }
    else if (id >= ID_CTAB && id < ID_CTAB + NCTAB) select_view((View)(id - ID_CTAB));
    else if (id >= ID_RTAB && id < ID_RTAB + NRTAB) select_rtab(id - ID_RTAB);
    else if (id == ID_DL_SVG) do_svg(w);
    else if (id == ID_DL_BMP) do_bmp(w);
    else if (id == ID_ERRCLOSE) g_err[0] = 0;
    else if (id == ID_ABOUT) do_about(w);
    else if (id == ID_M_CLOSE || id == ID_M_CANCEL || id == ID_M_BACK) close_modal();
    else if (id == ID_M_CHOOSE) choose_file(w);
    else if (id == ID_M_LOAD) do_load();
}
static void toggle_fullscreen(HWND w)
{
    DWORD st = (DWORD)GetWindowLong(w, GWL_STYLE);
    if (!g_full) {
        MONITORINFO mi;
        memset(&mi, 0, sizeof mi);
        mi.cbSize = sizeof mi;
        g_wp.length = sizeof g_wp;
        if (GetWindowPlacement(w, &g_wp) && GetMonitorInfo(MonitorFromWindow(w, MONITOR_DEFAULTTOPRIMARY), &mi)) {
            SetWindowLong(w, GWL_STYLE, (LONG)(st & ~WS_OVERLAPPEDWINDOW));
            SetWindowPos(w, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top,
                         mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top,
                         SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
            g_full = 1;
        }
    } else {
        SetWindowLong(w, GWL_STYLE, (LONG)(st | WS_OVERLAPPEDWINDOW));
        SetWindowPlacement(w, &g_wp);
        SetWindowPos(w, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        g_full = 0;
    }
}
static void end_splash(void) { g_splash = 0; g_t_enter = GetTickCount(); g_t_match = g_t_chart = g_t_rtab = g_t_enter; }

static void resize_backbuffer(HWND w, int cw, int ch)
{
    HDC sdc;
    if (cw < 1 || ch < 1) return;
    if (g_mem) { SelectObject(g_mem, g_memold); DeleteObject(g_membmp); DeleteDC(g_mem); }
    sdc = GetDC(w);
    g_mem = CreateCompatibleDC(sdc);
    g_membmp = CreateCompatibleBitmap(sdc, cw, ch);
    g_memold = SelectObject(g_mem, g_membmp);
    ReleaseDC(w, sdc);
    g_w = cw; g_h = ch;
    g_plot_valid = 0;
}

/* One animation step (about 60 times a second). Returns non-zero when another frame is needed. */
static int step_anims(void)
{
    DWORD now = GetTickCount();
    int i, need = 0;
    double d, k;
    g_dt = clampd((double)(now - g_t_last) / 1000.0, 0.001, 0.1);
    g_t_last = now;
    for (i = 0; i < ID_MAX; i++) {
        double tgt = (i == g_hot_id && g_hot_id != 0) ? 1.0 : 0.0;
        if (fabs(g_hv[i] - tgt) > 0.003) { g_hv[i] += (tgt - g_hv[i]) * (1.0 - exp(-g_dt * 16.0)); need = 1; }
        else g_hv[i] = tgt;
    }
    if (g_theme_t != g_theme_goal) {
        d = g_dt * 3.4;
        if (g_theme_t < g_theme_goal) { g_theme_t += d; if (g_theme_t > g_theme_goal) g_theme_t = g_theme_goal; }
        else { g_theme_t -= d; if (g_theme_t < g_theme_goal) g_theme_t = g_theme_goal; }
        theme_update();
        g_plot_valid = 0;
        need = 1;
    }
    d = (g_modal ? 1.0 : 0.0) - g_mod_a;
    if (fabs(d) > 0.002) { g_mod_a += d * (1.0 - exp(-g_dt * 14.0)); need = 1; } else g_mod_a = g_modal ? 1.0 : 0.0;
    d = (g_dd_open ? 1.0 : 0.0) - g_dd_a;
    if (fabs(d) > 0.002) { g_dd_a += d * (1.0 - exp(-g_dt * 18.0)); need = 1; } else g_dd_a = g_dd_open ? 1.0 : 0.0;
    k = 1.0 - exp(-g_dt * 16.0);
    if (fabs(g_scroll - g_scroll_goal) > 0.4) { g_scroll += (g_scroll_goal - g_scroll) * k; need = 1; } else g_scroll = g_scroll_goal;
    if (fabs(g_rs - g_rs_goal) > 0.4) { g_rs += (g_rs_goal - g_rs) * k; need = 1; } else g_rs = g_rs_goal;
    /* the multi-line edit box is only visible once the dialog has finished opening */
    if (g_edit) {
        int want = g_modal && g_mod_a > 0.97;
        if (want) {
            if (!IsWindowVisible(g_edit)) { ShowWindow(g_edit, SW_SHOW); SetFocus(g_edit); }
            SetWindowPos(g_edit, NULL, g_edit_pos.left, g_edit_pos.top, g_edit_pos.right - g_edit_pos.left,
                         g_edit_pos.bottom - g_edit_pos.top, SWP_NOZORDER | SWP_NOACTIVATE);
        } else if (IsWindowVisible(g_edit)) ShowWindow(g_edit, SW_HIDE);
    }
    return need;
}

/* ------------------------------------------------------- edit box subclass */
static LRESULT CALLBACK edit_proc(HWND h, UINT m, WPARAM wp, LPARAM lp)
{
    LRESULT r;
    int ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    if (m == WM_KEYDOWN && wp == VK_RETURN && ctrl) { PostMessage(GetParent(h), WM_CL_LOAD, 0, 0); return 0; }
    if (m == WM_KEYDOWN && wp == VK_ESCAPE) { PostMessage(GetParent(h), WM_CL_CLOSE, 0, 0); return 0; }
    if (m == WM_CHAR && wp == VK_RETURN && ctrl) return 0;
    r = CallWindowProcA(g_edit_old, h, m, wp, lp);
    if (m == WM_PAINT && GetWindowTextLengthA(h) == 0) {          /* placeholder text */
        HDC dc = GetDC(h);
        RECT rc;
        GetClientRect(h, &rc);
        rc.left += 2; rc.top += 1;
        SelectObject(dc, f_mono);
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, C(K_FAINT));
        DrawTextA(dc, "MATCH,ID,Team A,Team B,Venue,2026-11-18\nINNINGS,1,Team A,42,2,18\nBATTER,1,Player,25,12,2,1\n"
                      "BOWLER,2,Bowler,12,12,22\nOVER,1,1,10,0\nFOW,1,1,25,2.4,Player", -1, &rc, DT_LEFT | DT_TOP | DT_NOPREFIX);
        ReleaseDC(h, dc);
    }
    if (m == WM_CHAR || m == WM_PASTE || m == WM_CUT || m == WM_CLEAR || m == WM_UNDO || m == WM_KEYUP) InvalidateRect(h, NULL, TRUE);
    return r;
}

/* ------------------------------------------------------------ window proc */
static LRESULT CALLBACK window_proc(HWND w, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE:
        g_hwnd = w;
        make_fonts();
        theme_update();
        g_icon_big = cl_make_hicon(GetSystemMetrics(SM_CXICON) > 0 ? GetSystemMetrics(SM_CXICON) : 32);
        g_icon_small = cl_make_hicon(GetSystemMetrics(SM_CXSMICON) > 0 ? GetSystemMetrics(SM_CXSMICON) : 16);
        if (g_icon_big) SendMessage(w, WM_SETICON, ICON_BIG, (LPARAM)g_icon_big);
        if (g_icon_small) SendMessage(w, WM_SETICON, ICON_SMALL, (LPARAM)g_icon_small);
        g_logo_splash = (unsigned char *)malloc(256 * 256 * 4);
        if (g_logo_splash) { cl_render_icon(g_logo_splash, 256); cl_flatten_icon(g_logo_splash, 256, RGB(11, 18, 44)); }
        g_edit = CreateWindowExA(0, "EDIT", "", WS_CHILD | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN,
                                 0, 0, 10, 10, w, (HMENU)(UINT_PTR)1001, g_inst, NULL);
        if (g_edit) {
            SendMessage(g_edit, WM_SETFONT, (WPARAM)f_mono, TRUE);
            SendMessage(g_edit, EM_LIMITTEXT, 300000, 0);
            g_edit_old = (WNDPROC)SetWindowLongPtrA(g_edit, GWLP_WNDPROC, (LONG_PTR)edit_proc);
        }
        g_t_start = g_t_last = GetTickCount();
        SetTimer(w, 1, 16, NULL);
        return 0;
    case WM_SIZE:
        if (wp != SIZE_MINIMIZED) { resize_backbuffer(w, LOWORD(lp), HIWORD(lp)); InvalidateRect(w, NULL, FALSE); }
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO *mm = (MINMAXINFO *)lp;
        RECT r;
        r.left = 0; r.top = 0; r.right = U(1080); r.bottom = U(680);
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        mm->ptMinTrackSize.x = r.right - r.left;
        mm->ptMinTrackSize.y = r.bottom - r.top;
        return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_CTLCOLOREDIT: {
        HDC hdc = (HDC)wp;
        COLORREF bgc = C(K_CARD2);
        SetTextColor(hdc, C(K_TEXT));
        SetBkColor(hdc, bgc);
        if (!g_edit_brush || g_edit_brush_col != bgc) {
            if (g_edit_brush) DeleteObject(g_edit_brush);
            g_edit_brush = CreateSolidBrush(bgc);
            g_edit_brush_col = bgc;
        }
        return (LRESULT)g_edit_brush;
    }
    case WM_CL_LOAD: if (g_modal) do_load(); return 0;
    case WM_CL_CLOSE: if (g_modal) close_modal(); return 0;
    case WM_TIMER: {
        int need = step_anims();
        static unsigned tick;
        tick++;
        if (g_splash && GetTickCount() - g_t_start >= SPLASH_MS) end_splash();
        if (need || g_busy || g_splash || (g_idle && (tick & 1))) InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_MOUSEMOVE:
        g_mx = (short)LOWORD(lp); g_my = (short)HIWORD(lp);
        if (!g_tracking) {
            TRACKMOUSEEVENT te;
            te.cbSize = sizeof te; te.dwFlags = TME_LEAVE; te.hwndTrack = w; te.dwHoverTime = 0;
            TrackMouseEvent(&te);
            g_tracking = 1;
        }
        g_hot_id = g_splash ? 0 : hit_id(g_mx, g_my);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_MOUSELEAVE:
        g_tracking = 0; g_mx = g_my = -1; g_hot_id = 0;
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT && g_hot_id != 0 && !g_splash) { SetCursor(LoadCursor(NULL, IDC_HAND)); return TRUE; }
        break;
    case WM_MOUSEWHEEL: {
        int delta = (short)HIWORD(wp);
        POINT pt;
        pt.x = (short)LOWORD(lp); pt.y = (short)HIWORD(lp);
        ScreenToClient(w, &pt);
        if (g_splash || g_modal || g_dd_open) return 0;
        if (g_rs_max > 0 && PtInRect(&g_rs_rect, pt)) g_rs_goal = clampd(g_rs_goal - delta / 120.0 * U(70), 0, g_rs_max);
        else g_scroll_goal = clampd(g_scroll_goal - delta / 120.0 * U(80), 0, g_scroll_max);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_LBUTTONDOWN:
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        g_down_id = hit_id((short)LOWORD(lp), (short)HIWORD(lp));
        if (g_down_id == 0 && g_dd_open) g_dd_open = 0;
        if (g_down_id != 0) SetCapture(w);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    case WM_LBUTTONUP: {
        int id = hit_id((short)LOWORD(lp), (short)HIWORD(lp)), was = g_down_id;
        if (GetCapture() == w) ReleaseCapture();
        g_down_id = 0;
        if (was != 0 && id == was) do_id(w, id);
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_KEYDOWN: {
        int ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0, shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        if (g_splash) { end_splash(); InvalidateRect(w, NULL, FALSE); return 0; }
        if (g_modal) { if (wp == VK_ESCAPE) close_modal(); return 0; }
        if (g_dd_open) { if (wp == VK_ESCAPE) g_dd_open = 0; return 0; }
        if (wp == VK_LEFT) change_match(-1);
        else if (wp == VK_RIGHT) change_match(1);
        else if (wp >= '1' && wp <= '6') select_view((View)(wp - '1'));
        else if (wp == VK_TAB) select_view((View)(((int)g_view + (shift ? VIEW_COUNT - 1 : 1)) % VIEW_COUNT));
        else if (wp == VK_DOWN) g_scroll_goal = clampd(g_scroll_goal + U(60), 0, g_scroll_max);
        else if (wp == VK_UP) g_scroll_goal = clampd(g_scroll_goal - U(60), 0, g_scroll_max);
        else if (wp == VK_NEXT) g_scroll_goal = clampd(g_scroll_goal + U(400), 0, g_scroll_max);
        else if (wp == VK_PRIOR) g_scroll_goal = clampd(g_scroll_goal - U(400), 0, g_scroll_max);
        else if (wp == VK_HOME) g_scroll_goal = 0;
        else if (wp == VK_END) g_scroll_goal = g_scroll_max;
        else if (wp == VK_F11) toggle_fullscreen(w);
        else if (wp == VK_ESCAPE) { if (g_full) toggle_fullscreen(w); else g_err[0] = 0; }
        else if (wp == VK_F1) do_about(w);
        else if (ctrl && wp == 'O') open_modal();
        else if (ctrl && wp == 'S') do_bmp(w);
        else if (ctrl && wp == 'D') toggle_theme();
        InvalidateRect(w, NULL, FALSE);
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(w, &ps);
        if (g_mem) {
            draw_scene(g_mem);
            BitBlt(dc, 0, 0, g_w, g_h, g_mem, 0, 0, SRCCOPY);
        }
        EndPaint(w, &ps);
        return 0;
    }
    case WM_DESTROY:
        KillTimer(w, 1);
        if (g_mem) { SelectObject(g_mem, g_memold); DeleteObject(g_membmp); DeleteDC(g_mem); g_mem = NULL; }
        if (g_pxdc) { SelectObject(g_pxdc, g_pxold); DeleteObject(g_pxbmp); DeleteDC(g_pxdc); g_pxdc = NULL; }
        if (g_plot) DeleteObject(g_plot);
        if (g_edit_brush) DeleteObject(g_edit_brush);
        kill_all_fonts();
        if (g_icon_big) DestroyIcon(g_icon_big);
        if (g_icon_small) DestroyIcon(g_icon_small);
        free(g_logo_splash);
        sg5_shutdown();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(w, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE prev, LPSTR cmd, int show)
{
    WNDCLASSA wc;
    HWND w;
    MSG m;
    HDC sd;
    RECT wa, r;
    int cw, ch, ww, wh;
    (void)prev;

    /* "CricLens.exe --install" creates the Desktop / Start Menu shortcuts and exits. */
    if (cmd && strstr(cmd, "--install")) {
        char msg[256];
        cl_install_shortcuts(msg, sizeof msg);
        if (!strstr(cmd, "--quiet")) MessageBoxA(NULL, msg, "CricLens setup", MB_OK | MB_ICONINFORMATION);
        return 0;
    }
    g_inst = instance;
    cl_enable_dpi_awareness();
    sd = GetDC(NULL);
    g_s = GetDeviceCaps(sd, LOGPIXELSX) / 96.0;
    ReleaseDC(NULL, sd);
    if (g_s < 1.0) g_s = 1.0;
    theme_update();
    if (!sg5_init()) { MessageBoxA(NULL, "Could not initialise CricLens match data.", "CricLens", MB_OK | MB_ICONERROR); return 1; }
    load_current();

    ZeroMemory(&wc, sizeof wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = window_proc; wc.hInstance = instance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW); wc.hbrBackground = NULL; wc.lpszClassName = "CricLensNativeWindow";
    wc.hIcon = cl_make_hicon(32);
    if (!RegisterClassA(&wc)) { sg5_shutdown(); return 1; }

    SystemParametersInfoA(SPI_GETWORKAREA, 0, &wa, 0);
    cw = U(1280); ch = U(840);
    if (cw > wa.right - wa.left - U(40)) cw = wa.right - wa.left - U(40);
    if (ch > wa.bottom - wa.top - U(70)) ch = wa.bottom - wa.top - U(70);
    r.left = 0; r.top = 0; r.right = cw; r.bottom = ch;
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    ww = r.right - r.left; wh = r.bottom - r.top;
    w = CreateWindowExA(0, wc.lpszClassName, "CricLens - Cricket Analytics Desktop", WS_OVERLAPPEDWINDOW,
                        wa.left + (wa.right - wa.left - ww) / 2, wa.top + (wa.bottom - wa.top - wh) / 2, ww, wh,
                        NULL, NULL, instance, NULL);
    if (!w) { sg5_shutdown(); return 1; }
    cl_apply_titlebar(w, 0);
    ShowWindow(w, show);
    UpdateWindow(w);
    while (GetMessageA(&m, NULL, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageA(&m); }
    return (int)m.wParam;
}
