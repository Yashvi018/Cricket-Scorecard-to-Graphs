# CricLens test report

## Verified in the Linux build environment
- All five test programs pass when compiled with the direct `gcc` commands in README.md
  (Components 1-4 and the legacy compatibility layer); the text-menu build also compiles.
- `desktop_gui_win32.c` and `desktop_shell_win32.c` pass a syntax/type check (`-Wall -Wextra`, also `-std=c99 -pedantic`)
  against a stand-in Win32 header. This is NOT a real Windows compile.
- The real UI drawing code was executed natively with a recording stand-in for GDI, under AddressSanitizer and
  UndefinedBehaviorSanitizer, and rendered to images to inspect the layout: light and dark themes, all six charts,
  all three scorecard tabs, all three sample matches, hover tooltips, the upload dialog, the match dropdown, the error
  banner, the minimum window size and 150% display scaling. An exhaustive sweep (1,728 frames: every view x tab x match x
  theme x 4 window sizes, with random hover/scroll positions and dialog/dropdown states) found no memory or undefined-behaviour errors.
- Scorecard data (batting/bowling rows, SR, BND%, fall of wickets, MVP ranking) was checked against the sample match, and an
  invalid scorecard produces the message "line 1: the MATCH line must come first".
- The icon rasteriser and `.ico` writer were executed natively; the `.ico` contains 7 sizes and decodes with an independent reader.

## Still to verify on a Windows PC (MSYS2 UCRT64 GCC)
- The single `gcc` command in README.md compiles and links CricLens.exe without errors.
- Real Windows rendering (fonts are Segoe UI there), the native multi-line paste box, file dialogs, and animations feel.
- `CricLens.exe --install` creates the Desktop and Start Menu shortcuts and the desktop icon launches the app.
- Download SVG / BMP buttons and Import via file or pasted text.
